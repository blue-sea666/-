import { initRouter } from '@/router/index'
import router from '@/router/index'

const user = {
    state:{
        loginState:false
    },
    mutations:{
        SET_ROUTERS(state:any,routes:any){
            state.routers = routes
        },
        SET_LOGIN_STATE(state:any,loginState:any){
            state.loginState = loginState
        }
    },
    actions:{
        GET_ROUTERS_DATA(ctx:any){
            router.push({path:'/'})
        }
    }
}

export default user