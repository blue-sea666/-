<template>
    <div style="width:580px;float:left;">
        <el-input v-model="namevalue" class="sernameval" style="width:70%;" placeholder="请输入名称" />
        <el-button type="primary" plain   @click="searchname" class="btnbutton">搜索</el-button>
        <el-button type="primary" plain   @click="addaccounts" style="margin-left:10px;" class="btnbutton">添加</el-button>
    </div>
    <el-table
    :data="tableData"
    :row-style="{height:'35px'}"
    :cell-style="{padding:'0px'}"
    border
    style="width: 100%">
    <el-table-column  prop="accountsName" label="账套名称" align="center" ></el-table-column>
    <el-table-column  prop="accountsSystem" label="会计制度" align="center" ></el-table-column>
    <el-table-column  prop="setTime" label="启用期间" align="center" ></el-table-column>
    <el-table-column  prop="insertTime" label="创建时间" align="center" ></el-table-column>
    <el-table-column
      fixed="right"
      label="操作">
      <template #default="scope">
        <el-button @click="handleEdit(scope.$index, scope.row)" plain  type="primary" size="small" class="btnbutton">编辑</el-button>
        <el-button @click="handleDelete(scope.$index, scope.row)" plain  type="danger" size="small" class="btnbutton">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <!-- 分页底部 -->
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[5,10,15]"
      :page-size="pageSize"
      layout="total,jumper,prev, pager, next,sizes"
      :total="totalCount"
  ></el-pagination>
  <el-dialog title="账套信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="rules" :model="accountslist" ref="accountsform" label-width="100px">
        <el-form-item label="账套名称" prop="accountsName">
          <el-input v-model="accountslist.accountsName" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="会计制度" prop="accountsSystem">
          <el-input v-model="accountslist.accountsSystem" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="启用期间" prop="setTime">
           <el-date-picker class="sernameval"
              v-model="accountslist.setTime"
               type="date"
              placeholder="请选择期间" value-format="yyyy-mm-dd"
                              style="font-size:14px;padding-left:5px;width:356px;">
            </el-date-picker>
        </el-form-item>
        <el-form-item label="状态" prop="accountsStatus">
         <el-select v-model="accountslist.accountsStatus" style="width:358px;" class="sernameval" @change="changeStatus($event)" placeholder="请选择">
                <el-option
                  v-for="item in optionsvalue"
                  :key="item.accountsStatusvalue"
                  :label="item.accountsStatus"
                  :value="item.accountsStatusvalue">
                </el-option>
              </el-select>
        </el-form-item>
        <div class="examdiv">
          <el-button type="primary" plain   @click="saveAccounts" class="btnbutton">保存</el-button>
          <el-button type="primary" plain   @click="closeAccounts" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
</template>
<script>
import{ defineComponent,toRefs,unref,reactive, onMounted,ref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getAccountsList,addAccounts,deleteAccounts,updateAccounts} from "@/api/system";
import { async } from "q";
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
export default{
    name: "userlist",
    setup: () => {
        const accountsform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            isEdit:false,
            namevalue:"",
            accountslist:{
              accountsId:"",
              accountsName:"",
              accountsSystem:"",
              setTime:"",
              accountsStatus:"",
              accountsStatusValue:0
            },
            optionsvalue:[
              {
                  accountsStatusvalue: '1',
                  accountsStatus: '停用'
                }, {
                  accountsStatusvalue: '0',
                  accountsStatus: '启用'
                }
            ],
            dialogTableVisible:false,
            rules:{
                accountsName: [{ required: true, message: '请输入名称', trigger: 'blur' }],
                setTime: [{ required: true, message: '请选择启用期间', trigger: 'blur' }],
            }
        })
        onMounted(() => {
          getAccountsListArray();
        })
        const changeStatus=(e)=>{
          state.accountslist.accountsStatusValue=e;
        }
        const myTimeToLocal=(inputTime)=>{
         
          inputTime = inputTime.replace(" 00:00:00","");
          return inputTime;
        }
        const getTimeToLocal=(inputTime)=>{
          if(!inputTime && typeof inputTime !== 'number'){
            return '';
          }
          var localTime = '';
          inputTime = new Date(inputTime).getTime();
          const offset = (new Date()).getTimezoneOffset();
          localTime = (new Date(inputTime - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
        const getCurrentNowTime=()=>{
          let hh =  new Date().getHours()<10 ? '0'+new Date().getHours() : new Date().getHours();
    　　  let mf = new Date().getMinutes()<10 ? '0'+new Date().getMinutes() : new Date().getMinutes();
    　　  let ss = new Date().getSeconds()<10 ? '0'+new Date().getSeconds() : new Date().getSeconds();
          return " "+hh+":"+mf+":"+ss;
        }
        //加载仓库列表
        const getAccountsListArray=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsName:state.namevalue
          }
          let res=await getAccountsList(paramdata);
          console.log(res);
          if(res.code==20000){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        //新增表格
        const addaccounts=()=>{
          clearform();
          state.isEdit=false;
          state.dialogTableVisible=true;
        }
        //关闭对话框
        const closeAccounts=()=>{
          state.dialogTableVisible=false;
        }
        //保存
        const saveAccounts=async()=>{
          const form = unref(accountsform);//获取验证规则
          let cuurentDay=myTimeToLocal(getTimeToLocal(state.accountslist.setTime))+getCurrentNowTime();
          if (!form) return
          try {
            await form.validate();//表单验证
            var param={
              id:state.accountslist.accountsId,
              accountsName:state.accountslist.accountsName,
              accountsSystem:state.accountslist.accountsSystem,
              setTime:cuurentDay,
              accountsStatus:state.accountslist.accountsStatusValue
            }
            if(!state.isEdit){
              let res=await addAccounts(param);
              if(res.code==20000){
                ElMessage({
                  type: 'success',
                  message: '新增成功',
                })
                state.dialogTableVisible=false;
                getAccountsListArray();
              }
            }else{
              let res=await updateAccounts(param);
              if(res.code==20000){
                ElMessage({
                  type: 'success',
                  message: '编辑成功',
                })
                state.dialogTableVisible=false;
                getAccountsListArray();
              }
            }
          }catch (error) {

          }
        }
        const searchname=()=>{
          getAccountsListArray();
        }
        //删除
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.id);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        //编辑
        const handleEdit=(index,row)=>{
          state.isEdit=true;
          state.dialogTableVisible=true;
          state.accountslist.accountsId=row.id;
          state.accountslist.accountsName=row.accountsName;
          state.accountslist.accountsSystem=row.accountsSystem;
          state.accountslist.setTime=row.setTime;
          state.accountslist.accountsStatus=row.accountsStatus;
          if(row.accountsStatus=="1"){
            state.accountslist.accountsStatus="停用";
          }else{
            state.accountslist.accountsStatus="启用";
          }
        }
        const deleteDataById=async(rowid)=>{
           var param={
             id:rowid
           }
           let res=await deleteAccounts(param);
            if(res.code==20000){
              getAccountsListArray();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        //清楚表单的值
        const clearform=()=>{
          state.accountslist.accountsId="";
          state.accountslist.accountsName="";
          state.accountslist.accountsSystem="";
          state.accountslist.setTime="";
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getAccountsListArray();
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getAccountsListArray();
        }
        return {
            ...toRefs(state),
            addaccounts,
            handleDelete,
            accountsform,
            closeAccounts,
            saveAccounts,
            getAccountsListArray,
            handleCurrentChange,
            handleSizeChange,
            handleEdit,
            clearform,
            deleteDataById,
            searchname,
            getTimeToLocal,
            changeStatus,
            myTimeToLocal,
            getCurrentNowTime
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width: 100%;
}
 .btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
 .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.examdiv{
    text-align: center;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btndel.el-button--primary{
    height: 28px;
    color: #fff;
  }
</style>