<template>
    <div style="width:580px;float:left;">
        <el-input v-model="namevalue" class="sernameval" style="width:70%;" placeholder="请输入名称" />
        <el-button type="primary"  plain  @click="searchname" class="btnbutton">搜索</el-button>
        <el-button type="primary" plain   @click="addcategory" style="margin-left:10px;" class="btnbutton">添加</el-button>
    </div>
    <el-table
    :data="tableData"
    :row-style="{height:'35px'}"
    :cell-style="{padding:'0px'}"
    border
    style="width: 100%">
    <el-table-column  prop="cateName" label="名称" align="center" ></el-table-column>
    <el-table-column
      fixed="right"
      label="操作">
      <template #default="scope">
        <el-button @click="handleEdit(scope.$index, scope.row)" plain  type="primary" size="small" class="btnbutton">编辑</el-button>
        <el-button @click="handleDelete(scope.$index, scope.row)" plain  type="danger" size="small" class="btnbutton">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <!-- 分页底部 -->
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[5,10,15]"
      :page-size="pageSize"
      layout="total,jumper,prev, pager, next,sizes"
      :total="totalCount"
  ></el-pagination>
  <el-dialog title="科目类别信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="rules" :model="catelist" ref="cateform" label-width="100px">
        <el-form-item label="名称" prop="catename">
          <el-input v-model="catelist.catename" class="sernameval"></el-input>
        </el-form-item>
        <div class="examdiv">
          <el-button type="primary" plain @click="saveCategory" class="btnbutton">保存</el-button>
          <el-button type="primary" plain @click="closeCategory" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
</template>
<script>
import{ defineComponent,toRefs,unref,reactive, onMounted,ref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getSubjectCategoryList,addSubjectCategory,deleteSubjectCategory,updateSubjectCategory} from "@/api/system";
import { async } from "q";
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
export default{
    name: "userlist",
    setup: () => {
        const cateform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            isEdit:false,
            namevalue:"",
            catelist:{
              cateid:"",
              catename:""
            },
            dialogTableVisible:false,
            rules:{
                catename: [{ required: true, message: '请输入名称', trigger: 'blur' }]
            }
        })
        onMounted(() => {
          getCategoryList();
        })
        //加载仓库列表
        const getCategoryList=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            cateName:state.namevalue
          }
          let res=await getSubjectCategoryList(paramdata);
          if(res.code==200){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        //新增表格
        const addcategory=()=>{
          clearform();
          state.isEdit=false;
          state.dialogTableVisible=true;
        }
        //关闭对话框
        const closeCategory=()=>{
          state.dialogTableVisible=false;
        }
        //保存
        const saveCategory=async()=>{
          const form = unref(cateform);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param={
              id:state.catelist.cateid,
              cateName:state.catelist.catename
            }
            if(!state.isEdit){
              let res=await addSubjectCategory(param);
              if(res.code==20000){
                ElMessage({
                  type: 'success',
                  message: '新增成功',
                })
                state.dialogTableVisible=false;
                getCategoryList();
              }
            }else{
              let res=await updateSubjectCategory(param);
              if(res.code==20000){
                ElMessage({
                  type: 'success',
                  message: '编辑成功',
                })
                state.dialogTableVisible=false;
                getCategoryList();
              }
            }
          }catch (error) {

          }
        }
        const searchname=()=>{
          getCategoryList();
        }
        //删除
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.Id);
             console.log(111);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        //编辑
        const handleEdit=(index,row)=>{
          console.log(row);
          state.isEdit=true;
          state.dialogTableVisible=true;
          state.catelist.cateid=row.id;
          state.catelist.catename=row.cateName;
        }
        const deleteDataById=async(rowid)=>{
           var param={
             Id:rowid
           }
           let res=await deleteSubjectCategory(param);
            if(res.code==20000){
              getCategoryList();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        //清楚表单的值
        const clearform=()=>{
          state.catelist.cateid="";
          state.catelist.catename="";
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getCategoryList();
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getCategoryList();
        }
        return {
            ...toRefs(state),
            addcategory,
            handleDelete,
            cateform,
            closeCategory,
            saveCategory,
            getCategoryList,
            handleCurrentChange,
            handleSizeChange,
            handleEdit,
            clearform,
            deleteDataById,
            searchname
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width: 100%;
}
 .btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
 .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.examdiv{
    text-align: center;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btndel.el-button--primary{
    height: 28px;
    color: #fff;
  }
</style>