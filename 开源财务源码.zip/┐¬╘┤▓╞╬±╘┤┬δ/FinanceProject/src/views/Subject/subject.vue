<template>
    <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
      <el-tab-pane label="资产">
        <assetschild ref="RefChilde"></assetschild>
      </el-tab-pane>
      <el-tab-pane label="负债">
        <debtchild ref="RefChilde"></debtchild>
      </el-tab-pane>
      <el-tab-pane label="共同">
        <commonchild ref="RefChilde"></commonchild>
      </el-tab-pane>
      <el-tab-pane label="权益">
        <interestschild ref="RefChilde"></interestschild>
      </el-tab-pane>
      <el-tab-pane label="成本">
        <costchild ref="RefChilde"></costchild>
      </el-tab-pane>
      <el-tab-pane label="损益">
        <losschild ref="RefChilde"></losschild>
      </el-tab-pane>
    </el-tabs>
</template>
<script>
import{toRefs,reactive, onMounted,ref,watch,unref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {addSubject,deleteSubject,getSubjectList,updateSubject} from "@/api/system";
import {ElMessage,ElTree,ElMessageBox} from 'element-plus'
import assetschild from "../../components/assetschild.vue";
import debtchild from "../../components/debtchild.vue";
import commonchild from "../../components/commonchild.vue";
import interestschild from "../../components/interestschild.vue";
import costchild from "../../components/costchild.vue";
import losschild from "../../components/losschild.vue";
export default{
    name: "userlist",
    components: { assetschild,debtchild, commonchild,interestschild,costchild,losschild},
    setup: () => {
        const subjectform =ref(null);
        const RefChilde = ref();     //RefChilde 要和Son组件上的class名相同
        const fnCallChild = () => {
          RefChilde.value.sonFn();      //sonFn是子组件里的方法
        };
        const state = reactive({
        })
        onMounted(() => {
          
        })
        return {
            ...toRefs(state),
            fnCallChild
        }
    }
}
</script>
<style>
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}


.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
  padding: 5px;
}
.custom-tree-node .do i:hover {
  color: #333;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.el-pagination .el-pager .number.active {
    background-color: white;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
</style>