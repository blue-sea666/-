<template>
    <el-form :rules="rules" :model="formlist" label-width="120px" class="forminput" style="width:100%;height:40px;margin-left:-60px;">
      <div style="float:left;">
        <el-form-item label="凭证号："> 
          <el-input class="sernameval" v-model="formlist.vouchercode" style="width:300px;float:left;"></el-input>
        </el-form-item>
      </div>
    </el-form>
    <div style="width:320px;">
      <el-button type="primary" plain  @click="searchVoucher" class="btnbutton">查询</el-button>
      <el-button type="primary" plain  @click="savedatlist" class="btnbutton">审核</el-button>
    </div>
    <div style="width:100%;">
      <el-table
      :data="tableData"
      @selection-change="handleSelectionChange"
      :row-style="{height:'35px'}"
      :cell-style="{padding:'0px'}"
      border>
      <el-table-column type="selection" width="55" />
      <el-table-column prop="userName" label="制单人" align="center" class="tbline" width="180">
      </el-table-column>
      <el-table-column prop="voucherCode" label="凭证号" align="center" class="tbline">
      </el-table-column>
      <el-table-column prop="voucherStatus" label="状态" align="center" class="tbline">
        <template #default="scope">
             <span style="color:red;" v-if="scope.row.voucherStatus == 0">未审核</span>
          </template>
      </el-table-column>
      <el-table-column prop="voucherTime" label="日期" align="center" class="tbline">
      </el-table-column>
       <el-table-column
        fixed="right"
        label="操作">
        <template #default="scope">
          <el-button @click="handleView(scope.$index, scope.row)" plain type="primary" size="small" class="btnbutton">查看</el-button>
        </template>
     </el-table-column>
    </el-table>
    <!-- 分页底部 -->
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[5,10,15]"
      :page-size="pageSize"
      layout="total,jumper,prev, pager, next,sizes"
      :total="totalCount"
  ></el-pagination>
  </div>
    <el-dialog title="凭证信息" v-model="dialogTableVisiblePrint" center :append-to-body='true' :close-on-click-modal="false" @close="closePointDialog" :lock-scroll="true" width="52%" height="500px">
      <div style="width: 100%" align="center">
      <div id="printTest" style="width: 100%;" align="center">
        <h1 style="margin-top:10px;margin-bottom:10px;">凭证信息</h1>
        <div style="width:100%;height:30px;">
          <div style="float:left;width:10%;text-align:left;">日期：</div>
          <div style="float:left;width:15%;text-align:left;">{{forminfo.voucherTime}}</div>
          <div style="float:left;width:10%;text-align:left;">制单人：</div>
          <div style="float:left;width:15%;text-align:left;">{{forminfo.userName}}</div>
          <div style="float:left;width:10%;text-align:left;">凭证号：</div>
          <div style="float:left;width:15%;text-align:left;">{{forminfo.voucherCode}}</div>
        </div>
        <table class="tb" style="width:100%;"> 
          <tbody>
              <tr>
                <td style="text-align:center;">序号</td>
                <td style="text-align:center;">摘要</td>
                <td style="text-align:center;">科目</td>
                <td style="text-align:center;">借方金额</td>
                <td style="text-align:center;">贷方金额</td>
              </tr>
               <tr v-for="(printItem,index) in printTable" :key="index" >
                <td style="text-align:center;">{{index+1}}</td>
                <td style="text-align:center;">{{printItem.summaryName}}</td>
                <td style="text-align:center;">{{printItem.subjectName}}</td>
                <td style="text-align:center;">{{printItem.lenderMoney}}</td>
                <td style="text-align:center;">{{printItem.debitMoney}}</td>
              </tr>
              <!-- <tr>
                <td colspan="4" style="text-align:center;">合计：</td>
                <td style="text-align:center;"></td>
                <td style="text-align:center;">{{allgoodcount}}</td>
                <td style="text-align:center;"></td>
                <td style="text-align:center;">{{allmoneyprice}}</td>
              </tr> -->
          </tbody>
        </table>
      </div>
      <div style="margin-top:10px;">
        <el-button type="primary" plain class="btnbutton" v-print="'#printTest'">打印</el-button>
        <el-button type="primary" plain class="btnbutton" @click="closeprint">取消</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getVoucherList,updateVoucherById,getVoucherDetailList} from '@/api/system';
import { async } from "q";
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const state = reactive({
            locale:zhCn,
            tableData: [],
            printTable:[],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            dialogTableVisiblePrint:false,
            formlist:{
              voucherdate:"",
              vouchercode:""
            },
            forminfo:{
              userName:"",
              voucherTime:"",
              voucherCode:""
            },
            currentId:""
        })
        onMounted(() => {
          getVoucherListArray();
        })
        //加载仓库列表
        const getVoucherListArray=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            voucherCode:state.formlist.vouchercode,
            voucherStatus:0,
            accountsId:localStorage.getItem('accountsId')
          }
          let res=await getVoucherList(paramdata);
          if(res.code==200){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        const handleSelectionChange = (val) => {
          state.currentId="";
          for(var index=0;index<val.length;index++){
            state.currentId=state.currentId+val[index].id+",";
          }
          console.log(val);
        }
        const searchVoucher=()=>{
          getVoucherListArray();
        }
        const getVoucherDetailListArray=async(currentid)=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            voucherId:currentid
          }
          let res=await getVoucherDetailList(paramdata);
          console.log(res);
          if(res.code==200){
           state.printTable=res.data.records;
          }
        }
        const closeprint=()=>{
            state.dialogTableVisiblePrint=false;
        }
        const handleView=(index,row)=>{
          state.forminfo.userName=row.userName;
          state.forminfo.voucherTime=row.voucherTime;
          state.forminfo.voucherCode=row.voucherCode;
            getVoucherDetailListArray(row.id);
            state.dialogTableVisiblePrint=true;
        }
         //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getVoucherListArray();
        }
        const savedatlist=async()=>{
          if(state.currentId!=""){
            ElMessageBox.confirm(
            '确认要审核吗?',
            'Warning',
              {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
              }
            )
            .then(async() => {
              var paramdata={
                id:state.currentId,
                voucherStatus:1
              }
              let res=await updateVoucherById(paramdata);
              if(res.code==20000){
                ElMessage({
                  type: 'success',
                  message: '审核成功！',
                })
                getVoucherListArray();
              }
            })
            .catch(() => {
              ElMessage({
                type: 'info',
                message: '已经取消',
              })
            })
          }else{
              ElMessage({
                type: 'info',
                message: '没有选择需要审核的凭证，请重新选择！',
              })
          }
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getVoucherListArray();
        }
        const myTimeToLocal=(inputTime)=>{
          if(!inputTime && typeof inputTime !== 'number'){
            return '';
          }
          var localTime = '';
          inputTime = new Date(inputTime).getTime();
          const offset = (new Date()).getTimezoneOffset();
          localTime = (new Date(inputTime - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
        return {
            ...toRefs(state),
            myTimeToLocal,
            getVoucherListArray,
            handleCurrentChange,
            handleSizeChange,
            searchVoucher,
            handleSelectionChange,
            savedatlist,
            handleView,
            getVoucherDetailListArray,
            closeprint
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width:200px;
}
 .btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.el-table__fixed {
    height:auto !important; 
    bottom:17px; 
}
.el-table--scrollable-x .el-table__body-wrapper {
    z-index: 1;
  }
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
  .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.el-table__fixed {
    height:auto !important; 
    bottom:17px; 
}
.el-table--scrollable-x .el-table__body-wrapper {
    z-index: 1;
  }
      @page{
        size: auto A4 landscape;
        margin: 3mm;
    }
.tb {
		border-collapse:collapse;
		}
    .tb td{
      height: 25px;
    }
		.tb td, .tb th {
		border:1px solid #aaa;
		}
</style>