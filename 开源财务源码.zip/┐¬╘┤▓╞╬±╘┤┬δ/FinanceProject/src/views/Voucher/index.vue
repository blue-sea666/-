<template>
    <el-form ref="voucherform" :rules="rules" :model="formlist" label-width="120px" class="forminput" style="width:100%;height:40px;margin-left:-60px;">
    
      <div style="float:left;">
        <el-form-item label="日期：" prop="voucherdate" class="sernameval"> 
            <el-date-picker
            v-model="formlist.voucherdate"
            @change="getvoucherCode"
            type="date"
            placeholder="请选择日期" style="width:300px;float:left;padding-left:5px;"
          ></el-date-picker>
        </el-form-item>
      </div>
      <div style="float:left;">
        <el-form-item label="凭证号："> 
          <el-input class="sernameval" v-model="formlist.vouchercode" :disabled="true" style="width:300px;float:left;"></el-input>
        </el-form-item>
      </div>
    </el-form>
    <div style="width:320px;">
      <el-button type="primary" plain  @click="add_twoTableDelete" class="btnbutton">添加</el-button>
      <el-button type="primary" plain  @click="savedatlist" class="btnbutton" style="margin-left:10px;">保存</el-button>
    </div>
    <el-dialog title="客户信息" v-model="dialogTableVisibleCustomer" center :append-to-body='true' :close-on-click-modal="false" @close="closePointDialog" :lock-scroll="true" width="52%" height="500px">
      <div style="width:320px;float:left;">
        <el-input v-model="customernamevalue" class="sernameval" placeholder="请输入名称" />
      </div>
       <div style="width:120px;float:left;">
        <el-button type="primary" plain  style="margin-top:5px;" @click="customersearchname" class="btnbutton">搜索</el-button>
      </div>
      <div style="width:100%;">
          <el-table
          :data="customertableData"
          @selection-change="customerhandleSelectionChange"
          :row-style="{height:'35px'}"
          :cell-style="{padding:'0px'}"
          border>
          <el-table-column type="selection" width="55" />
          <el-table-column prop="customerName" label="名称" align="center"></el-table-column>
          <el-table-column prop="customerCode" label="编号" align="center"></el-table-column>
          <el-table-column prop="customerContact" label="联系人" align="center"></el-table-column>
          <el-table-column prop="customerTel" label="电话" align="center"></el-table-column>
        </el-table>
        <!-- 分页底部 -->
        <el-pagination 
            @size-change="customerhandleSizeChange"
            @current-change="customerhandleCurrentChange"
            :current-page="customercurrentPage"
            :page-sizes="[5,10,15]"
            :page-size="customerpageSize"
            layout="total,jumper,prev, pager, next,sizes"
            :total="customertotalCount"
        ></el-pagination>
        <div class="examdiv">
          <el-button type="primary" plain  @click="saveCustomer()" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeCustomer()" class="btnbutton">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <el-dialog title="供应商信息" v-model="dialogTableVisibleSupplier" center :append-to-body='true' :close-on-click-modal="false" @close="closePointDialog" :lock-scroll="true" width="52%" height="500px">
      <div style="width:320px;float:left;">
        <el-input v-model="suppliernamevalue" class="sernameval" placeholder="请输入名称" />
      </div>
      <div style="width:120px;float:left;">
        <el-button type="primary" plain  style="margin-top:5px;" @click="suppliersearchname" class="btnbutton">搜索</el-button>
      </div>
      <div style="width:100%;">
          <el-table
          :data="suppliertableData"
          @selection-change="supplierhandleSelectionChange"
          :row-style="{height:'35px'}"
          :cell-style="{padding:'0px'}"
          border>
          <el-table-column type="selection" width="55" />
          <el-table-column prop="supplierName" label="名称" align="center"></el-table-column>
          <el-table-column prop="supplierCode" label="编号" align="center"></el-table-column>
          <el-table-column prop="supplierContact" label="联系人" align="center"></el-table-column>
          <el-table-column prop="supplierTel" label="电话" align="center"></el-table-column>
        </el-table>
        <!-- 分页底部 -->
        <el-pagination 
            @size-change="supplierhandleSizeChange"
            @current-change="supplierhandleCurrentChange"
            :current-page="suppliercurrentPage"
            :page-sizes="[5,10,15]"
            :page-size="supplierpageSize"
            layout="total,jumper,prev, pager, next,sizes"
            :total="suppliertotalCount"
        ></el-pagination>
        <div class="examdiv">
          <el-button type="primary" plain  @click="saveSupplier()" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeSupplier()" class="btnbutton">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <div style="width:100%;">
      <el-table
      :data="tableData"
      show-summary
      :summary-method="getSummaries"
      :row-style="{height:'35px'}"
      :cell-style="{padding:'0px'}"
      border>
      <el-table-column prop="summaryName" label="摘要" align="center" class="tbline" width="180">
        <template #default="scope">
            <el-input v-model="scope.row.summaryName" class="sernameval"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="subjectName" label="科目" align="center" class="tbline">
        <template #default="scope">
            <el-input v-model="scope.row.subjectName" @click="getSubject(scope.row)"  class="sernameval"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="debitMoney" label="借方金额" align="center" class="tbline">
        <template #default="scope">
            <el-input v-model="scope.row.debitMoney" class="sernameval" type="number"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="lenderMoney" label="贷方金额" align="center" class="tbline">
        <template #default="scope">
            <el-input v-model="scope.row.lenderMoney" class="sernameval" type="number"></el-input>
        </template>
      </el-table-column>
       <el-table-column prop="customerName" label="客户" v-if="customerShow" align="center" class="tbline">
        <template #default="scope">
            <el-input v-model="scope.row.customerName" @click="getCustomer(scope.row)" class="sernameval"></el-input>
        </template>
      </el-table-column>
       <el-table-column prop="supplierName" label="供应商" v-if="supplierShow" align="center" class="tbline">
        <template #default="scope">
            <el-input v-model="scope.row.supplierName" @click="getSupplier(scope.row)" class="sernameval"></el-input>
        </template>
      </el-table-column>
      <el-table-column
        fixed="right"
        label="操作">
        <template #default="scope">
          <el-button @click="handleDelete(scope.$index)"  plain type="danger" class="btnbutton" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <el-dialog title="科目信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  width="40%" height="800px">
      <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
      <el-tab-pane label="资产">
        <el-tree style="overflow-y: auto;height:350px;"
            ref="treeRef"
            class="filter-tree"
            :data="treeAssetsDatalist"
            node-key="id"
             @node-click="handleNodeAssetsClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
      <el-tab-pane label="负债">
        <el-tree style="overflow-y: auto;height:350px;"
            ref="treeRef"
            class="filter-tree"
            :data="treeDebtDatalist"
            node-key="id"
             @node-click="handleNodeDebtClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
      <el-tab-pane label="共同">
        <el-tree
            ref="treeRef"
            class="filter-tree"
            :data="treeCommonDatalist"
            node-key="id"
             @node-click="handleNodeCommonClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
      <el-tab-pane label="权益">
       <el-tree style="overflow-y: auto;height:350px;"
            ref="treeRef"
            class="filter-tree"
            :data="treeIntersDatalist"
            node-key="id"
             @node-click="handleNodeIntersClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
      <el-tab-pane label="成本">
         <el-tree style="overflow-y: auto;height:350px;"
            ref="treeRef"
            class="filter-tree"
            :data="treeCostDatalist"
            node-key="id"
             @node-click="handleNodeCostClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
      <el-tab-pane label="损益">
        <el-tree style="overflow-y: auto;height:350px;"
            ref="treeRef"
            class="filter-tree"
            :data="treeLossDatalist"
            node-key="id"
             @node-click="handleNodeLossClick"
            :filter-node-method="filterNode">
        </el-tree>
      </el-tab-pane>
    </el-tabs>
  </el-dialog>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getAccountsSubjectList,addVoucher,addVoucherDetail,getSupplierList,getCustomerList} from '@/api/system';
import { async } from "q";
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const voucherform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [
              {
                summaryName: '',
                subjectId:'',
                subjectName: '',
                debitMoney: 0,
                lenderMoney:0,
                currentsubjectId:'',
                customerId:'',
                customerName:'',
                supplierId:'',
                supplierName:'',
                accountsId:""
              },
              {
                summaryName: '',
                subjectId:'',
                subjectName: '',
                debitMoney: 0,
                lenderMoney:0,
                currentsubjectId:'',
                customerId:'',
                customerName:'',
                supplierId:'',
                supplierName:'',
                accountsId:""
              },
              {
                summaryName: '',
                subjectId:'',
                subjectName: '',
                debitMoney: 0,
                lenderMoney:0,
                currentsubjectId:'',
                customerId:'',
                customerName:'',
                supplierId:'',
                supplierName:'',
                accountsId:""
              },
              {
                summaryName: '',
                subjectId:'',
                subjectName: '',
                debitMoney: 0,
                lenderMoney:0,
                currentsubjectId:'',
                customerId:'',
                customerName:'',
                supplierId:'',
                supplierName:'',
                accountsId:""
              },
              {
                summaryName: '',
                subjectId:'',
                subjectName: '',
                debitMoney: 0,
                lenderMoney:0,
                currentsubjectId:'',
                customerId:'',
                customerName:'',
                supplierId:'',
                supplierName:'',
                accountsId:""
              }
            ],
            Assetsdatas:[],
            treeAssetsDatalist:[],
            Debtdatas:[],
            treeDebtDatalist:[],
            Commondatas:[],
            treeCommonDatalist:[],
            Intersdatas:[],
            treeIntersDatalist:[],
            Costdatas:[],
            treeCostDatalist:[],
            Lossdatas:[],
            treeLossDatalist:[],
            dialogTableVisible:false,
            formlist:{
              voucherdate:"",
              vouchercode:"",
              customerid:"",
              customername:"",
              supplierid:"",
              suppliername:""
            },
            rules:{
                voucherdate: [{ required: true, message: '请选择日期', trigger: 'blur' }]
            },
            currentRow:"",
            dataArrayAssetslist:[],
            dataArrayDebtlist:[],
            dataArrayCommonlist:[],
            dataArrayInterslist:[],
            dataArrayCostlist:[],
            dataArrayLosslist:[],
            indexAssetsval:0,
            indexDebtval:0,
            indexCommonval:0,
            indexIntersval:0,
            indexCostval:0,
            indexLossval:0,
            customerShow:false,
            supplierShow:false,
            dialogTableVisibleCustomer:false,
            dialogTableVisibleSupplier:false,
            customertableData: [],
            customercurrentPage:1,
            customerpageSize:10,
            customertotalCount:0,
            suppliertableData: [],
            suppliercurrentPage:1,
            supplierpageSize:10,
            suppliertotalCount:0,
            customernamevalue:"",
            suppliernamevalue:""
        })
        onMounted(() => {
          getAccountsSubjectListAssetsArray();
          getAccountsSubjectListDebtArray();
          getAccountsSubjectListCommonArray();
          getAccountsSubjectListIntersArray();
          getAccountsSubjectListCostArray();
          getAccountsSubjectListLossArray();
          getSupplierListArry();
          getCustomerListArry();
        })
        //新增表格
        const add_twoTableDelete=()=>{
          state.tableData.push({
              summaryName: '',
              subjectId:'',
              subjectName: '',
              debitMoney: 0,
              lenderMoney:0,
              currentsubjectId:'',
              customerId:'',
              customerName:'',
              supplierId:'',
              supplierName:'',
              accountsId:""
          })
        }
        const getCustomer=(row)=>{
          state.formlist.customerid="";
          state.formlist.customername="";
          state.dialogTableVisibleCustomer=true;
          state.currentRow=row;
        }
        const closeCustomer=()=>{
          state.dialogTableVisibleCustomer=false;
        }
        const saveCustomer=()=>{
          if(state.currentRow.customerId==""){
            ElMessage({
              type: 'info',
              message: '请选择客户',
            })
          }else{
            state.dialogTableVisibleCustomer=false;
          }
        }
        const closeSupplier=()=>{
          state.dialogTableVisibleSupplier=false;
        }
        const saveSupplier=()=>{
          if(state.currentRow.supplierId==""){
            ElMessage({
              type: 'info',
              message: '请选择供应商',
            })
          }else{
            state.dialogTableVisibleSupplier=false;
          }
        }
        const getSupplier=()=>{
          state.formlist.supplierid="";
          state.formlist.suppliername="";
          state.dialogTableVisibleSupplier=true;
          state.currentRow=row;
        }
        const savedatlist=async()=>{
          const form = unref(voucherform);//获取验证规则
          let cuurentDay=myTimeToLocal(getTimeToLocal(state.formlist.voucherdate))+getCurrentNowTime();
          if (!form) return
          try {
            await form.validate();//表单验证
            var param={
              accountsId:localStorage.getItem('accountsId'),
              voucherCode:state.formlist.vouchercode,
              voucherName:localStorage.getItem('userId'),
              voucherStatus:0,
              voucherTime:cuurentDay,
              customerId:state.formlist.customerid,
              supplierId:state.formlist.supplierid
            }
            let res=await addVoucher(param);
              if(res.code==20000){
                let currentVoucherId=res.data.voucherId;
                for(let index=0; index<state.tableData.length; index++){
                  state.tableData[index]={
                    voucherId: currentVoucherId,
                    summaryName: state.tableData[index].summaryName,
                    subjectId:state.tableData[index].subjectId,
                    subjectName: state.tableData[index].subjectName,
                    lenderMoney: state.tableData[index].lenderMoney,
                    debitMoney: state.tableData[index].debitMoney,
                    currentsubjectId:state.tableData[index].currentsubjectId,
                    customerId: state.tableData[index].customerId,
                    supplierId:state.tableData[index].supplierId,
                    accountsId:localStorage.getItem('accountsId')
                  } 
              }
              if(state.tableData.length>0){
                for(let index=0; index<state.tableData.length; index++){
                  if(state.tableData[index].subjectId==""){
                    ElMessage({
                      type: 'info',
                      message: '存在空行，请重新录入！',
                    })
                    return;
                  }
                }
              }
              let msg=await addVoucherDetail(state.tableData);
              if(msg.code=20000){
                state.tableData=[];
                state.formlist.voucherdate="";
                state.formlist.vouchercode="";
                ElMessage({
                  type: 'success',
                  message: '保存成功',
                })
              }
            }
          }catch (error) {

          }
        }
        const customerhandleSelectionChange = (val) => {
          state.currentRow.customerId=val[0].id;
          state.currentRow.customerName=val[0].customerName;
        }
        const supplierhandleSelectionChange = (val) => {
          state.currentRow.supplierId=val[0].id;
          state.currentRow.supplierName=val[0].supplierName;
        }
        const customersearchname=()=>{
          getCustomerListArry();
        }
        const suppliersearchname=()=>{
          getSupplierListArry();
        }
        const getCustomerListArry=async()=>{
          var paramdata={
            pageNum:state.customercurrentPage,
            pageSize:state.customerpageSize,
            customerName:state.customernamevalue
          }
          let res=await getCustomerList(paramdata);
          if(res.code==200){
            state.customertableData=res.data.records;
            state.customertotalCount=res.data.total;
          }
        }
        const getSupplierListArry=async()=>{
          var paramdata={
            pageNum:state.suppliercurrentPage,
            pageSize:state.supplierpageSize,
            supplierName:state.suppliernamevalue
          }
          let res=await getSupplierList(paramdata);
          if(res.code==200){
            state.suppliertableData=res.data.records;
            state.suppliertotalCount=res.data.total;
          }
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const supplierhandleSizeChange = (size) => {
           state.supplierpageSize = size;
           getSupplierListArry();
        }
         // 控制页面的切换
        const supplierhandleCurrentChange = (currentPage) => {
            state.suppliercurrentPage = currentPage;
            getSupplierListArry();
        }
         //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const customerhandleSizeChange = (size) => {
           state.customerpageSize = size;
           getCustomerListArry();
        }
         // 控制页面的切换
        const customerhandleCurrentChange = (currentPage) => {
            state.customercurrentPage = currentPage;
            getCustomerListArry();
        }
        const getSubject=(row)=>{
          state.currentRow=row;
          state.dialogTableVisible=true;
          //  row.pay_money=row.sett_weight*row.pur_price;
        }
        const getvoucherCode=()=>{
          let currentTime=state.formlist.voucherdate;
          state.formlist.vouchercode=getTimeNum(currentTime);
        }
        const myTimeToLocal=(inputTime)=>{
         
          inputTime = inputTime.replace(" 00:00:00","");
          return inputTime;
        }
        const getTimeToLocal=(inputTime)=>{
          if(!inputTime && typeof inputTime !== 'number'){
            return '';
          }
          var localTime = '';
          inputTime = new Date(inputTime).getTime();
          const offset = (new Date()).getTimezoneOffset();
          localTime = (new Date(inputTime - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
        const getCurrentNowTime=()=>{
          let hh =  new Date().getHours()<10 ? '0'+new Date().getHours() : new Date().getHours();
    　　  let mf = new Date().getMinutes()<10 ? '0'+new Date().getMinutes() : new Date().getMinutes();
    　　  let ss = new Date().getSeconds()<10 ? '0'+new Date().getSeconds() : new Date().getSeconds();
          return " "+hh+":"+mf+":"+ss;
        }
        const getTimeNum =(timenum) =>{
          const projectTime = new Date() // 当前中国标准时间
          const Year = projectTime.getFullYear() // 获取当前年份 支持IE和火狐浏览器.
          const Month = projectTime.getMonth() + 1 // 获取中国区月份
          const Day = projectTime.getDate() // 获取几号
          const Hour = projectTime.getHours() // 获取小时
          const Minute = projectTime.getMinutes() // 获取分钟
          const Second = projectTime.getSeconds() // 获取秒
          var timenum = getTimeToLocal(timenum).replace("-","").replace("-","").replace(" 00:00","").replace(":","").replace("000","");
          if (Month >= 10) { // 判断月份和几号是否大于10或者小于10
            timenum += Month
          } else {
            timenum += '0' + Month
          }
          if (Day >= 10) {
            timenum += Day+Hour
          } else {
            timenum += '0' + Day+Hour
          }
          return "凭-"+timenum;
        }
         const handleDelete=(index)=> {
          state.tableData.splice(index, 1);
        }
         
        //递归子节点
        const data2treeDGNode= async(datas, dataArray,type)=> {
              for (let j = 0; j < dataArray.length; j++) {
                let dataArrayIndex = dataArray[j];
                let childrenArray = [];
                let id = dataArrayIndex.pid;
                for (let i = 0; i < datas.length; i++) {
                  let data = datas[i];
                  if(true){
                    let pId = data.subjectId;
                    if (pId == id) {//判断是否为儿子节点
                      if(type=="1"){
                        state.indexAssetsval=state.indexAssetsval+1;
                      }
                      if(type=="2"){
                          state.indexDebtval=state.indexDebtval+1;
                      }
                      if(type=="3"){
                          state.indexCommonval=state.indexCommonval+1;
                      }
                      if(type=="4"){
                          state.indexIntersval=state.indexIntersval+1;
                      }
                      if(type=="5"){
                          state.indexCostval=state.indexCostval+1;
                      }
                      if(type=="6"){
                          state.indexLossval=state.indexLossval+1;
                      }
                      let objTemp = {
                        id: data.subjectId,
                        label:data.subjectName,
                        pid:data.pid,
                        num:state.indexval
                      }
                      dataArray.push(objTemp);
                    }
                  }
              }
              dataArrayIndex= dataArray;
              if (childrenArray.length > 0) {
                //有儿子节点则递归
                  data2treeDGNode(datas, childrenArray)
              }
            }
        }
              //遍历父节点
        const getListData =(datalist,type)=> {
          let dataArray = [];
          datalist.forEach(function (data) {
            if(true){
              let Pid = data.pid;
              if (Pid == "0") {
                let objTemp = {
                  id: data.subjectId,
                  label: data.subjectName,
                  pid: Pid,
                  accountstatus:data.accountStatus
                }
                dataArray.push(objTemp);
              }
            }
          })
          data2treeDG(datalist, dataArray,type)
        }
        //递归子节点
        const data2treeDG=(datas, dataArray,type)=>{
          for (let j = 0; j < dataArray.length; j++) {
            let dataArrayIndex = dataArray[j];
            let childrenArray = [];
            let id = dataArrayIndex.id;
            for (let i = 0; i < datas.length; i++) {
              let data = datas[i];
              if(true){
                let pId = data.pid;
                if (pId == id) {//判断是否为儿子节点
                  let objTemp = {
                    id: data.subjectId,
                    label: data.subjectName,
                    pid: pId,
                    accountstatus:data.accountStatus
                  }
                  childrenArray.push(objTemp);
                }
              }
            }
            dataArrayIndex.children = childrenArray;
            if (childrenArray.length > 0) {
                //有儿子节点则递归
                data2treeDG(datas, childrenArray,type)
              }
          }
          if(type=="1"){
            state.treeAssetsDatalist = dataArray;
          }
          if(type=="2"){
            state.treeDebtDatalist = dataArray;
          }
          if(type=="3"){
            state.treeCommonDatalist = dataArray;
          }
          if(type=="4"){
            state.treeIntersDatalist = dataArray;
          }
          if(type=="5"){
            state.treeCostDatalist = dataArray;
          }
          if(type=="6"){
            state.treeLossDatalist = dataArray;
          }
        }
         //加载结算明细列表
        const getAccountsSubjectListAssetsArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:1
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Assetsdatas=res.data.records;
            getListData(state.Assetsdatas,"1");
          }
        }
         //加载结算明细列表
        const getAccountsSubjectListDebtArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:2
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Debtdatas=res.data.records;
            getListData(state.Debtdatas,"2");
          }
        }
        const getSummaries = (param) => {
          const { columns, data } = param
          const sums = []
          columns.forEach((column, index) => {
            if (index === 1||index==0||index==4||index==5) {
              if(index===0){
                sums[index] = '合计'
                return
              }
              if(index===1){
                sums[index] = ''
                return
              }
              if(index===4){
                sums[index] = ''
                return
              }
              if(index===5){
                sums[index] = ''
                return
              }
            }
            const values = data.map((item) => Number(item[column.property]))
            if (!values.every((value) => Number.isNaN(value))) {
              sums[index] = ` ${values.reduce((prev, curr) => {
                const value = Number(curr)
                if (!Number.isNaN(value)) {
                  return prev + curr
                } else {
                  return prev
                }
              }, 0)}`
            } else {
              sums[index] = 'N/A'
            }
          })

          return sums
        }

         //加载结算明细列表
        const getAccountsSubjectListCommonArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:3
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Commondatas=res.data.records;
            getListData(state.Commondatas,"3");
          }
        }
         //加载结算明细列表
        const getAccountsSubjectListIntersArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:4
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Intersdatas=res.data.records;
            getListData(state.Intersdatas,"4");
          }
        }
         //加载结算明细列表
        const getAccountsSubjectListCostArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:5
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Costdatas=res.data.records;
            getListData(state.Costdatas,"5");
          }
        }
         //加载结算明细列表
        const getAccountsSubjectListLossArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            accountsId:localStorage.getItem('accountsId'),
            subjectType:6
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.Lossdatas=res.data.records;
            getListData(state.Lossdatas,"6");
          }
        }
        const handleNodeAssetsClick = (node) => {
          console.log(node);
          if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
          // if(node.accountstatus==0){
          //   state.supplierShow=false;
          //   state.customerShow=false;
          // }
          let expancurrentid=node.pid;
          state.dataArrayAssetslist = [];
          state.Assetsdatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexAssetsval=state.indexAssetsval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexAssetsval
                  }
                  state.dataArrayAssetslist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Assetsdatas, state.dataArrayAssetslist,"1");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayAssetslist.length;index++){
              let currentindex=state.dataArrayAssetslist.length-index;
              console.log(currentindex);
              subjectIdstr=subjectIdstr+state.dataArrayAssetslist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayAssetslist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        const handleNodeDebtClick = (node) => {
          
          if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
        
          let expancurrentid=node.pid;
          state.dataArrayDebtlist = [];
          state.Debtdatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexDebtval=state.indexDebtval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexDebtval
                  }
                  state.dataArrayDebtlist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Debtdatas, state.dataArrayDebtlist,"2");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayDebtlist.length;index++){
              let currentindex=state.dataArrayDebtlist.length-index;
              console.log(currentindex);
              subjectIdstr=subjectIdstr+state.dataArrayDebtlist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayDebtlist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        const handleNodeCommonClick = (node) => {
           if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
          // if(node.accountstatus==0){
          //   state.supplierShow=false;
          //   state.customerShow=false;
          // }
          let expancurrentid=node.pid;
          state.dataArrayCommonlist = [];
          state.Commondatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexCommonval=state.indexCommonval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexCommonval
                  }
                  state.dataArrayCommonlist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Commondatas, state.dataArrayCommonlist,"3");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayCommonlist.length;index++){
              let currentindex=state.dataArrayCommonlist.length-index;
              console.log(currentindex);
              subjectIdstr=subjectIdstr+state.dataArrayCommonlist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayCommonlist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        const handleNodeIntersClick = (node) => {
          console.log(node);
          if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
          // if(node.accountstatus==0){
          //   state.supplierShow=false;
          //   state.customerShow=false;
          // }
          let expancurrentid=node.pid;
          state.dataArrayInterslist = [];
          state.Intersdatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexIntersval=state.indexIntersval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexIntersval
                  }
                  state.dataArrayInterslist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Intersdatas, state.dataArrayInterslist,"4");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayInterslist.length;index++){
              let currentindex=state.dataArrayInterslist.length-index;
              subjectIdstr=subjectIdstr+state.dataArrayInterslist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayInterslist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        const handleNodeCostClick = (node) => {
          if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
          // if(node.accountstatus==0){
          //   state.supplierShow=false;
          //   state.customerShow=false;
          // }
          let expancurrentid=node.pid;
          state.dataArrayCostlist = [];
          state.Costdatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexCostval=state.indexCostval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexCostval
                  }
                  state.dataArrayCostlist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Costdatas, state.dataArrayCostlist,"5");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayCostlist.length;index++){
              let currentindex=state.dataArrayCostlist.length-index;
              subjectIdstr=subjectIdstr+state.dataArrayCostlist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayCostlist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        const handleNodeLossClick = (node) => {
           console.log(node);
           if(node.children.length>0){
            return;
          }
          if(node.accountstatus==1){
            state.customerShow=true;
          }
          if(node.accountstatus==2){
            state.supplierShow=true;
          }
          // if(node.accountstatus==0){
          //   state.supplierShow=false;
          //   state.customerShow=false;
          // }
          let expancurrentid=node.pid;
          state.dataArrayLosslist = [];
          state.Lossdatas.forEach(function (data) {
            if(true){
              let assetsid = data.subjectId;
              if (assetsid == expancurrentid) {
                  state.indexLossval=state.indexLossval+1;
                  let objTemp = {
                    id: data.subjectId,
                    label:data.subjectName,
                    pid:data.pid,
                    num:state.indexLossval
                  }
                  state.dataArrayLosslist.push(objTemp);
              }
            }
          })
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          data2treeDGNode(state.Lossdatas, state.dataArrayLosslist,"6");
          let subjectIdstr="";
          let subjectNamestr="";
          //state.dataArraylist.sort();
          //state.dataArraylist.push({id:node.id,label:node.label,pid:node.pid});
          for(var index=1;index<=state.dataArrayLosslist.length;index++){
              let currentindex=state.dataArrayLosslist.length-index;
              subjectIdstr=subjectIdstr+state.dataArrayLosslist[currentindex].id+",";
              subjectNamestr=subjectNamestr+state.dataArrayAssetsLosslist[currentindex].label+"...";
          }
          state.currentRow.subjectId="";
          state.currentRow.subjectName="";
          state.currentRow.subjectId=subjectIdstr+node.id;
          state.currentRow.subjectName=subjectNamestr+node.label;
          state.currentRow.currentsubjectId=node.id;
          state.dialogTableVisible=false;
          // console.log(subjectIdstr+node.id);
          // console.log(subjectNamestr+node.label);
        }
        return {
            ...toRefs(state),
            add_twoTableDelete,
            getTimeNum,
            myTimeToLocal,
            getvoucherCode,
            handleDelete,
            getListData,
            data2treeDG,
            getSubject,
            data2treeDGNode,
            voucherform,
            savedatlist,
            getTimeToLocal,
            getAccountsSubjectListAssetsArray,
            getAccountsSubjectListDebtArray,
            getAccountsSubjectListCommonArray,
            getAccountsSubjectListIntersArray,
            getAccountsSubjectListCostArray,
            getAccountsSubjectListLossArray,
            handleNodeLossClick,
            handleNodeCostClick,
            handleNodeAssetsClick,
            handleNodeDebtClick,
            handleNodeCommonClick,
            handleNodeIntersClick,
            getSummaries,
            getSupplierListArry,
            supplierhandleSizeChange,
            supplierhandleCurrentChange,
            customerhandleSizeChange,
            customerhandleCurrentChange,
            getCustomerListArry,
            customersearchname,
            suppliersearchname,
            getCustomer,
            getSupplier,
            closeSupplier,
            saveSupplier,
            closeCustomer,
            saveCustomer,
            customerhandleSelectionChange,
            supplierhandleSelectionChange,
            getCurrentNowTime
        }
    }
}
</script>
<style>
.userdiv{
  margin-bottom: 13px;
}
.btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
.el-scrollbar__wrap {
    overflow-x: hidden!important;
}
.examdiv{
    text-align: center;
    margin-top: 20px;
}
</style>