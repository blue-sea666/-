<template>
    <h2>智能财务云管理平台</h2>
</template>
<script lang="ts">
import{ defineComponent,toRefs,reactive, onMounted,ref,watch,unref }from 'vue';
export default defineComponent({
    name: "Home",
    setup: () => {
        onMounted(() => { 
            setTimeout(() => {
                location.reload();
            }, 300);
        })
        return {
        };
    }
})
</script>
<style scoped>
    h2{
        font-size:20px;
    }
    div{
        padding:10px;
        color:#fc0;
        font-size:18px;
    }
</style>