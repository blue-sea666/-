<template>
    <div style="width:620px;float:left;">
        <el-input v-model="namevalue" class="sernameval" style="width:70%;" placeholder="请输入名称" />
        <el-button type="primary"  plain  @click="searchname" class="btnbutton">搜索</el-button>
        <el-button type="primary" plain   @click="addcustomer" style="margin-left:10px;" class="btnbutton">添加</el-button>
    </div>
    <div style="width:100%;">
        <el-table
        :data="tableData"
        :row-style="{height:'35px'}"
        :cell-style="{padding:'0px'}"
        border>
        <el-table-column prop="customerName" label="名称" align="center"></el-table-column>
        <el-table-column prop="customerCode" label="编号" align="center"></el-table-column>
        <el-table-column prop="customerContact" label="联系人" align="center"></el-table-column>
        <el-table-column prop="customerTel" label="电话" align="center"></el-table-column>
        <el-table-column prop="customerStatus" label="状态" align="center">
           <template #default="scope">
             <span v-if="scope.row.customerStatus == 1">启用</span>
             <span v-if="scope.row.customerStatus ==0">停用</span>
          </template>
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作">
          <template #default="scope">
            <el-button @click="handleEdit(scope.$index, scope.row)" plain  type="primary" size="small" class="btnbutton">编辑</el-button>
            <el-button @click="handleDelete(scope.$index, scope.row)" plain  type="danger" size="small" class="btnbutton">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页底部 -->
      <el-pagination 
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5,10,15]"
          :page-size="pageSize"
          layout="total,jumper,prev, pager, next,sizes"
          :total="totalCount"
      ></el-pagination>
    </div>
    <el-dialog title="客户信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="60%" height="800px">
      <el-form :rules="rules" :model="customerlist" ref="customerform" label-width="120px">
        <div style="width:100%;">
            <el-form-item label="客户名称：" prop="customername" style="width:50%;float:left;">
              <el-input v-model="customerlist.customername" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="客户编号：" prop="customercode" style="width:50%;float:right;">
              <el-input v-model="customerlist.customercode" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="联系人：" prop="customercontact" style="width:50%;float:left;">
              <el-input v-model="customerlist.customercontact" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="电话：" prop="customertel" style="width:50%;float:right;">
              <el-input v-model="customerlist.customertel" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="邮箱：" prop="customeremail" style="width:50%;float:left;">
              <el-input v-model="customerlist.customeremail" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="地址：" prop="customeraddr" style="width:50%;float:right;">
              <el-input v-model="customerlist.customeraddr" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="状态：" prop="customerstatus" style="width:50%;float:left;">
              <el-select v-model="customerlist.customerstatus" class="sernameval" @change="changeStatus($event)" placeholder="请选择">
                <el-option
                 v-for="(item,index) in customerstatuslist"
                 :key="item.value"
                 :label="item.label"
                 :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="备注：" prop="customerremark" style="width:50%;float:right;">
              <el-input v-model="customerlist.customerremark" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div class="examdiv">
          <el-button type="primary" plain   @click="saveCustomer" class="btnbutton">保存</el-button>
          <el-button type="primary" plain   @click="closeCustomer" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getCustomerList,updateCustomer,addCustomer,deleteCustomer} from '@/api/system';
import { async } from "q";
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const customerform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            isEdit:false,
            namevalue:"",
            customerlist:{
                customerid:"",
                customername:"",
                customercode:"",
                customercontact:"",
                customertel:"",
                customeremail:"",
                customeraddr:"",
                customerstatus:"",
                customerstatusvalue:"",
                customerremark:""
            },
             customerstatuslist:[
              {
                  value: '0',
                  label: '停用'
                }, {
                  value: '1',
                  label: '启用'
                }
            ],
            dialogTableVisible:false,
            rules:{
                customername: [{ required: true, message: '请输入客户名称', trigger: 'blur' }]
            }
        })
        onMounted(() => {
          getCustomerListArry();
        })
        const changeStatus=(e)=>{
          state.customerlist.customerstatusvalue=e;
        }
        //加载仓库列表
        const getCustomerListArry=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            customerName:state.namevalue
          }
          let res=await getCustomerList(paramdata);
          if(res.code==200){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        //新增表格
        const addcustomer=()=>{
          clearform();
          state.isEdit=false;
          state.dialogTableVisible=true;
        }
        //关闭对话框
        const closeCustomer=()=>{
          state.dialogTableVisible=false;
        }
        //保存
        const saveCustomer=async()=>{
          const form = unref(customerform);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param = {
              id: state.customerlist.customerid,
              customerAddr: state.customerlist.customeraddr,
              customerCode: state.customerlist.customercode,
              customerContact: state.customerlist.customercontact,
              customerEmail: state.customerlist.customeremail,
              customerName: state.customerlist.customername,
              customerRemark: state.customerlist.customerremark,
              customerStatus: state.customerlist.customerstatusvalue,
              customerTel: state.customerlist.customertel
            }
            if(!state.isEdit){
              let msg=await addCustomer(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '保存成功',
                })
                state.dialogTableVisible=false;
                getCustomerListArry();
              }
            }else{
              let msg=await updateCustomer(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '修改成功',
                })
                state.dialogTableVisible=false;
                getCustomerListArry();
              }
            }
          }catch (error) {

          }
        }
        const searchname=()=>{
          getCustomerListArry();
        }
        //删除
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.id);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        //编辑
        const handleEdit=(index,row)=>{
          console.log(row);
          state.isEdit=true;
          state.customerlist.customerid=row.id;
          state.customerlist.customeraddr=row.customerAddr;
          state.customerlist.customercode=row.customerCode;
          state.customerlist.customercontact=row.customerContact;
          state.customerlist.customeremail=row.customerEmail;
          state.customerlist.customername=row.customerName;
          state.customerlist.customerremark=row.customerRemark;
          state.customerlist.customerstatusvalue=row.customerStatus;
          if(row.customerStatus=="1"){
            state.customerlist.customerstatus="启用";
          }
          if(row.customerStatus=="0"){
            state.customerlist.customerstatus="停用";
          }
          state.customerlist.customertel=row.customerTel;
          state.dialogTableVisible=true;
        }
        const deleteDataById=async(rowid)=>{
           var param={
             id:rowid
           }
           let res=await deleteCustomer(param);
            if(res.code==20000){
              getCustomerListArry();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        //清楚表单的值
        const clearform=()=>{
          state.customerlist.customerid="";
          state.customerlist.customeraddr="";
          state.customerlist.customercode="";
          state.customerlist.customercontact="";
          state.customerlist.customeremail="";
          state.customerlist.customername="";
          state.customerlist.customerremark="";
          state.customerlist.customertel="";
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getCustomerListArry();
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getCustomerListArry();
        }
        return {
            ...toRefs(state),
            addcustomer,
            handleDelete,
            customerform,
            closeCustomer,
            saveCustomer,
            getCustomerListArry,
            handleCurrentChange,
            handleSizeChange,
            handleEdit,
            clearform,
            deleteDataById,
            searchname,
            changeStatus
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width: 100%;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.btndel.el-button--primary{
    height: 28px;
    color: #fff;
  }
  .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.examdiv{
    text-align: center;
}
.sernameval{
  width: 80%;
}

 .sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    padding: 0 15px;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
</style>