<template>
    <div style="width:620px;float:left;">
        <el-input v-model="namevalue" class="sernameval" style="width:70%;" placeholder="请输入名称" />
        <el-button type="primary" plain   @click="searchname" class="btnbutton">搜索</el-button>
        <el-button type="primary" plain   @click="addsupplier" style="margin-left:10px;" class="btnbutton">添加</el-button>
    </div>
    <div style="width:100%;">
        <el-table
        :data="tableData"
        :row-style="{height:'35px'}"
        :cell-style="{padding:'0px'}"
        border>
        <el-table-column prop="supplierName" label="名称" align="center"></el-table-column>
        <el-table-column prop="supplierCode" label="编号" align="center"></el-table-column>
        <el-table-column prop="supplierContact" label="联系人" align="center"></el-table-column>
        <el-table-column prop="supplierTel" label="电话" align="center"></el-table-column>
        <el-table-column prop="supplierStatus" label="状态" align="center">
           <template #default="scope">
             <span v-if="scope.row.supplierStatus == 1">启用</span>
             <span v-if="scope.row.supplierStatus ==0">停用</span>
          </template>
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作">
          <template #default="scope">
            <el-button @click="handleEdit(scope.$index, scope.row)"  plain type="primary" size="small" class="btnbutton">编辑</el-button>
            <el-button @click="handleDelete(scope.$index, scope.row)" plain  type="danger" size="small" class="btnbutton">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页底部 -->
      <el-pagination 
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5,10,15]"
          :page-size="pageSize"
          layout="total,jumper,prev, pager, next,sizes"
          :total="totalCount"
      ></el-pagination>
    </div>
    <el-dialog title="供应商信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="60%" height="800px">
      <el-form :rules="rules" :model="supplierlist" ref="supplierform" label-width="120px">
        <div style="width:100%;">
            <el-form-item label="供应商名称：" prop="suppliername" style="width:50%;float:left;">
              <el-input v-model="supplierlist.suppliername" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="供应商编号：" prop="suppliercode" style="width:50%;float:right;">
              <el-input v-model="supplierlist.suppliercode" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="联系人：" prop="suppliercontact" style="width:50%;float:left;">
              <el-input v-model="supplierlist.suppliercontact" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="电话：" prop="suppliertel" style="width:50%;float:right;">
              <el-input v-model="supplierlist.suppliertel" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="邮箱：" prop="supplieremail" style="width:50%;float:left;">
              <el-input v-model="supplierlist.supplieremail" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="地址：" prop="supplieraddr" style="width:50%;float:right;">
              <el-input v-model="supplierlist.supplieraddr" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="银行账户：" prop="supplierbankcd" style="width:50%;float:left;">
              <el-input v-model="supplierlist.supplierbankcd" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label=开户行： prop="supplierbank" style="width:50%;float:right;">
              <el-input v-model="supplierlist.supplierbank" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div style="width:100%;">
            <el-form-item label="状态：" prop="supplierstatusvalue" style="width:50%;float:left;">
              <el-select v-model="supplierlist.supplierstatus" class="sernameval" @change="changeStatus($event)" placeholder="请选择">
                <el-option
                 v-for="(item,index) in supplierstatuslist"
                 :key="item.value"
                 :label="item.label"
                 :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="备注：" prop="supplierremark" style="width:50%;float:right;">
              <el-input v-model="supplierlist.supplierremark" class="sernameval"></el-input>
            </el-form-item>
        </div>
        <div class="examdiv">
          <el-button type="primary" plain   @click="saveSupplier" class="btnbutton">保存</el-button>
          <el-button type="primary" plain   @click="closeSupplier" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getSupplierList,updateSupplier,addSupplier,deleteSupplier} from '@/api/system';
import { async } from "q";
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const supplierform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            isEdit:false,
            namevalue:"",
            supplierlist:{
                supplierid:"",
                suppliername:"",
                suppliercode:"",
                suppliercontact:"",
                suppliertel:"",
                supplieremail:"",
                supplieraddr:"",
                supplierbankcd:"",
                supplierbank:"",
                supplierstatus:"启用",
                supplierstatusvalue:1,
                supplierremark:""
            },
            supplierstatuslist:[
              {
                  value: '0',
                  label: '停用'
                }, {
                  value: '1',
                  label: '启用'
                }
            ],
            dialogTableVisible:false,
            rules:{
                suppliername: [{ required: true, message: '请输入供应商名称', trigger: 'blur' }]
            }
        })
        onMounted(() => {
          getSupplierListArry();
        })
        //加载仓库列表
        const getSupplierListArry=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            supplierName:state.namevalue
          }
          let res=await getSupplierList(paramdata);
          if(res.code==200){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        //新增表格
        const addsupplier=()=>{
          clearform();
          state.isEdit=false;
          state.dialogTableVisible=true;
        }
        //关闭对话框
        const closeSupplier=()=>{
          state.dialogTableVisible=false;
        }
        //保存
        const saveSupplier=async()=>{
          const form = unref(supplierform);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param = {
              id: state.supplierlist.supplierid,
              supplierAddr: state.supplierlist.supplieraddr,
              supplierBank: state.supplierlist.supplierbank,
              supplierBankcd: state.supplierlist.supplierbankcd,
              supplierCode: state.supplierlist.suppliercode,
              supplierContact: state.supplierlist.suppliercontact,
              supplierEmail: state.supplierlist.supplieremail,
              supplierName: state.supplierlist.suppliername,
              supplierRemark: state.supplierlist.supplierremark,
              supplierStatus: state.supplierlist.supplierstatusvalue,
              supplierTel: state.supplierlist.suppliertel
            }
            if(!state.isEdit){
              let msg=await addSupplier(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '保存成功',
                })
                state.dialogTableVisible=false;
                getSupplierListArry();
              }
            }else{
              let msg=await updateSupplier(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '修改成功',
                })
                state.dialogTableVisible=false;
                getSupplierListArry();
              }
            }
          }catch (error) {

          }
        }
        const searchname=()=>{
          getSupplierListArry();
        }
        const changeStatus=(e)=>{
          state.supplierlist.supplierstatusvalue=e;
        }
        //删除
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.id);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        //编辑
        const handleEdit=(index,row)=>{
          state.isEdit=true;
          state.supplierlist.supplierid=row.id;
          state.dialogTableVisible=true;
          state.supplierlist.suppliername=row.supplierName;
          state.supplierlist.supplieraddr=row.supplierAddr;
          state.supplierlist.supplierbank=row.supplierBank;
          state.supplierlist.supplierbankcd=row.supplierBankcd;
          state.supplierlist.suppliercode=row.supplierCode;
          state.supplierlist.suppliercontact=row.supplierContact;
          state.supplierlist.supplieremail=row.supplierEmail;
          state.supplierlist.supplierremark=row.supplierRemark;
          state.supplierlist.suppliertel=row.supplierTel;
          state.supplierlist.supplierstatusvalue=row.supplierStatus;
          if(row.supplierStatus==1){
            state.supplierlist.supplierstatus="启用";
          }else{
            state.supplierlist.supplierstatus="停用";
          }
        }
        const deleteDataById=async(rowid)=>{
           var param={
             id:rowid
           }
           let res=await deleteSupplier(param);
            if(res.code==20000){
              getSupplierListArry();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        //清楚表单的值
        const clearform=()=>{
          state.supplierlist.supplierid="";
          state.supplierlist.supplieraddr="";
          state.supplierlist.supplierbank="";
          state.supplierlist.supplierbankcd="";
          state.supplierlist.suppliercode="";
          state.supplierlist.suppliercontact="";
          state.supplierlist.supplieremail="";
          state.supplierlist.suppliername="";
          state.supplierlist.supplierremark="";
          state.supplierlist.suppliertel="";
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getSupplierListArry();
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getSupplierListArry();
        }
        return {
            ...toRefs(state),
            addsupplier,
            handleDelete,
            supplierform,
            closeSupplier,
            saveSupplier,
            getSupplierListArry,
            handleCurrentChange,
            handleSizeChange,
            handleEdit,
            clearform,
            deleteDataById,
            searchname,
            changeStatus
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width: 100%;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.btndel.el-button--primary{
    height: 28px;
    color: #fff;
  }
  .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.examdiv{
    text-align: center;
}
.sernameval{
  width: 80%;
}

 .sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    padding: 0 15px;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
</style>