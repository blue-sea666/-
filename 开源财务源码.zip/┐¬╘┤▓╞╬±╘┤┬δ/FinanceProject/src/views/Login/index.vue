<template>
	<div class="login">
		<div class="login-weaper">
			<div class="login-left">
				<div class="login-time">{{ time.txt }}</div>
				<div class="login-left-box">
					<div>
						<div class="logo">行云有道</div>
						<h2 class="title">智能财务云管理平台</h2>
					<div class="msg">
							<div class="msg-author">
								<span>{{ quotations.name }}</span>
								<span>{{ quotations.comeFrom }}</span>
							</div>
							<div class="msg-txt">{{ quotations.content }}</div>
						</div>
					</div>
				</div>
			</div>
			<div class="login-right">
				<div class="login-main">
					<h4 class="login-title">智能财务云管理平台</h4>
					<el-form :rules="rules" :model="formlist" ref="loginform" class="el-form login-form">
						<el-form-item  style="margin-left: 0px" prop="accountsName">
						<el-select v-model="formlist.accountsName"
							 style="width:342px;" @change="changeAccounts($event)" placeholder="请选择">
							<el-option
							v-for="item in optionsvalue"
							:key="item.id"
							:label="item.accountsName"
							:value="item.id">
							</el-option>
						</el-select>
						</el-form-item>
						<el-form-item style="margin-left: 0px" prop="username">
							<el-input
								type="text"
								prefix-icon="el-icon-user"
								v-model="formlist.username"
							>
							</el-input>
						</el-form-item>
						<el-form-item style="margin-left: 0px" prop="password">
							<el-input
								type="password"
								prefix-icon="el-icon-lock"
                				v-model="formlist.password"
								:show-password="true"
							>
							</el-input>
						</el-form-item>
						<el-form-item style="margin: 40px 0px 0">
							<el-button type="primary" class="login-submit" @click="login">
							<span>登陆</span>
							</el-button>
						</el-form-item>
					</el-form>
					<div class="login-menu">
					</div>
				</div>
			</div>
		</div>
		<div class="vue-particles">
			<vue-particles color="#dedede" shapeType="star" linesColor="#dedede" hoverMode="grab" clickMode="push" style="height: 100%"></vue-particles>
		</div>
	</div>
</template>
<script>
import { toRefs,unref,reactive, onMounted,ref  } from "vue";
import {getMenuList,loginUser,getAccountsList} from "@/api/system";
import {ElMessage} from 'element-plus'
import { Store } from "vuex";
import store from "@/store/index";
import { formatDate, formatAxis } from '@/utils/formatTime';
import { quotationsList } from '@/utils/mock';
import { useRouter } from 'vue-router'
export default{
  name: "",
  setup: () => {
    const router = useRouter()
	const loginform =ref(null);
    const state = reactive({
	  formlist:{
		username: "admin",
		password: "12",
		accountsId:"",
		accountsName:""
	  },
	  optionsvalue:[],
      quotationsList,
	  quotations: {},
	  isView: false,
      loading: false,
	  time: {
		txt: '',
		fun: null,
	  },
	  rules:{
        accountsName: [{ required: true, message: '请选择账套', trigger: 'blur' }],
	  }
    });
	 const changeAccounts=(e)=>{
          state.formlist.accountsId=e;
        }
	 const getAccountsListArray=async()=>{
          var paramdata={
            pageNum:1,
            pageSize:100
          }
          let res=await getAccountsList(paramdata);
          if(res.code==20000){
            state.optionsvalue=res.data.records;
          }
        }
    // 随机语录
		const initRandomQuotations=()=> {
			state.quotations = state.quotationsList[Math.floor(Math.random() * state.quotationsList.length)];
		}
		// 初始化左上角时间显示
		const initTime=()=> {
			state.time.txt = formatDate(new Date(), 'YYYY-mm-dd HH:MM:SS WWW QQQQ');
			state.time.fun = setInterval(() => {
				state.time.txt = formatDate(new Date(), 'YYYY-mm-dd HH:MM:SS WWW QQQQ');
			}, 1000);
		}
     let  login =async ()=>{
		 if(state.formlist.accountsId==""){
			  ElMessage({
              type: 'info',
              message: '请先选择账套',
             })
			 return;
		 }
         var loginparam={
           userCode: state.formlist.username,
           userPassword: state.formlist.password
         }
          let msg=await loginUser(loginparam);
          if(msg.data.total>0){
		  	localStorage.setItem('userId',msg.data.records[0].id)
		  	localStorage.setItem('userName',msg.data.records[0].userName)
            ElMessage({
              type: 'success',
              message: '登录成功',
             })
            var param={
              id:msg.data.records[0].id
            }
            let res=await getMenuList(param);
            if(res.code=20000){
              let menu=[];
              menu=res.data.records;
			  localStorage.setItem('accountsId',state.formlist.accountsId)
              localStorage.setItem('v3-element-plus-menu',"")
              localStorage.setItem('v3-element-plus-menu',JSON.stringify(menu))
              localStorage.setItem('v3-element-plus-token',JSON.stringify("data.token"))
              router.replace({
                path: '/'
              })
              //$store.dispatch("GET_ROUTERS_DATA");
            }
          }else{
            ElMessage({
                message: '账号或密码错误登录失败！',
                type: 'info',
            })
          }
        };
    onMounted(() => {
      initRandomQuotations();
      initTime();
	  getAccountsListArray();
	  document.onkeypress = function(e) {
			var keycode = document.all ? event.keyCode : e.which;
			if (keycode == 13) {
				login();// 登录方法名
			}
		}
    });
    return {
      login,
      ...toRefs(state),
      initRandomQuotations,
      initTime,
	  getAccountsListArray,
	  changeAccounts,
	  loginform
    };
  },
};
</script>
<style>
.vue-particles {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: radial-gradient(ellipse at top left, rgba(105, 155, 200, 1) 0%, rgba(181, 197, 216, 1) 57%);
	}
  .login-weaper {
		margin: auto;
		height: 500px;
		display: flex;
		box-sizing: border-box;
		position: relative;
		z-index: 1;
		border: none;
		box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  }
  .login-left {
			width: 491px;
			padding: 20px;
			font-size: 16px;
			color: #fff;
			position: relative;
			background-color: rgba(64, 158, 255, 0.8);
			display: flex;
			flex-direction: column;
			border-top-left-radius: 4px;
			border-bottom-left-radius: 4px;
  }
  .login-time {
				width: 100%;
				color: #fff;
				opacity: 0.9;
				font-size: 20px;
				overflow: hidden;
			}
      .login-left-box {
				flex: 1;
				overflow: hidden;
				position: relative;
				z-index: 1;
				display: flex;
				align-items: center;
				padding: 80px 45px;
				
			
			}
.login {
	height: 100%;
	width: 100%;
	overflow: hidden;
	display: flex;
	position: relative;
	
	
		
			
			
		}
    	.title {
					color: #fff;
					font-weight: 300;
					letter-spacing: 2px;
					font-size: 16px;
				}
				.msg {
					color: #fff;
					font-size: 13px;
					margin-top: 35px;
				
				}
    	.msg-author {
						opacity: 0.6;
					}
					.msg-txt {
						margin-top: 15px;
						line-height: 22px;
					}
          	.login-title {
					color: #333;
					margin-bottom: 40px;
					font-weight: 500;
					font-size: 22px;
					text-align: center;
					letter-spacing: 4px;
				}
        .login-code-img {
								margin-top: 2px;
								width: 100px;
								height: 38px;
								border: 1px solid #dcdfe6;
								color: #333;
								font-size: 14px;
								font-weight: 700;
								letter-spacing: 5px;
								line-height: 38px;
								text-indent: 5px;
								text-align: center;
								cursor: pointer;
								transition: all ease 0.2s;
								border-radius: 4px;
							}
              .login-submit {
							width: 100%;
							height: 45px;
							letter-spacing: 2px;
							font-weight: 300;
						}
            .login-code {
							display: flex;
							align-items: center;
							justify-content: space-around;
							margin: 0 0 0 10px;
							user-select: none;
							
						}
            .el-form-item {
						margin-bottom: 20px !important;
						
						
					}
          .login-form {
					margin: 10px 0;
				}
        	.login-menu {
					margin-top: 30px;
					width: 100%;
					text-align: left;
				}
        .login-main {
				margin: 0 auto;
				width: 70%;
			}
		.login-right {
			width: 491px;
			padding: 20px;
			position: relative;
			align-items: center;
			display: flex;
			background-color: rgba(255, 255, 255, 1);
			border-top-right-radius: 4px;
			border-bottom-right-radius: 4px;
    }
    .logo{
          font-size: 22px;
    margin-bottom: 15px
    }
</style>