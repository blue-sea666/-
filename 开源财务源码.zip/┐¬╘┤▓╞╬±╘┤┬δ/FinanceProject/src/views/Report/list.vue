<template>
    <el-form ref="voucherform" :rules="rules" :model="formlist" label-width="120px" class="forminput" style="width:100%;height:40px;margin-left:-60px;">
      <div style="float:left;width:100%;">
         <el-form-item label="日期：" prop="voucherTime" class="sernameval"> 
            <el-date-picker
            v-model="formlist.voucherTime"
            type="month"
            placeholder="请选择日期" style="width:300px;float:left;padding-left:5px;"
          ></el-date-picker>
          <el-button type="primary" plain  @click="searchVoucher" class="btnbutton" style="margin-left:10px;">查询</el-button>
          <el-button type="primary" plain  class="btnbutton" v-print="'#printTest'" style="margin-left:10px;">打印</el-button>
        </el-form-item>
      </div>
    </el-form>
    <div style="width: 100%" align="center">
      <div id="printTest" style="width: 100%;" align="center">
        <table class="tb" style="width:100%;"> 
          <tbody>
              <tr>
                <td style="text-align:center;">项目</td>
                <td style="text-align:center;">本期余额</td>
                <td style="text-align:center;">本年余额</td>
              </tr>
              <tr>
                <td>一、营业收入</td>
                <td>{{tabinfo.colunm1}}</td>
                <td>{{tabinfo.colunm2}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;减：营业成本</td>
                <td>{{tabinfo.colunm3}}</td>
                <td>{{tabinfo.colunm4}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;营业税金及附加</td>
                <td>{{tabinfo.colunm5}}</td>
                <td>{{tabinfo.colunm6}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;销售费用</td>
                <td>{{tabinfo.colunm7}}</td>
                <td>{{tabinfo.colunm8}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;管理费用</td>
                <td>{{tabinfo.colunm9}}</td>
                <td>{{tabinfo.colunm10}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;研发费用</td>
                <td>{{tabinfo.colunm11}}</td>
                <td>{{tabinfo.colunm12}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;财务费用</td>
                <td>{{tabinfo.colunm13}}</td>
                <td>{{tabinfo.colunm14}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;资产减值损失</td>
                <td>{{tabinfo.colunm15}}</td>
                <td>{{tabinfo.colunm16}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;加：其他收益</td>
                <td>{{tabinfo.colunm17}}</td>
                <td>{{tabinfo.colunm18}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;公允价值变动收益（损失以"-"号填例）</td>
                <td>{{tabinfo.colunm19}}</td>
                <td>{{tabinfo.colunm20}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;投资收益（损失以"-"号填例）</td>
                <td>{{tabinfo.colunm21}}</td>
                <td>{{tabinfo.colunm22}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其中：对联营企业和合营企业的投资收益</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>二、营业利润（亏损以"-"号填例）</td>
                <td>{{tabinfo.colunm23}}</td>
                <td>{{tabinfo.colunm24}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;加：营业外收入</td>
                <td>{{tabinfo.colunm25}}</td>
                <td>{{tabinfo.colunm26}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;减：营业外支出</td>
                <td>{{tabinfo.colunm27}}</td>
                <td>{{tabinfo.colunm28}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其中：非流动资产处置损失</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>三、利润总额（亏损总额以"-"号填例）</td>
                <td>{{tabinfo.colunm29}}</td>
                <td>{{tabinfo.colunm30}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;减：所得税费用</td>
                <td>{{tabinfo.colunm31}}</td>
                <td>{{tabinfo.colunm32}}</td>
              </tr>
              <tr>
                <td>四、净利润（净亏损以"-"号填例）</td>
                <td>{{tabinfo.colunm33}}</td>
                <td>{{tabinfo.colunm34}}</td>
              </tr>
              <tr>
                <td>五、每股收益：</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>（一）基本每股收益</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>（二）稀释每股收益</td>
                <td></td>
                <td></td>
              </tr>
          </tbody>
        </table>
      </div>
    </div>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getVoucherDetailByYearList} from '@/api/system';
import { async } from "q";
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const voucherform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            formlist:{
              voucherTime:""
            },
            tabinfo:{
              colunm1:0,
              colunm2:0,
              colunm3:0,
              colunm4:0,
              colunm5:0,
              colunm6:0,
              colunm7:0,
              colunm8:0,
              colunm9:0,
              colunm10:0,
              colunm11:0,
              colunm12:0,
              colunm13:0,
              colunm14:0,
              colunm15:0,
              colunm16:0,
              colunm17:0,
              colunm18:0,
              colunm19:0,
              colunm20:0,
              colunm21:0,
              colunm22:0,
              colunm23:0,
              colunm24:0,
              colunm25:0,
              colunm26:0,
              colunm27:0,
              colunm28:0,
              colunm29:0,
              colunm30:0,
              colunm31:0,
              colunm32:0,
              colunm33:0,
              colunm34:0,
              colunm35:0,
              colunm36:0,
              colunm37:0,
              colunm38:0,
              colunm39:0,
              colunm40:0
            },
        })
        onMounted(() => {
          state.formlist.voucherTime=getNowDate();
          getVoucherDetailListArray();
        })
        const searchVoucher=()=>{
          getVoucherDetailListArray();
        }
        const clearvalue=()=>{
          state.tabinfo.colunm1=0;
          state.tabinfo.colunm2=0;
              state.tabinfo.colunm3=0;
              state.tabinfo.colunm4=0;
              state.tabinfo.colunm5=0;
              state.tabinfo.colunm6=0;
              state.tabinfo.colunm7=0;
              state.tabinfo.colunm8=0;
              state.tabinfo.colunm9=0;
              state.tabinfo.colunm10=0;
              state.tabinfo.colunm11=0;
              state.tabinfo.colunm12=0;
              state.tabinfo.colunm13=0;
              state.tabinfo.colunm14=0;
              state.tabinfo.colunm15=0;
              state.tabinfo.colunm16=0;
              state.tabinfo.colunm17=0;
              state.tabinfo.colunm18=0;
              state.tabinfo.colunm19=0;
              state.tabinfo.colunm20=0;
              state.tabinfo.colunm21=0;
              state.tabinfo.colunm22=0;
              state.tabinfo.colunm23=0;
              state.tabinfo.colunm24=0;
              state.tabinfo.colunm25=0;
              state.tabinfo.colunm26=0;
              state.tabinfo.colunm27=0;
              state.tabinfo.colunm28=0;
              state.tabinfo.colunm29=0;
              state.tabinfo.colunm30=0;
              state.tabinfo.colunm31=0;
              state.tabinfo.colunm32=0;
              state.tabinfo.colunm33=0;
              state.tabinfo.colunm34=0;
              state.tabinfo.colunm35=0;
              state.tabinfo.colunm36=0;
              state.tabinfo.colunm37=0;
              state.tabinfo.colunm38=0;
              state.tabinfo.colunm39=0;
              state.tabinfo.colunm40=0;
        }
        const getVoucherDetailListArray=async()=>{
          clearvalue();
          let cuurentDay=myTimeToLocal(getTimeToLocal(state.formlist.voucherTime))+getCurrentNowTime();
          var paramdata={
            accountsId:localStorage.getItem('accountsId'),
            voucherTime:cuurentDay
          }
          let res=await getVoucherDetailByYearList(paramdata);
          if(res.code==200){
            state.tableData=res.data;
            for(var index=0;index<state.tableData.length;index++){
              if(state.tableData[index].subjectCode=="6001"){//
                state.tabinfo.colunm1=parseFloat(state.tabinfo.colunm1)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm2=parseFloat(state.tabinfo.colunm2)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)+parseFloat(state.tabinfo.colunm1);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)+parseFloat(state.tabinfo.colunm2);
              }
              if(state.tableData[index].subjectCode=="6051"){//
                state.tabinfo.colunm1=parseFloat(state.tabinfo.colunm1)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm2=parseFloat(state.tabinfo.colunm2)+parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="6401"){//
                state.tabinfo.colunm3=parseFloat(state.tabinfo.colunm3)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm4=parseFloat(state.tabinfo.colunm4)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm3);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm4);
              }
              if(state.tableData[index].subjectCode=="6402"){//
                state.tabinfo.colunm3=parseFloat(state.tabinfo.colunm3)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm4=parseFloat(state.tabinfo.colunm4)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm3);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm4);
              }
              if(state.tableData[index].subjectCode=="6403"){//营业税金及附加
                state.tabinfo.colunm5=state.tableData[index].lenderMoney;
                state.tabinfo.colunm6=state.tableData[index].lenderMoney;
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm5);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm6);
              }
              if(state.tableData[index].subjectCode=="6601"){//销售费用
                state.tabinfo.colunm7=state.tableData[index].currentMoney;
                state.tabinfo.colunm8=state.tableData[index].startMoney;
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm7);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm8);
              }
              if(state.tableData[index].subjectCode=="6602"){//管理费用
                state.tabinfo.colunm9=state.tableData[index].currentMoney;
                state.tabinfo.colunm10=state.tableData[index].startMoney;
                 state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm9);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm10);
              }
              if(state.tableData[index].subjectCode=="6603"){//研发费用
                state.tabinfo.colunm11=state.tableData[index].currentMoney;
                state.tabinfo.colunm12=state.tableData[index].startMoney;
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm11);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm12);
              }
              if(state.tableData[index].subjectCode=="6604"){//财务费用
                state.tabinfo.colunm13=state.tableData[index].currentMoney;
                state.tabinfo.colunm14=state.tableData[index].startMoney;
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm13);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm14);
              }
              if(state.tableData[index].subjectCode=="6701"){//资产减值损失
                state.tabinfo.colunm15=state.tableData[index].currentMoney;
                state.tabinfo.colunm16=state.tableData[index].startMoney;
                state.tabinfo.colunm23=parseFloat(state.tabinfo.colunm23)-parseFloat(state.tabinfo.colunm15);
                state.tabinfo.colunm24=parseFloat(state.tabinfo.colunm24)-parseFloat(state.tabinfo.colunm16);
              }
              if(state.tableData[index].subjectCode=="6117"){//其他收益
                state.tabinfo.colunm17=state.tableData[index].currentMoney;
                state.tabinfo.colunm18=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="6101"){//
                state.tabinfo.colunm19=state.tableData[index].currentMoney;
                state.tabinfo.colunm20=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="6111"){//
                state.tabinfo.colunm21=state.tableData[index].currentMoney;
                state.tabinfo.colunm22=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="6301"){//营业外收入
                state.tabinfo.colunm25=state.tableData[index].currentMoney;
                state.tabinfo.colunm26=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="6711"){//营业外支出
                state.tabinfo.colunm27=state.tableData[index].currentMoney;
                state.tabinfo.colunm28=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="6801"){//
                state.tabinfo.colunm31=state.tableData[index].currentMoney;
                state.tabinfo.colunm32=state.tableData[index].startMoney;
              }
            }
          }
        }
        const myTimeToLocal=(inputTime)=>{
         
          inputTime = inputTime.replace(" 00:00:00","");
          return inputTime;
        }
        const getTimeToLocal=(inputTime)=>{
          if(!inputTime && typeof inputTime !== 'number'){
            return '';
          }
          var localTime = '';
          inputTime = new Date(inputTime).getTime();
          const offset = (new Date()).getTimezoneOffset();
          localTime = (new Date(inputTime - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
        const getCurrentNowTime=()=>{
          let hh =  new Date().getHours()<10 ? '0'+new Date().getHours() : new Date().getHours();
    　　  let mf = new Date().getMinutes()<10 ? '0'+new Date().getMinutes() : new Date().getMinutes();
    　　  let ss = new Date().getSeconds()<10 ? '0'+new Date().getSeconds() : new Date().getSeconds();
          return " "+hh+":"+mf+":"+ss;
        }
        const getNowDate=() =>{
            let date = new Date();
            let y = date.getFullYear();
            let m = date.getMonth() + 1;
            let d = date.getDate();
            let H = date.getHours();
            let mm = date.getMinutes();
            let s=date.getSeconds();
                  m = m < 10 ? "0" + m : m;
                  d = d < 10 ? "0" + d : d;
                  H = H < 10 ? "0" + H : H;
                  return y + "-" + m + "-" + d + " ";
        }
        return {
            ...toRefs(state),
            getVoucherDetailListArray,
            searchVoucher,
            myTimeToLocal,
            getCurrentNowTime,
            getTimeToLocal,
            getNowDate,
            clearvalue
        }
    }
}
</script>
<style>
.userdiv{
  margin-bottom: 13px;
}
.btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
.el-scrollbar__wrap {
    overflow-x: hidden!important;
}

.el-table__fixed {
    height:auto !important; 
    bottom:17px; 
}
.el-table--scrollable-x .el-table__body-wrapper {
    z-index: 1;
  }
      @page{
        size: auto A4 landscape;
        margin: 3mm;
    }
.tb {
		border-collapse:collapse;
		}
    .tb td{
      height: 25px;
    }
		.tb td {
		border:0.5px solid #545c64;
		}
</style>