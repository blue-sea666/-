<template>
    <el-form ref="voucherform" :rules="rules" :model="formlist" label-width="120px" class="forminput" style="width:100%;height:40px;margin-left:-60px;">
      <div style="float:left;width:100%;">
         <el-form-item label="日期：" prop="voucherTime" class="sernameval"> 
            <el-date-picker
            v-model="formlist.voucherTime"
            type="month"
            placeholder="请选择日期" style="width:300px;float:left;padding-left:5px;"
          ></el-date-picker>
          <el-button type="primary" plain @click="searchVoucher" class="btnbutton" style="margin-left:10px;">查询</el-button>
          <el-button type="primary" plain class="btnbutton" v-print="'#printTest'" style="margin-left:10px;">打印</el-button>
        </el-form-item>
      </div>
    </el-form>
    <div style="width: 100%" align="center">
      <div id="printTest" style="width: 100%;" align="center">
        <table class="tb" style="width:100%;"> 
          <tbody>
              <tr>
                <td style="text-align:center;">资产</td>
                <td style="text-align:center;">期末余额</td>
                <td style="text-align:center;">年初余额</td>
                <td style="text-align:center;">资产和所有者权益（或股东权益）</td>
                <td style="text-align:center;">期末余额</td>
                <td style="text-align:center;">年初余额</td>
              </tr>
              <tr>
                <td>流动资产：</td>
                <td></td>
                <td></td>
                <td>流动负债</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;货币资金</td>
                <td>{{tabinfo.colunm1}}</td>
                <td>{{tabinfo.colunm2}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;短期借款</td>
                <td>{{tabinfo.colunm3}}</td>
                <td>{{tabinfo.colunm4}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;交易性金融资产</td>
                <td>{{tabinfo.colunm5}}</td>
                <td>{{tabinfo.colunm6}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;交易性金融负债</td>
                <td>{{tabinfo.colunm7}}</td>
                <td>{{tabinfo.colunm8}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应收票据</td>
                <td>{{tabinfo.colunm9}}</td>
                <td>{{tabinfo.colunm10}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付票据</td>
                <td>{{tabinfo.colunm11}}</td>
                <td>{{tabinfo.colunm12}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应收账款</td>
                <td>{{tabinfo.colunm13}}</td>
                <td>{{tabinfo.colunm14}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付账款</td>
                <td>{{tabinfo.colunm15}}</td>
                <td>{{tabinfo.colunm16}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;预付款项</td>
                <td>{{tabinfo.colunm21}}</td>
                <td>{{tabinfo.colunm22}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;预收款项</td>
                <td>{{tabinfo.colunm23}}</td>
                <td>{{tabinfo.colunm24}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应收利息</td>
                <td>{{tabinfo.colunm25}}</td>
                <td>{{tabinfo.colunm26}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付职工薪酬</td>
                <td>{{tabinfo.colunm27}}</td>
                <td>{{tabinfo.colunm28}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应收股利</td>
                <td>{{tabinfo.colunm29}}</td>
                <td>{{tabinfo.colunm30}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应交税费</td>
                <td>{{tabinfo.colunm31}}</td>
                <td>{{tabinfo.colunm32}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他应收款</td>
                <td>{{tabinfo.colunm33}}</td>
                <td>{{tabinfo.colunm331}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付利息</td>
                <td>{{tabinfo.colunm34}}</td>
                <td>{{tabinfo.colunm35}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;存货</td>
                <td>{{tabinfo.colunm36}}</td>
                <td>{{tabinfo.colunm37}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付股利</td>
                <td>{{tabinfo.colunm38}}</td>
                <td>{{tabinfo.colunm39}}</td>
              </tr>
              <tr>
                <td>其中：原材料</td>
                <td>{{tabinfo.colunm40}}</td>
                <td>{{tabinfo.colunm41}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他应付款</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;产成品</td>
                <td>{{tabinfo.colunm42}}</td>
                <td>{{tabinfo.colunm43}}</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在产品</td>
                <td>{{tabinfo.colunm44}}</td>
                <td>{{tabinfo.colunm45}}</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他流动资产</td>
                <td>{{tabinfo.colunm46}}</td>
                <td>{{tabinfo.colunm47}}</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;流动资产合计</td>
                <td>{{tabinfo.colunm48}}</td>
                <td>{{tabinfo.colunm49}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他负债</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>非流动资产</td>
                <td></td>
                <td></td>
                <td>流动负债合计</td>
                <td>{{tabinfo.colunm50}}</td>
                <td>{{tabinfo.colunm51}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;长期股权投资</td>
                <td>{{tabinfo.colunm52}}</td>
                <td>{{tabinfo.colunm53}}</td>
                <td>非流动负债</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;持有至到期投资</td>
                <td>{{tabinfo.colunm56}}</td>
                <td>{{tabinfo.colunm57}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;长期借款</td>
                <td>{{tabinfo.colunm58}}</td>
                <td>{{tabinfo.colunm59}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;长期应收款</td>
                <td>{{tabinfo.colunm60}}</td>
                <td>{{tabinfo.colunm61}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;应付债券</td>
                <td>{{tabinfo.colunm62}}</td>
                <td>{{tabinfo.colunm63}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;固定资产原值</td>
                <td>{{tabinfo.colunm64}}</td>
                <td>{{tabinfo.colunm65}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;流动负债</td>
                <td>{{tabinfo.colunm66}}</td>
                <td>{{tabinfo.colunm67}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;流动资产</td>
                <td>{{tabinfo.colunm68}}</td>
                <td>{{tabinfo.colunm69}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;长期应付款</td>
                <td>{{tabinfo.colunm70}}</td>
                <td>{{tabinfo.colunm71}}</td>
              </tr>
              <tr>
                <td>减：累计折旧</td>
                <td>{{tabinfo.colunm72}}</td>
                <td>{{tabinfo.colunm73}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;专项应付款</td>
                <td>{{tabinfo.colunm74}}</td>
                <td>{{tabinfo.colunm75}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;固定资产净值</td>
                <td>{{tabinfo.colunm76}}</td>
                <td>{{tabinfo.colunm77}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;预计负债</td>
                <td>{{tabinfo.colunm78}}</td>
                <td>{{tabinfo.colunm79}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在建工程</td>
                <td>{{tabinfo.colunm80}}</td>
                <td>{{tabinfo.colunm81}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;递延所得税负债</td>
                <td>{{tabinfo.colunm82}}</td>
                <td>{{tabinfo.colunm83}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;工程物资</td>
                <td>{{tabinfo.colunm84}}</td>
                <td>{{tabinfo.colunm85}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他非流动负债</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;固定资产清理</td>
                <td>{{tabinfo.colunm88}}</td>
                <td>{{tabinfo.colunm89}}</td>
                <td>非流动负债合计</td>
                <td>{{tabinfo.colunm90}}</td>
                <td>{{tabinfo.colunm91}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;固定资产合计</td>
                <td>{{tabinfo.colunm92}}</td>
                <td>{{tabinfo.colunm93}}</td>
                <td>负债合计</td>
                <td>{{tabinfo.colunm94}}</td>
                <td>{{tabinfo.colunm95}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;油气资产</td>
                <td></td>
                <td></td>
                <td>所有者权益（或股东权益）</td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;无形资产</td>
                <td>{{tabinfo.colunm96}}</td>
                <td>{{tabinfo.colunm97}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;实收资本（或股东）</td>
                <td>{{tabinfo.colunm98}}</td>
                <td>{{tabinfo.colunm99}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;开发支出</td>
                <td>{{tabinfo.colunm100}}</td>
                <td>{{tabinfo.colunm101}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;资本公积</td>
                <td>{{tabinfo.colunm102}}</td>
                <td>{{tabinfo.colunm103}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;商誉</td>
                <td>{{tabinfo.colunm104}}</td>
                <td>{{tabinfo.colunm105}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;减：库存股</td>
                <td>{{tabinfo.colunm106}}</td>
                <td>{{tabinfo.colunm107}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;长摊待摊费用</td>
                <td>{{tabinfo.colunm108}}</td>
                <td>{{tabinfo.colunm109}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;盈余公积</td>
                <td>{{tabinfo.colunm110}}</td>
                <td>{{tabinfo.colunm111}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;递延所得税资产</td>
                <td>{{tabinfo.colunm112}}</td>
                <td>{{tabinfo.colunm113}}</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;未分配利润</td>
                <td>{{tabinfo.colunm114}}</td>
                <td>{{tabinfo.colunm115}}</td>
              </tr>
              <tr>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他非流动资产</td>
                <td></td>
                <td></td>
                <td>所有者权益（或股东权益）合计</td>
                <td>{{tabinfo.colunm116}}</td>
                <td>{{tabinfo.colunm117}}</td>
              </tr>
              <tr>
                <td>非流动资产合计</td>
                <td>{{tabinfo.colunm118}}</td>
                <td>{{tabinfo.colunm119}}</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td>资产合计</td>
                <td>{{tabinfo.colunm120}}</td>
                <td>{{tabinfo.colunm121}}</td>
                <td>负债和所有者权益（或股东权益）总计</td>
                <td>{{tabinfo.colunm122}}</td>
                <td>{{tabinfo.colunm123}}</td>
              </tr>
          </tbody>
        </table>
      </div>
    </div>
</template>
<script>
import{ toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage } from 'element-plus'
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getVoucherDetailByMonthList} from '@/api/system';
import { async } from "q";
export default {

    setup: () => {
        const { proxy } = getCurrentInstance();
        const voucherform =ref(null);
        const state = reactive({
            locale:zhCn,
            tableData: [],
            formlist:{
              voucherTime:""
            },
            tabinfo:{
              colunm1:0,
              colunm2:0,
              colunm3:0,
              colunm4:0,
              colunm5:0,
              colunm6:0,
              colunm7:0,
              colunm8:0,
              colunm9:0,
              colunm10:0,
              colunm11:0,
              colunm12:0,
              colunm13:0,
              colunm14:0,
              colunm15:0,
              colunm16:0,
              colunm17:0,
              colunm18:0,
              colunm19:0,
              colunm20:0,
              colunm21:0,
              colunm22:0,
              colunm23:0,
              colunm24:0,
              colunm25:0,
              colunm26:0,
              colunm27:0,
              colunm28:0,
              colunm29:0,
              colunm30:0,
              colunm31:0,
              colunm32:0,
              colunm33:0,
              colunm34:0,
              colunm35:0,
              colunm36:0,
              colunm37:0,
              colunm38:0,
              colunm39:0,
              colunm40:0,
              colunm41:0,
              colunm42:0,
              colunm43:0,
              colunm44:0,
              colunm45:0,
              colunm46:0,
              colunm47:0,
              colunm48:0,
              colunm49:0,
              colunm50:0,
              colunm51:0,
              colunm52:0,
              colunm53:0,
              colunm54:0,
              colunm55:0,
              colunm56:0,
              colunm57:0,
              colunm58:0,
              colunm59:0,
              colunm60:0,
              colunm61:0,
              colunm62:0,
              colunm63:0,
              colunm64:0,
              colunm65:0,
              colunm66:0,
              colunm67:0,
              colunm68:0,
              colunm69:0,
              colunm70:0,
              colunm71:0,
              colunm72:0,
              colunm73:0,
              colunm74:0,
              colunm75:0,
              colunm76:0,
              colunm77:0,
              colunm78:0,
              colunm79:0,
              colunm80:0,
              colunm81:0,
              colunm82:0,
              colunm83:0,
              colunm84:0,
              colunm85:0,
              colunm86:0,
              colunm87:0,
              colunm88:0,
              colunm89:0,
              colunm90:0,
              colunm91:0,
              colunm92:0,
              colunm93:0,
              colunm94:0,
              colunm95:0,
              colunm96:0,
              colunm97:0,
              colunm98:0,
              colunm99:0,
              colunm100:0,
              colunm101:0,
              colunm102:0,
              colunm103:0,
              colunm104:0,
              colunm105:0,
              colunm106:0,
              colunm107:0,
              colunm108:0,
              colunm109:0,
              colunm110:0,
              colunm111:0,
              colunm112:0,
              colunm113:0,
              colunm114:0,
              colunm115:0,
              colunm116:0,
              colunm117:0,
              colunm118:0,
              colunm119:0,
              colunm120:0,
              colunm121:0,
              colunm122:0,
              colunm123:0,
              colunm331:0,
            },
        })
        onMounted(() => {
          state.formlist.voucherTime=getNowDate();
          getVoucherDetailListArray();
        })
        const searchVoucher=()=>{
          getVoucherDetailListArray();
        }
        const clearvalue=()=>{
          state.tabinfo.colunm1=0;
          state.tabinfo.colunm2=0;
              state.tabinfo.colunm3=0;
              state.tabinfo.colunm4=0;
              state.tabinfo.colunm5=0;
              state.tabinfo.colunm6=0;
              state.tabinfo.colunm7=0;
              state.tabinfo.colunm8=0;
              state.tabinfo.colunm9=0;
              state.tabinfo.colunm10=0;
              state.tabinfo.colunm11=0;
              state.tabinfo.colunm12=0;
              state.tabinfo.colunm13=0;
              state.tabinfo.colunm14=0;
              state.tabinfo.colunm15=0;
              state.tabinfo.colunm16=0;
              state.tabinfo.colunm17=0;
              state.tabinfo.colunm18=0;
              state.tabinfo.colunm19=0;
              state.tabinfo.colunm20=0;
              state.tabinfo.colunm21=0;
              state.tabinfo.colunm22=0;
              state.tabinfo.colunm23=0;
              state.tabinfo.colunm24=0;
              state.tabinfo.colunm25=0;
              state.tabinfo.colunm26=0;
              state.tabinfo.colunm27=0;
              state.tabinfo.colunm28=0;
              state.tabinfo.colunm29=0;
              state.tabinfo.colunm30=0;
              state.tabinfo.colunm31=0;
              state.tabinfo.colunm32=0;
              state.tabinfo.colunm33=0;
              state.tabinfo.colunm34=0;
              state.tabinfo.colunm35=0;
              state.tabinfo.colunm36=0;
              state.tabinfo.colunm37=0;
              state.tabinfo.colunm38=0;
              state.tabinfo.colunm39=0;
              state.tabinfo.colunm40=0;
              state.tabinfo.colunm41=0;
              state.tabinfo.colunm42=0;
              state.tabinfo.colunm43=0;
              state.tabinfo.colunm44=0;
              state.tabinfo.colunm45=0;
              state.tabinfo.colunm46=0;
              state.tabinfo.colunm47=0;
              state.tabinfo.colunm48=0;
              state.tabinfo.colunm49=0;
              state.tabinfo.colunm50=0;
              state.tabinfo.colunm51=0;
              state.tabinfo.colunm52=0;
              state.tabinfo.colunm53=0;
              state.tabinfo.colunm54=0;
              state.tabinfo.colunm55=0;
              state.tabinfo.colunm56=0;
              state.tabinfo.colunm57=0;
              state.tabinfo.colunm58=0;
              state.tabinfo.colunm59=0;
              state.tabinfo.colunm60=0;
              state.tabinfo.colunm61=0;
              state.tabinfo.colunm62=0;
              state.tabinfo.colunm63=0;
              state.tabinfo.colunm64=0;
              state.tabinfo.colunm65=0;
              state.tabinfo.colunm66=0;
              state.tabinfo.colunm67=0;
              state.tabinfo.colunm68=0;
              state.tabinfo.colunm69=0;
              state.tabinfo.colunm70=0;
              state.tabinfo.colunm71=0;
              state.tabinfo.colunm72=0;
              state.tabinfo.colunm73=0;
              state.tabinfo.colunm74=0;
              state.tabinfo.colunm75=0;
              state.tabinfo.colunm76=0;
              state.tabinfo.colunm77=0;
              state.tabinfo.colunm78=0;
              state.tabinfo.colunm79=0;
              state.tabinfo.colunm80=0;
              state.tabinfo.colunm81=0;
              state.tabinfo.colunm82=0;
              state.tabinfo.colunm83=0;
              state.tabinfo.colunm84=0;
              state.tabinfo.colunm85=0;
              state.tabinfo.colunm86=0;
              state.tabinfo.colunm87=0;
              state.tabinfo.colunm88=0;
              state.tabinfo.colunm89=0;
              state.tabinfo.colunm90=0;
              state.tabinfo.colunm91=0;
              state.tabinfo.colunm92=0;
              state.tabinfo.colunm93=0;
              state.tabinfo.colunm94=0;
              state.tabinfo.colunm95=0;
              state.tabinfo.colunm96=0;
              state.tabinfo.colunm97=0;
              state.tabinfo.colunm98=0;
              state.tabinfo.colunm99=0;
              state.tabinfo.colunm100=0;
              state.tabinfo.colunm101=0;
              state.tabinfo.colunm102=0;
              state.tabinfo.colunm103=0;
              state.tabinfo.colunm104=0;
              state.tabinfo.colunm105=0;
              state.tabinfo.colunm106=0;
              state.tabinfo.colunm107=0;
              state.tabinfo.colunm108=0;
              state.tabinfo.colunm109=0;
              state.tabinfo.colunm110=0;
              state.tabinfo.colunm111=0;
              state.tabinfo.colunm112=0;
              state.tabinfo.colunm113=0;
              state.tabinfo.colunm114=0;
              state.tabinfo.colunm115=0;
              state.tabinfo.colunm116=0;
              state.tabinfo.colunm117=0;
              state.tabinfo.colunm118=0;
              state.tabinfo.colunm119=0;
              state.tabinfo.colunm120=0;
              state.tabinfo.colunm121=0;
              state.tabinfo.colunm122=0;
              state.tabinfo.colunm123=0;
              state.tabinfo.colunm331=0;
        }
        const getVoucherDetailListArray=async()=>{
          clearvalue();
          let cuurentDay=myTimeToLocal(getTimeToLocal(state.formlist.voucherTime))+getCurrentNowTime();
          var paramdata={
            accountsId:localStorage.getItem('accountsId'),
            voucherTime:cuurentDay
          }
          let res=await getVoucherDetailByMonthList(paramdata);
          if(res.code==200){
            state.tableData=res.data;
            for(var index=0;index<state.tableData.length;index++){
              if(state.tableData[index].subjectCode=="1012"){//货币资金
                state.tabinfo.colunm1=state.tableData[index].currentMoney;
                state.tabinfo.colunm2=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm1);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm2);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2001"){//短期借款
                state.tabinfo.colunm3=state.tableData[index].currentMoney;
                state.tabinfo.colunm4=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm3); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm4);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51); 
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1101"){//交易性金融资产
                state.tabinfo.colunm5=state.tableData[index].currentMoney;
                state.tabinfo.colunm6=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm5);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm6);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2101"){//交易性金融负债
                state.tabinfo.colunm7=state.tableData[index].currentMoney;
                state.tabinfo.colunm8=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm7); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm8);
                 state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51); 
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1121"){//应收票据
                state.tabinfo.colunm9=state.tableData[index].currentMoney;
                state.tabinfo.colunm10=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm9);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm10);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2201"){// 应付票据
                state.tabinfo.colunm11=state.tableData[index].currentMoney;
                state.tabinfo.colunm12=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm11); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm12);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm51);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1122"){//应收账款
                state.tabinfo.colunm13=state.tableData[index].currentMoney;
                state.tabinfo.colunm14=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm13);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm14);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2202"){//应付账款
                state.tabinfo.colunm15=state.tableData[index].currentMoney;
                state.tabinfo.colunm16=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm15); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm16); 
                 state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1123"){//预付账款
                state.tabinfo.colunm21=state.tableData[index].currentMoney;
                state.tabinfo.colunm22=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm21);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm22);
              }
              if(state.tableData[index].subjectCode=="2203"){//预收款项
                state.tabinfo.colunm23=state.tableData[index].currentMoney;
                state.tabinfo.colunm24=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm23); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm24); 
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51); 
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1132"){//应收利息
                state.tabinfo.colunm25=state.tableData[index].currentMoney;
                state.tabinfo.colunm26=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm25);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm26);
              }
              if(state.tableData[index].subjectCode=="2211"){//应付职工薪酬
                state.tabinfo.colunm27=state.tableData[index].currentMoney;
                state.tabinfo.colunm28=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm27); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm28);
                 state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51);  
              }
              if(state.tableData[index].subjectCode=="1131"){//应收股利
                state.tabinfo.colunm29=state.tableData[index].currentMoney;
                state.tabinfo.colunm30=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm29);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm30);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2221"){//应交税费
                state.tabinfo.colunm31=state.tableData[index].currentMoney;
                state.tabinfo.colunm32=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm31); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm32); 
                 state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51); 
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1221"){//其他应收款
                state.tabinfo.colunm33=state.tableData[index].currentMoney;
                state.tabinfo.colunm331=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm33);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm331);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2231"){//应付利息
                state.tabinfo.colunm34=state.tableData[index].currentMoney;
                state.tabinfo.colunm35=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm34); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm35); 
                 state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm95)+parseFloat(state.tabinfo.colunm51);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              //存货
              if(state.tableData[index].subjectCode=="1403"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
               if(state.tableData[index].subjectCode=="1404"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
               if(state.tableData[index].subjectCode=="1405"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
              }
              if(state.tableData[index].subjectCode=="1406"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="5001"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
              }
              if(state.tableData[index].subjectCode=="5101"){
                state.tabinfo.colunm36=parseFloat(state.tabinfo.colunm36)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm37=parseFloat(state.tabinfo.colunm37)+parseFloat(state.tableData[index].startMoney);
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm36);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm37);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm48);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm49);
              }
              if(state.tableData[index].subjectCode=="2232"){
                state.tabinfo.colunm38=state.tableData[index].currentMoney;
                state.tabinfo.colunm39=state.tableData[index].startMoney;
                state.tabinfo.colunm50=parseFloat(state.tabinfo.colunm50)+parseFloat(state.tabinfo.colunm38); 
                state.tabinfo.colunm51=parseFloat(state.tabinfo.colunm51)+parseFloat(state.tabinfo.colunm39);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm50); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm51);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);    
              }
              if(state.tableData[index].subjectCode=="1403"){
                state.tabinfo.colunm40=state.tableData[index].currentMoney;
                state.tabinfo.colunm41=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="1405"){
                state.tabinfo.colunm42=parseFloat(state.tabinfo.colunm42)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm43=parseFloat(state.tabinfo.colunm43)+parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="1406"){
                state.tabinfo.colunm42=parseFloat(state.tabinfo.colunm42)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm43=parseFloat(state.tabinfo.colunm43)+parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="5001"){
                state.tabinfo.colunm44=parseFloat(state.tabinfo.colunm44)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm45=parseFloat(state.tabinfo.colunm45)+parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="5101"){
                state.tabinfo.colunm44=parseFloat(state.tabinfo.colunm44)+parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm45=parseFloat(state.tabinfo.colunm45)+parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="1483"){
                state.tabinfo.colunm46=state.tableData[index].currentMoney;
                state.tabinfo.colunm47=state.tableData[index].startMoney;
                state.tabinfo.colunm48=parseFloat(state.tabinfo.colunm48)+parseFloat(state.tabinfo.colunm46);
                state.tabinfo.colunm49=parseFloat(state.tabinfo.colunm49)+parseFloat(state.tabinfo.colunm47);
              }
              if(state.tableData[index].subjectCode=="1511"){//长期股权投资
                state.tabinfo.colunm52=state.tableData[index].currentMoney;
                state.tabinfo.colunm53=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm52);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm53);
              }
              if(state.tableData[index].subjectCode=="1501"){//持有至到期投资
                state.tabinfo.colunm56=state.tableData[index].currentMoney;
                state.tabinfo.colunm57=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="2501"){//长期借款
                state.tabinfo.colunm58=state.tableData[index].currentMoney;
                state.tabinfo.colunm59=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm58);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm59);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1531"){//长期应收款
                state.tabinfo.colunm60=state.tableData[index].currentMoney;
                state.tabinfo.colunm61=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="2502"){//应付债券
                state.tabinfo.colunm62=state.tableData[index].currentMoney;
                state.tabinfo.colunm63=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm62);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm63);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1601"){//固定资产原值
                state.tabinfo.colunm64=state.tableData[index].currentMoney;
                state.tabinfo.colunm65=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="2701"){//长期应付款
                state.tabinfo.colunm70=state.tableData[index].currentMoney;
                state.tabinfo.colunm71=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm70);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm71);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1602"){//累计折旧
                state.tabinfo.colunm72=state.tableData[index].currentMoney;
                state.tabinfo.colunm73=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="2711"){//专项应付款
                state.tabinfo.colunm74=state.tableData[index].currentMoney;
                state.tabinfo.colunm75=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm74);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm75);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              ////固定资产净值
              if(state.tableData[index].subjectCode=="1601"){
                state.tabinfo.colunm76=state.tableData[index].currentMoney;
                state.tabinfo.colunm77=state.tableData[index].startMoney;
                state.tabinfo.colunm92=parseFloat(state.tabinfo.colunm92)+parseFloat(state.tabinfo.colunm76);
                state.tabinfo.colunm93=parseFloat(state.tabinfo.colunm93)+parseFloat(state.tabinfo.colunm77);
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm92);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm93);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="1602"){
                state.tabinfo.colunm76=parseFloat(state.tabinfo.colunm76)-parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm77=parseFloat(state.tabinfo.colunm77)-parseFloat(state.tableData[index].startMoney);
              }
              if(state.tableData[index].subjectCode=="1603"){
                state.tabinfo.colunm76=parseFloat(state.tabinfo.colunm76)-parseFloat(state.tableData[index].currentMoney);
                state.tabinfo.colunm77=parseFloat(state.tabinfo.colunm77)-parseFloat(state.tableData[index].startMoney);
              }
              //////////
              if(state.tableData[index].subjectCode=="2801"){//预计负债
                state.tabinfo.colunm78=state.tableData[index].currentMoney;
                state.tabinfo.colunm79=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm78);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm79);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1604"){//在建工程
                state.tabinfo.colunm80=state.tableData[index].currentMoney;
                state.tabinfo.colunm81=state.tableData[index].startMoney;
                state.tabinfo.colunm92=parseFloat(state.tabinfo.colunm92)+parseFloat(state.tabinfo.colunm80);
                state.tabinfo.colunm93=parseFloat(state.tabinfo.colunm93)+parseFloat(state.tabinfo.colunm81);
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm92);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm93);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="2901"){//递延所得税负债
                state.tabinfo.colunm82=state.tableData[index].currentMoney;
                state.tabinfo.colunm83=state.tableData[index].startMoney;
                state.tabinfo.colunm90=parseFloat(state.tabinfo.colunm90)+parseFloat(state.tabinfo.colunm82);
                state.tabinfo.colunm91=parseFloat(state.tabinfo.colunm91)+parseFloat(state.tabinfo.colunm83);
                state.tabinfo.colunm94=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm90); 
                state.tabinfo.colunm95=parseFloat(state.tabinfo.colunm94)+parseFloat(state.tabinfo.colunm91);
                state.tabinfo.colunm122=parseFloat(state.tabinfo.colunm122)+parseFloat(state.tabinfo.colunm94); 
                state.tabinfo.colunm123=parseFloat(state.tabinfo.colunm123)+parseFloat(state.tabinfo.colunm95);   
              }
              if(state.tableData[index].subjectCode=="1605"){//工程物资
                state.tabinfo.colunm84=state.tableData[index].currentMoney;
                state.tabinfo.colunm85=state.tableData[index].startMoney;
              }
              if(state.tableData[index].subjectCode=="1606"){//固定资产清理
                state.tabinfo.colunm88=state.tableData[index].currentMoney;
                state.tabinfo.colunm89=state.tableData[index].startMoney;
                state.tabinfo.colunm92=parseFloat(state.tabinfo.colunm92)+parseFloat(state.tabinfo.colunm88);
                state.tabinfo.colunm93=parseFloat(state.tabinfo.colunm93)+parseFloat(state.tabinfo.colunm89);
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm92);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm93);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="1701"){//无形资产
                state.tabinfo.colunm96=state.tableData[index].currentMoney;
                state.tabinfo.colunm97=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm96);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm97);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="4001"){//实收资本
                state.tabinfo.colunm98=state.tableData[index].currentMoney;
                state.tabinfo.colunm99=state.tableData[index].startMoney;
                state.tabinfo.colunm116=parseFloat(state.tabinfo.colunm116)+parseFloat(state.tabinfo.colunm98); 
                state.tabinfo.colunm117=parseFloat(state.tabinfo.colunm117)+parseFloat(state.tabinfo.colunm99);
              }
              if(state.tableData[index].subjectCode=="5301"){//开发支出
                state.tabinfo.colunm100=state.tableData[index].currentMoney;
                state.tabinfo.colunm101=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm100);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm101);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="4002"){//资本公积
                state.tabinfo.colunm102=state.tableData[index].currentMoney;
                state.tabinfo.colunm103=state.tableData[index].startMoney;
                state.tabinfo.colunm116=parseFloat(state.tabinfo.colunm116)+parseFloat(state.tabinfo.colunm102); 
                state.tabinfo.colunm117=parseFloat(state.tabinfo.colunm117)+parseFloat(state.tabinfo.colunm103);
              }
              if(state.tableData[index].subjectCode=="1711"){//商誉
                state.tabinfo.colunm104=state.tableData[index].currentMoney;
                state.tabinfo.colunm105=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm104);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm105);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
              if(state.tableData[index].subjectCode=="4201"){//库存股
                state.tabinfo.colunm106=state.tableData[index].currentMoney;
                state.tabinfo.colunm107=state.tableData[index].startMoney;
                state.tabinfo.colunm116=parseFloat(state.tabinfo.colunm116)+parseFloat(state.tabinfo.colunm106); 
                state.tabinfo.colunm117=parseFloat(state.tabinfo.colunm117)+parseFloat(state.tabinfo.colunm107);
              }
               if(state.tableData[index].subjectCode=="1801"){//长期待摊费用
                state.tabinfo.colunm108=state.tableData[index].currentMoney;
                state.tabinfo.colunm109=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm108);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm109);
              }
               if(state.tableData[index].subjectCode=="4101"){//盈余公积
                state.tabinfo.colunm110=state.tableData[index].currentMoney;
                state.tabinfo.colunm111=state.tableData[index].startMoney;
                 state.tabinfo.colunm116=parseFloat(state.tabinfo.colunm116)+parseFloat(state.tabinfo.colunm110); 
                state.tabinfo.colunm117=parseFloat(state.tabinfo.colunm117)+parseFloat(state.tabinfo.colunm111);
              }
               if(state.tableData[index].subjectCode=="1811"){//递延所得税资产
                state.tabinfo.colunm112=state.tableData[index].currentMoney;
                state.tabinfo.colunm113=state.tableData[index].startMoney;
                state.tabinfo.colunm118=parseFloat(state.tabinfo.colunm118)+parseFloat(state.tabinfo.colunm112);
                state.tabinfo.colunm119=parseFloat(state.tabinfo.colunm119)+parseFloat(state.tabinfo.colunm113);
                state.tabinfo.colunm120=parseFloat(state.tabinfo.colunm120)+parseFloat(state.tabinfo.colunm118);
                state.tabinfo.colunm121=parseFloat(state.tabinfo.colunm121)+parseFloat(state.tabinfo.colunm119);
              }
               if(state.tableData[index].subjectCode=="4104.01"){//未分配利润
                state.tabinfo.colunm114=state.tableData[index].currentMoney;
                state.tabinfo.colunm115=state.tableData[index].startMoney;
                state.tabinfo.colunm116=parseFloat(state.tabinfo.colunm116)+parseFloat(state.tabinfo.colunm114); 
                state.tabinfo.colunm117=parseFloat(state.tabinfo.colunm117)+parseFloat(state.tabinfo.colunm115);
              }
            }
          }
        }
        const myTimeToLocal=(inputTime)=>{
         
          inputTime = inputTime.replace(" 00:00:00","");
          return inputTime;
        }
        const getTimeToLocal=(inputTime)=>{
          if(!inputTime && typeof inputTime !== 'number'){
            return '';
          }
          var localTime = '';
          inputTime = new Date(inputTime).getTime();
          const offset = (new Date()).getTimezoneOffset();
          localTime = (new Date(inputTime - offset * 60000)).toISOString();
          localTime = localTime.substr(0, localTime.lastIndexOf('.'));
          localTime = localTime.replace('T', ' ');
          return localTime;
        }
        const getCurrentNowTime=()=>{
          let hh =  new Date().getHours()<10 ? '0'+new Date().getHours() : new Date().getHours();
    　　  let mf = new Date().getMinutes()<10 ? '0'+new Date().getMinutes() : new Date().getMinutes();
    　　  let ss = new Date().getSeconds()<10 ? '0'+new Date().getSeconds() : new Date().getSeconds();
          return " "+hh+":"+mf+":"+ss;
        }
        const getNowDate=() =>{
            let date = new Date();
            let y = date.getFullYear();
            let m = date.getMonth() + 1;
            let d = date.getDate();
            let H = date.getHours();
            let mm = date.getMinutes();
            let s=date.getSeconds();
                  m = m < 10 ? "0" + m : m;
                  d = d < 10 ? "0" + d : d;
                  H = H < 10 ? "0" + H : H;
                  return y + "-" + m + "-" + d + " ";
        }
        return {
            ...toRefs(state),
            getVoucherDetailListArray,
            searchVoucher,
            myTimeToLocal,
            getCurrentNowTime,
            getTimeToLocal,
            getNowDate,
            clearvalue
        }
    }
}
</script>
<style>
.userdiv{
  margin-bottom: 13px;
}
.btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
.el-scrollbar__wrap {
    overflow-x: hidden!important;
}

.el-table__fixed {
    height:auto !important; 
    bottom:17px; 
}
.el-table--scrollable-x .el-table__body-wrapper {
    z-index: 1;
  }
      @page{
        size: auto A4 landscape;
        margin: 3mm;
    }
.tb {
		border-collapse:collapse;
		}
    .tb td{
      height: 25px;
    }
		.tb td {
		border:0.5px solid #545c64;
		}
</style>