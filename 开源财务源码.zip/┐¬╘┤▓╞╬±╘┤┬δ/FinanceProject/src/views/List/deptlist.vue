<template>
  <div class="bodydiv" style="width:100%;height:100%;">
    <div class="bodyleft" style="width:25%;height:100%;border-right: 3px solid #DCDFE6;float:left;margin-top:-10px;">
      <el-input v-model="filterText" class="sernameval" style="width:180px;" placeholder="Filter keyword" />
      <el-button type="primary" plain  @click="adddept" style="margin-top:3px;" class="btnbutton">添加</el-button>
      <el-tree
         ref="treeRef"
         class="filter-tree"
         :data="datatree"
         :props="defaultProps"
         default-expand-all
         @node-click="handleLeftclick"
         :filter-node-method="filterNode">
          <template #default="{node,datatree}" >
             <span class="custom-tree-node el-tree-node__label">
                <span class="label">
                  {{ node.label }}
                </span>
                <el-dropdown>
                <span class="do">
                   <i class="el-icon-plus"></i>
                </span>
                  <template #dropdown  style="marign-left:120px;">
                    <el-dropdown-menu>
                      <el-dropdown-item @click.native="addSameLevelNode(node)">新增同级</el-dropdown-item>
                      <el-dropdown-item @click.native="addChildNode(node)">新增下级</el-dropdown-item>
                      <el-dropdown-item @click.native="updateNode(node)">编辑</el-dropdown-item>
                      <el-dropdown-item @click.native="deleteNode(node)">删除</el-dropdown-item>
                    </el-dropdown-menu>
                  </template>
                  </el-dropdown>
              </span>
        </template>
      </el-tree>
    </div>
    <div class="bodyright" style="width:72%;margin-left:20px;height:100%;float:left;">
      <div style="width:320px;float:left;">
        <el-input v-model="namevalue" class="sernameval" placeholder="请输入姓名" />
      </div>
      <div style="width:90px;float:left;margin-top:5px;">
        <el-button type="primary" plain  @click="searuserlist" class="btnbutton">搜索</el-button>
      </div>
      <div style="width:70px;float:left;margin-top:5px;">
          <el-button type="primary" plain  @click="adduser" v-show="isAdd" class="btnbutton">添加</el-button>
      </div>
      <el-table
        :data="tableData"
        :row-style="{height:'35px'}"
        :cell-style="{padding:'0px'}"
        border
        style="width: 100%">
      <el-table-column prop="userName"  label="姓名" align="center" width="100" class="tbline"></el-table-column>
      <el-table-column prop="userTel" label="电话" align="center" class="tbline"></el-table-column>
      <el-table-column prop="userEmail" label="邮箱" align="center" class="tbline"></el-table-column><el-table-column
        fixed="right"
        label="操作">
        <template #default="scope">
         <el-button @click="handleSet(scope.$index, scope.row)" plain type="primary" size="small" class="btnbutton">设置</el-button>
         <el-button @click="handleEdit(scope.$index, scope.row)" plain type="primary" size="small" class="btnbutton">编辑</el-button>
         <el-button @click="resetPass(scope.$index, scope.row)" plain type="primary" size="small" class="btnbutton">重置密码</el-button>
         <el-button @click="handleDelete(scope.$index, scope.row)" plain type="danger" size="small" class="btnbutton">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
     <!-- 分页底部 -->
    <el-pagination 
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[5,10,15]"
        :page-size="pageSize"
        layout="total,jumper,prev, pager, next,sizes"
        :total="totalCount"
    ></el-pagination>
    </div>
    <el-dialog title="组织信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="rules" :model="deptlist" ref="deptform" label-width="100px">
        <el-form-item label="名称" prop="deptname">
          <el-input v-model="deptlist.deptname" class="sernameval"></el-input>
        </el-form-item>
        <div class="btn-bottom">
          <el-button type="primary" plain  @click="saveDept" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeDept" class="btnbutton">取消</el-button>
        </div>
      </el-form>
    </el-dialog> 
    <el-dialog title="人员信息" v-model="dialogTableVisibleuser" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form ref="userFormRef" :model="userinfo" :rules="userrules" label-width="100px">
        <el-form-item label="姓名:" prop="userName" class="userdiv">
          <el-input v-model="userinfo.userName" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="登录名:" prop="userCode" class="userdiv">
          <el-input v-model="userinfo.userCode" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="邮箱:" prop="userEmail" class="userdiv">
          <el-input v-model="userinfo.userEmail" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="手机号:" prop="userTel" class="userdiv">
          <el-input v-model="userinfo.userTel" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="用户密码:" prop="userPassword" class="userdiv">
          <el-input v-model="userinfo.userPassword" show-password class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="确认密码:" prop="surePassword" class="userdiv">
          <el-input v-model="userinfo.surePassword" show-password class="sernameval"></el-input>
        </el-form-item>
        <div class="btn-bottom">
            <el-button type="primary" plain  @click="submituser(userFormRef)" class="btnbutton">保存</el-button>
            <el-button type="primary" plain  @click="closeuser" class="btnbutton">取消</el-button>
        </div>
      </el-form>
    </el-dialog>
    <el-dialog title="人员信息" v-model="dialogTableVisibleuseredit" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="userrulesedit" :model="userinfo" ref="userFormEdit"  label-width="100px">
        <el-form-item label="姓名:" prop="userName" class="userdiv">
          <el-input v-model="userinfo.userName" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="登录名:" prop="userCode" class="userdiv">
          <el-input v-model="userinfo.userCode" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="邮箱:" prop="userEmail" class="userdiv">
          <el-input v-model="userinfo.userEmail" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="手机号:" prop="userTel" class="userdiv">
          <el-input v-model="userinfo.userTel" class="sernameval"></el-input>
        </el-form-item>
        <div class="btn-bottom">
            <el-button type="primary" plain  @click="submituseredit" class="btnbutton">保存</el-button>
            <el-button type="primary" plain  @click="closeuseredit" class="btnbutton">取消</el-button>
        </div>
      </el-form>
    </el-dialog>
     <el-dialog title="人员信息" v-model="dialogTableVisibleuserpass" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="userrulespass" :model="userinfo" ref="userFormPass"  label-width="100px">
        <el-form-item label="用户密码:" prop="userPassword" class="userdiv">
          <el-input v-model="userinfo.userPassword" show-password class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="确认密码:" prop="surePassword" class="userdiv">
          <el-input v-model="userinfo.surePassword" show-password class="sernameval"></el-input>
        </el-form-item>
        <div class="btn-bottom">
            <el-button type="primary" plain  @click="submituserpass" class="btnbutton">保存</el-button>
            <el-button type="primary" plain  @click="closeuserpass" class="btnbutton">取消</el-button>
        </div>
      </el-form>
    </el-dialog>
    <el-dialog title="角色列表" v-model="dialogTableVisibleuserrole" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-input v-model="rolenamevalue" class="sernameval" style="width:200px;" placeholder="请输入角色名称"></el-input>
      <el-button type="primary" plain  style="margin-left:10px;" class="btnbutton" @click="searchrolelist()">搜索</el-button>
      <el-table :data="roleData" ref="multipleTable" 
      @selection-change="chooseRole" style="width: 100%;">
      <el-table-column type="selection"></el-table-column>
      <el-table-column prop="roleName" label="角色名称"></el-table-column>
      </el-table>
      <div class="tabListPage">
        <el-pagination @size-change="rolehandleSizeChange"
                     @current-change="rolehandleCurrentChange"
                     :current-page="rolecurrentPage"
                     :page-sizes="rolepageSizes"
                     :page-size="rolePageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="roletotalCount">
        </el-pagination>
      </div>
      <div style="margin-top:20px;text-align: center;">
        <el-button type="primary" plain  class="btnbutton" @click="addrolevalue">确定</el-button>
        <el-button type="primary" plain  class="btnbutton" @click="closerolediv">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import{ defineComponent,toRefs,reactive, onMounted,ref,watch,unref,getCurrentInstance }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {findDeptList,saveauthArray,getauthlist,getRoleList,userDelete,userUpdate,deleteDept,findDeptById,saveDeptList,updateDeptlist,getUserArray,getUserById,userSave} from "@/api/system";
import {ElMessage,ElTree,ElMessageBox,ElForm,message,ElTable} from 'element-plus'
export default {
    setup: () => {
        const { proxy } = getCurrentInstance()
        const deptform =ref(null);
        const userFormRef= ref(null);
        const userFormEdit=ref(null);
         const userFormPass=ref(null);
        const state = reactive({
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            rolecurrentPage:1,
            rolepageSize:10,
            roletotalCount:0,
            filterText:"",
            dialogTableVisible:false,
            dialogTableVisibleuser:false,
            dialogTableVisibleuseredit:false,
            dialogTableVisibleuserpass:false,
            dialogTableVisibleuserrole:false,
            deptlist:{
              deptid:"",
              deptname:"",
            },
            datatree:[],
            roleData:[],
            datas:[],
            deptpid:"0",
            userinfo:{
              userName:"",
              userCode:"",
              userEmail:"",
              userTel:"",
              userPassword:"",
              surePassword:""
            },
            deptid:"",
            isedit:false,
            namevalue:"",
            dataArraylist:[] ,
            currentDeptId:"",
            currenteditId:"",
            rules:{
              deptname: [{ required: true, message: '请输入名称', trigger: 'blur' }]
            },
            userrules:{
              userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
              userCode: [{ required: true, message: '请输入登录名', trigger: 'blur' }],
              userEmail: [{ required: true, message: '请输入邮箱', trigger: 'blur' }],
              userTel: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
              userPassword: [{ required: true, message: '请输入密码', trigger: 'blur' }],
              surePassword: [{ required: true, message: '请输入确认密码', trigger: 'blur' }],
            },
            userrulesedit:{
              userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
              userCode: [{ required: true, message: '请输入登录名', trigger: 'blur' }],
              userEmail: [{ required: true, message: '请输入邮箱', trigger: 'blur' }],
              userTel: [{ required: true, message: '请输入手机号', trigger: 'blur' }]
            },
            userrulespass:{
              userPassword: [{ required: true, message: '请输入密码', trigger: 'blur' }],
              surePassword: [{ required: true, message: '请输入确认密码', trigger: 'blur' }]
            },
            rolenamevalue:"",
            checkUserRolelist:[],
            userId:"",
            isAdd:false,
            currentId:""
        })
        onMounted(() => {
          getDeptList();
          getUserList();
          getRoleListarray();
        })
        const searuserlist=()=>{
            getUserList();
        }

        const adddept=()=>{
          state.dialogTableVisible=true;
          state.deptpid="0";
          state.isedit=false;
        }
        const closerolediv=()=>{
          state.dialogTableVisibleuserrole=false;
        }
        const updateNode=(nodevalue)=>{
          console.log(nodevalue);
          state.isedit=true;
          state.dialogTableVisible=true;
          state.deptpid=nodevalue.data.pId;
          state.deptlist.deptid=nodevalue.data.id;
          state.deptlist.deptname=nodevalue.data.label;
        }
        const resetPass=(index,row)=>{
          console.log(row);
          state.currentId=row.id;
          state.dialogTableVisibleuserpass=true;
        }
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.id);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        const deleteDataById=async(rowid)=>{
           var param={
             id:rowid
           }
           let res=await userDelete(param);
            if(res.code==20000){
              getUserList();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        const saveDept=async()=>{
          const form = unref(deptform);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param = {
              id:state.deptlist.deptid,
              pid:state.deptpid,
              name:state.deptlist.deptname
            }
            if(state.isedit){
              let msg=await updateDeptlist(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '保存成功',
                })
                state.dialogTableVisible=false;
                getDeptList();
              }
            }else{
              let msg=await saveDeptList(param);
              if(msg.code=20000){
                ElMessage({
                    type: 'success',
                    message: '修改成功',
                })
                state.dialogTableVisible=false;
                getDeptList();
              }
            }
          }catch (error) {

          }
        }
        const handleEdit=(index,row)=>{
          state.userinfo.userName=row.userName;
          state.userinfo.userCode=row.userCode;
          state.userinfo.userEmail=row.userEmail;
          state.userinfo.userTel=row.userTel;
          state.currenteditId=row.id;
          state.dialogTableVisibleuseredit=true;
        }
        const submituseredit=async()=>{
          const form = unref(userFormEdit);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param = {
              id:state.currenteditId,
              userCode: state.userinfo.userCode,
              userEmail: state.userinfo.userEmail,
              userName: state.userinfo.userName,
              userTel: state.userinfo.userTel
            }
            let msg=await userUpdate(param);
            if(msg.code=20000){
              ElMessage({
                type: 'success',
                message: '修改成功',
              })
              state.dialogTableVisibleuseredit=false;
              getUserList();
            }
          }catch (error) {

          }
        }
        const submituserpass=async()=>{
          const form = unref(userFormPass);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param = {
              id:state.currentId,
              userPassword: state.userinfo.userPassword,
            }
            let msg=await userUpdate(param);
            if(msg.code=20000){
              ElMessage({
                type: 'success',
                message: '修改成功',
              })
              state.dialogTableVisibleuserpass=false;
              getUserList();
            }
          }catch (error) {

          }
        }
        const submituser=async()=>{
          const form = unref(userFormRef);//获取验证规则
           if (!form) return
          try {
            await form.validate();//表单验证
            if(state.userinfo.userPassword!=state.userinfo.surePassword){
              ElMessage({
                type: 'info',
                message: '俩次输入密码不一致！',
              })
              return
            }
            var param = {
              deptId: state.currentDeptId,
              userCode: state.userinfo.userCode,
              userEmail: state.userinfo.userEmail,
              userName: state.userinfo.userName,
              userPassword: state.userinfo.userPassword,
              userTel: state.userinfo.userTel
            }
            let msg=await userSave(param);
            if(msg.code=20000){
              ElMessage({
                type: 'success',
                message: '添加成功',
              })
              state.dialogTableVisibleuser=false;
              getUserList();
            }
          }catch (error) {

          }
        }
        const addrolevalue=async()=>{
          if(state.checkUserRolelist.length>0){
            let checkDatas=[];
            for(let index=0; index<state.checkUserRolelist.length; index++){
              checkDatas[index]={'userId':state.userId,'roleId':state.checkUserRolelist[index].id}
            }
            let res=await saveauthArray(checkDatas);
            if(res.code=20000){
              ElMessage({
                type: 'success',
                message: '添加成功',
              })
              state.dialogTableVisibleuserrole=false;
            }
          }else{
            ElMessage({
                type: 'info',
                message: '请选择角色进行权限配置!',
            })
          }
        }
        const searchrolelist=()=>{
          getRoleListarray();
        }
        const getRoleListarray=async()=>{
          var param = {
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            roleName:state.rolenamevalue
          }
           let msg=await getRoleList(param);
           if(msg.code=20000){
             console.log(msg);
             state.roleData=msg.data.records;
             state.roletotalCount=msg.data.total;
           }
        }
        const getUserList=async()=>{
          var param = {
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            userName:state.namevalue
          }
           let msg=await getUserArray(param);
           if(msg.code=20000){
             state.tableData=msg.data.records;
             state.totalCount=msg.data.total;
           }
        }
        const closeDept=async()=>{
          state.dialogTableVisible=false;
        }
        //遍历父节点
        const getListData =()=> {
              let dataArray = [];
              state.datas.forEach(function (data) {
              if(true){
                  var deptpid = data.pid;
                    if (deptpid == "0") {
                      let objTemp = {
                          id: data.id,
                          label: data.name,
                          pId: deptpid,
                      }
                      dataArray.push(objTemp);
                    }
                }
            })
            data2treeDG(state.datas, dataArray)
          }
          //递归子节点
          const data2treeDG=(datas, dataArray)=>{
              for (let j = 0; j < dataArray.length; j++) {
                let dataArrayIndex = dataArray[j];
                let childrenArray = [];
                let id = dataArrayIndex.id;
                for (let i = 0; i < datas.length; i++) {
                  let data = datas[i];
                  if(true){
                    let pId = data.pid;
                    if (pId == id) {//判断是否为儿子节点
                      let objTemp = {
                        id: data.id,
                        label: data.name,
                        pId: pId,
                      }
                      childrenArray.push(objTemp);
                    }
                  }
              }
              dataArrayIndex.children = childrenArray;
              if (childrenArray.length > 0) {
                //有儿子节点则递归
                data2treeDG(state.datas, childrenArray)
              }
            }
          state.datatree = dataArray;
        }
        const getDeptList=async()=>{
           var param = {}
           let msg=await findDeptList(param);
           if(msg.code=20000){
             state.datas=msg.data.records;
             getListData();
           }
        }
        const chooseRole=(val)=> {
          if(val.length>0){
            state.checkUserRolelist=val;
          }
        }

        const deleteNode=async(nodevalue)=>{
          var deptid=nodevalue.data.id;
          ElMessageBox.confirm("是否删除该部门, 是否继续?", '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(async() => {
            var param = {
              id:deptid
            }
            let res=await findDeptById(param);
            if (res.data.total>0) {
                ElMessage({
                  message: '存在子部门不能删除！',
                  type: 'info',
                })
            } else {
              var paramval = {
                pageNum:1,
                pageSize:10,
                deptIdStr:deptid
              }
              let msg=await getUserById(paramval);
              if(msg.data.total>0){
                ElMessage({
                  message: '该部门下存在人员不能删除',
                  type: 'info',
                })
              }else{
                var delparam = {
                  id:deptid
                }
                let msg=await deleteDept(delparam);
                if (msg.code == 20000) {
                  ElMessage({
                    message: '删除成功！',
                    type: 'success',
                  })
                  getDeptList();
                }
              }
            }
          }).catch(() => {

          });

        }
        const addSameLevelNode=async(nodevalue)=>{
          state.dialogTableVisible=true;
          state.deptpid=nodevalue.data.pId;
        }
        const addChildNode=async(nodevalue)=>{
          state.dialogTableVisible=true;
          state.deptpid=nodevalue.data.id;
        }
        const adduser=()=>{
          state.dialogTableVisibleuser=true;
        }
        const closeuser=()=>{
          state.dialogTableVisibleuser=false;
        }
        const closeuserpass=()=>{
          state.dialogTableVisibleuserpass=false;
        }
        const closeuseredit=()=>{
          state.dialogTableVisibleuseredit=false;
        }
         // 鼠标左击事件
        const handleLeftclick =async(data, node)=> {
          state.isAdd=true;
          let expancurrentid=data.id;
          state.currentDeptId=data.id;
          state.dataArraylist = [];
          state.datas.forEach(function (data) {
            if(true){
              let assetsId = data.id;
              let assetsPid = data.pid;
              if (assetsPid == expancurrentid) {
                  let objTemp = {
                    id: data.id,
                  }
                  state.dataArraylist.push(objTemp);
              }
            }
          })
          data2treeDGNode(state.datas, state.dataArraylist);
          state.dataArraylist.push({id:data.id});
          getUserListDataById(state.pageSize,state.currentPage,state.namevalue,state.dataArraylist);
        }
        const getUserListDataById=async(size,page,pointName,dataarry)=>{
          state.tableData=[];
          state.pageSize=size;
          // 显示第几页
          state.currentPage=page;
          let idstr="";
          dataarry.forEach((item, index, arr) => {
            idstr += item.id+",";
          })
          var param = {
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            userName:state.namevalue,
            deptIdStr:idstr
          }
           let msg=await getUserById(param);
           if(msg.code=20000){
             state.tableData=msg.data.records;
             state.totalCount=msg.data.total;
          }
        }
        //递归子节点
        const data2treeDGNode= async(datas, dataArray)=> {
              for (let j = 0; j < dataArray.length; j++) {
                let dataArrayIndex = dataArray[j];
                let childrenArray = [];
                let id = dataArrayIndex.id;
                for (let i = 0; i < datas.length; i++) {
                  let data = datas[i];
                  if(true){
                    let pId = data.pid;
                    if (pId == id) {//判断是否为儿子节点
                      let objTemp = {
                        id: data.id,
                      }
                      dataArray.push(objTemp);
                    }
                  }
              }
              dataArrayIndex= dataArray;
              if (childrenArray.length > 0) {
                //有儿子节点则递归
                  data2treeDGNode(datas, childrenArray)
              }
            }
        }
        const handleSet=(index,row)=>{
          state.userId=row.id;
          state.dialogTableVisibleuserrole=true;
          checkroledata(state.userId);
        }
        const checkroledata=async(userCid)=> {
           var param = {
            userId:userCid
          }
           let msg=await getauthlist(param);
           if(msg.code=20000){
             for(var number=0;number<msg.data.total;number++){
                for(let numberval=0;numberval<state.roleData.length;numberval++){
                  if(msg.data.records[number].id==state.roleData[numberval].id){
                    setTimeout(() => {
                      proxy.$refs.multipleTable.toggleRowSelection(state.roleData[numberval],true);
                    }, 300);
                  }
                }
             }
          }
        }
        return {
            ...toRefs(state),
            handleLeftclick,
            data2treeDG,
            adddept,
            addSameLevelNode,
            addChildNode,
            deleteNode,
            saveDept,
            closeDept,
            deptform,
            searuserlist,
            data2treeDGNode,
            adduser,
            closeuser,
            userFormRef,
            handleEdit,
            closeuseredit,
            submituseredit,
            userFormEdit,
            handleDelete,
            deleteDataById,
            submituser,
            handleSet,
            closerolediv,
            searchrolelist,
            chooseRole,
            addrolevalue,
            checkroledata,
            updateNode,
            resetPass,
            submituserpass,
            userFormPass,
            closeuserpass
        }
    }
}
</script>

<style>
.userdiv{
  margin-bottom: 13px;
}
.btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}


.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
  padding: 5px;
}
.custom-tree-node .do i:hover {
  color: #333;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.el-pagination .el-pager .number.active {
    background-color: white;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
</style>