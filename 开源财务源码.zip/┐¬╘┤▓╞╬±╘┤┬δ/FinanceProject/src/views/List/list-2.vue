<template>
    <div style="width:580px;float:left;">
        <el-input v-model="namevalue" class="sernameval" style="width:70%;" placeholder="请输入角色名称" />
        <el-button type="primary" plain  @click="searchname" class="btnbutton">搜索</el-button>
        <el-button type="primary" plain  @click="addrole" style="margin-left:10px;" class="btnbutton">添加</el-button>
    </div>
    <el-table
    :data="tableData"
    :row-style="{height:'35px'}"
    :cell-style="{padding:'0px'}"
    border
    style="width: 100%">
    <el-table-column  prop="roleName" label="角色名称" align="center" ></el-table-column>
    <el-table-column
      fixed="right"
      label="操作">
      <template #default="scope">
        <el-button @click="handleEdit(scope.$index, scope.row)" plain  type="primary" size="small" class="btnbutton">权限配置</el-button>
        <el-button @click="handleDelete(scope.$index, scope.row)" plain  type="danger" size="small" class="btnbutton">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <!-- 分页底部 -->
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[5,10,15]"
      :page-size="pageSize"
      layout="total,jumper,prev, pager, next,sizes"
      :total="totalCount"
  ></el-pagination>
  <el-dialog title="角色信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="rules" :model="rolelist" ref="roleform" label-width="100px">
        <el-form-item label="角色名称" prop="rolename">
          <el-input v-model="rolelist.rolename" class="sernameval"></el-input>
        </el-form-item>
        <div class="examdiv">
          <el-button type="primary" plain  @click="saveRoleMsg" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeRole" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
  <el-dialog title="菜单列表" v-model="dialogTableVisibleTree" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
    <el-tree
       ref="treeRef"
      :data="menulistTree"
      show-checkbox
      node-key="id"
      :default-checked-keys="checkdatalist"
      @check="handleCheckChange"
    />
    <div class="examdiv" style="margin-top:20px;">
          <el-button type="primary" plain  @click="saveRoleData" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeRoleData" class="btnbutton">取消</el-button>
        </div>
  </el-dialog>
</template>
<script>
import{ defineComponent,toRefs,reactive, onMounted,ref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getRoleList,updateRole,saveRole,deleteRole,getMenuTree,savelist,findUserRole} from "@/api/system";
import { async } from "q";
import Row from 'element-plus/lib/el-row';
import { ElMessageBox, ElMessage,ElTree} from 'element-plus'
export default{
    name: "userlist",
    setup: () => {
        const roleform =ref(null);
        const state = reactive({
            tableData: [],
            currentPage:1,
            pageSize:10,
            totalCount:0,
            isEdit:false,
            namevalue:"",
            rolelist:{
              id:"",
              rolename:""
            },
            dialogTableVisible:false,
            dialogTableVisibleTree:false,
            rules:{
                rolename: [{ required: true, message: '请输入角色名称', trigger: 'blur' }]
            },
            roleId:"",
            menulistTree:[],
            checkMenuData:[],
            checkdatalist:[],
            currentRoleId:""
        })
        onMounted(() => {
          getPageList();
        })
        //加载仓库列表
        const getPageList=async()=>{
          var paramdata={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            roleName:state.namevalue
          }
          let res=await getRoleList(paramdata);
          if(res.code==200){
            state.tableData=res.data.records;
            state.totalCount=res.data.total;
          }
        }
        const saveRoleData=async()=>{
          var param={}
          let res=await savelist(state.checkMenuData);
          ElMessage({
            type: 'success',
            message: '保存成功',
          })
          state.dialogTableVisibleTree=false;
        }
        const closeRoleData=()=>{
          state.dialogTableVisibleTree=false;
        }
        //新增表格
        const addrole=()=>{
          clearform();
          state.isEdit=false;
          state.dialogTableVisible=true;
        }
        //关闭对话框
        const closeRole=()=>{
          state.dialogTableVisible=false;
        }
        //保存
        const saveRoleMsg=async()=>{
          var param={
            id:state.rolelist.id,
            roleName:state.rolelist.rolename
          }
          if(state.isEdit){
            let res=await updateRole(param);
            if(res.code==20000){
              ElMessage({
                type: 'success',
                message: '编辑成功',
              })
            }
          }else{
            let res=await saveRole(param);
            if(res.code==20000){
              ElMessage({
                type: 'success',
                message: '新增成功',
              })
            }
          }
          state.dialogTableVisible=false;
          getPageList();
        }
        const searchname=()=>{
          getPageList();
        }
         //加载结算明细列表
        const getMenuTreeList=async()=>{
         
          var param={}
          let res=await getMenuTree(param);
          if(res.code==20000){
            state.menulistTree=res.data.records;
          }
        }
         const getMenuArrayList=async(roleId)=>{
          var param={
              pageNum: 1,
              pageSize: 1000,
              roleId:roleId
          }
          let res=await findUserRole(param);
          if(res.code==200){
            console.log(res);
            if(res.data.total<=0){
              state.checkdatalist=[];
            }else{
              state.checkdatalist=[];
              for(let index=0; index<res.data.total; index++){
                if(res.data.records[index].level!="0"){
                  console.log(res.data.records[index].menuId);
                  state.checkdatalist.push(res.data.records[index].menuId);
                }
              }
            }
            getMenuTreeList();
          }
        }
        const handleCheckChange=async(data, checked) =>{
          let numbercount=1;
          state.checkMenuData=[];
          for(let index=0; index<checked.checkedKeys.length; index++){
            state.checkMenuData[index]={'roleId':state.roleId,'menuId':checked.checkedKeys[index]}
            numbercount=parseFloat(numbercount)+1;
          }
          for(let numval=0; numval<checked.halfCheckedKeys.length; numval++){
            numbercount=parseFloat(state.checkMenuData.length);
            state.checkMenuData[numbercount]={'roleId':state.roleId,'menuId':checked.halfCheckedKeys[numval]}
          }
        }
        //删除
        const handleDelete=(index,row)=> {
          ElMessageBox.confirm(
          '确认删除这条数据吗?',
          'Warning',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(async() => {
             deleteDataById(row.id);
             console.log(111);
          })
          .catch(() => {
            ElMessage({
              type: 'info',
              message: '已经取消',
            })
          })
        }
        //编辑
        const handleEdit=(index,row)=>{
          
          state.roleId=row.id;
          state.dialogTableVisibleTree=true;
          getMenuArrayList(state.roleId);
        }
        const deleteDataById=async(rowid)=>{
           var param={
             id:rowid
           }
           let res=await deleteRole(param);
            if(res.code==20000){
              getPageList();
              ElMessage({
                type: 'success',
                message: '删除成功',
              })
            }
        }
        //清楚表单的值
        const clearform=()=>{
          state.rolelist.id="";
          state.rolelist.rolename="";
        }
        //分页 初始页currentPage、初始每页数据数pagesize和数据testpage--->控制每页几条
        const handleSizeChange = (size) => {
           state.pageSize = size;
           getPageList();
        }
         // 控制页面的切换
        const handleCurrentChange = (currentPage) => {
            state.currentPage = currentPage;
            getPageList();
        }
        return {
            ...toRefs(state),
            addrole,
            handleDelete,
            roleform,
            closeRole,
            saveRole,
            getPageList,
            handleCurrentChange,
            handleSizeChange,
            handleEdit,
            clearform,
            deleteDataById,
            searchname,
            saveRoleMsg,
            handleCheckChange,
            getMenuTreeList,
            closeRoleData,
            saveRoleData,
            getMenuArrayList
        }
    }
}
</script>
<style>
.tbline{
  height: 35px;
  width: 100%;
}
.tbinput.el-input__inner{   /*或者 .s2>>>.el-input__inner  */
  margin-top: -8px;
  height: 13px;
  width: 100%;
}
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
 .btndel.el-button {
    display: inline-block;
    line-height: 6px;
    min-height: 28px;
    white-space: nowrap;
    border: 1px solid #DCDFE6;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    background-color: red;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.examdiv{
    text-align: center;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btndel.el-button--primary{
    height: 28px;
    color: #fff;
  }
</style>