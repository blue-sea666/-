<template>
  <div class="bodydiv" style="width:100%;height:100%;">
    <div class="bodyleft" style="width:25%;height:100%;border-right: 3px solid #DCDFE6;float:left;margin-top:-10px;">
      <el-input v-model="filterText" class="sernameval" style="width:180px;" placeholder="Filter keyword" />
      <el-button type="primary" plain  @click="addmenu" style="margin-top:3px;" class="btnbutton">添加</el-button>
      <el-tree
         ref="treeRef"
         class="filter-tree"
         :data="datatree"
         :props="defaultProps"
         default-expand-all
         @node-click="handleNodeClick"
         :filter-node-method="filterNode">
          <template #default="{node,datatree}" >
             <span class="custom-tree-node el-tree-node__label">
                <span class="label">
                  {{ node.label }}
                </span>
                <el-dropdown>
                <span class="do">
                   <i class="el-icon-plus"></i>
                </span>
                  <template #dropdown  style="marign-left:120px;">
                    <el-dropdown-menu>
                      <el-dropdown-item @click.native="addSameLevelNode(node)">新增同级</el-dropdown-item>
                      <el-dropdown-item @click.native="addChildNode(node)">新增下级</el-dropdown-item>
                      <el-dropdown-item @click.native="deleteNode(node)">删除</el-dropdown-item>
                    </el-dropdown-menu>
                  </template>
                  </el-dropdown>
              </span>
        </template>
      </el-tree>
    </div>
    <div class="bodyright" v-show="isShow" style="width:70%;margin-left:20px;height:100%;float:left;">
      <el-form ref="formRef" :model="form" label-width="120px">
        <el-form-item label="菜单名称:">
          <el-input v-model="form.title" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="菜单别名:">
           <el-input v-model="form.label" class="sernameval"></el-input>
        </el-form-item>
         <el-form-item label="菜单路径:">
           <el-input v-model="form.path" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="菜单图标:">
           <el-input v-model="form.icon" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item label="菜单路由:">
           <el-input v-model="form.component" class="sernameval"></el-input>
        </el-form-item>
         <el-form-item label="菜单顺序:">
           <el-input v-model="form.sort" class="sernameval"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" plain  class="btnbutton" @click="onSubmit">确定</el-button>
          <el-button type="primary" plain  class="btnbutton">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
   <el-dialog title="菜单信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
      <el-form :rules="rules" :model="menulist" ref="menuform" label-width="100px">
        <el-form-item label="菜单名称" prop="menuname">
          <el-input v-model="menulist.menuname" class="sernameval"></el-input>
        </el-form-item>
        <div class="btn-bottom">
          <el-button type="primary" plain  @click="saveMenuNode" class="btnbutton">保存</el-button>
          <el-button type="primary" plain  @click="closeMenuNode" class="btnbutton">取消</el-button>
        </div>
      </el-form>
  </el-dialog>
</template>
<script lang="ts">
import{ defineComponent,toRefs,reactive, onMounted,ref,watch,unref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {getMenuTree,saveMenu,deleteMenu,findMenuById,updateMenu} from "@/api/system";
import {ElMessage,ElTree,ElMessageBox} from 'element-plus'
export default defineComponent({
    name: "userlist",
    setup: () => {
        interface Tree {
          id: number
          label: string
          children?: Tree[]
        }
        const treeRef = ref<InstanceType<typeof ElTree>>()
        const menuform =ref(null);
        const defaultProps = {
          children: 'children',
          label: 'label',
        }
        const state = reactive({
            filterText:"",
            locale:zhCn,
            isShow:false,
            searchname:"",
            dialogTableVisible:false,
            form:{
              id:"",
              label:"",
              title:"",
              path:"",
              icon:"",
              component:"",
              sort:""
            },
            menulist:{
              menuname:"",
            },
            datatree:[],
            rules:{
              menuname: [{ required: true, message: '请输入菜单名称', trigger: 'blur' }]
            },
            node:{
              level:"",
              pid:"",
              id:""
            },
            statelevel:"0",
        })
        onMounted(() => {
          getMenuTreeList();
        })
         //新增设备信息
        const saveMenuNode=async()=>{
          const form = unref(menuform);//获取验证规则
          if (!form) return
          try {
            var param=null;
            if(state.statelevel=="0"){
                param={
                label: state.menulist.menuname,
                title:state.menulist.menuname,
                level: 1,
                icon:"el-icon-s-tools",
                path: "/index",
                pid: "0"
              }
            }
             if(state.statelevel=="1"){
                param={
                component:"/index/list",
                label: state.menulist.menuname,
                title:state.menulist.menuname,
                level: state.statelevel,
                icon:"el-icon-s-tools",
                path: "/index",
                pid: state.node.pid,
              }
            }
          let res:any=await saveMenu(param);
          if(res.code==20000){
            ElMessage({
              message: '添加成功！',
              type: 'success',
            })
            getMenuTreeList();
            state.dialogTableVisible=false;
          }
          }catch (error) {

          }
        }
        const onSubmit=async()=>{
           var param={
            label:state.form.label,
            title:state.form.title,
            path:state.form.path,
            icon:state.form.icon,
            component:state.form.component,
            menuSort:state.form.sort,
            id:state.form.id
           }
           let res:any=await updateMenu(param);
            if(res.code==20000){
              ElMessage({
                message: '修改成功！',
                type: 'success',
              })
              getMenuTreeList();
            }
        }
        const addmenu=()=>{
          state.dialogTableVisible=true;
          state.statelevel="0";
        }
        //删除节点调用事件
        const delMenuById = async(menuid:any) => {
          var param = {
            id:menuid
          }
          let res:any=await findMenuById(param);
           if (res.data.total>0) {
              ElMessage({
                message: '存在子菜单不能删除！',
                type: 'info',
              })
            } else {
               var delparam = {
                id:menuid
              }
              let msg:any=await deleteMenu(delparam);
              if (msg.code == 20000) {
                ElMessage({
                  message: '删除成功！',
                  type: 'success',
                })
                getMenuTreeList();
              }
            }
        }

        const deleteNode=async(nodevalue:any)=>{
          var menuid=nodevalue.data.id;
          ElMessageBox.confirm("是否删除该菜单, 是否继续?", '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            delMenuById(menuid);
          }).catch(() => {

          });

        }
        const addSameLevelNode=async(nodevalue:any)=>{
          state.node.pid=nodevalue.data.pid;
          state.node.level=nodevalue.data.level;
          state.dialogTableVisible=true;
          if(nodevalue.pid=="0"){
            state.statelevel="0";
          }else{
            state.statelevel="1";
          }
        }
        const addChildNode=async(nodevalue:any)=>{
          console.log(nodevalue);
          state.node.pid=nodevalue.data.id;
          state.node.level=nodevalue.data.level;
          state.dialogTableVisible=true;
          state.statelevel="1";
        }
        const closeMenuNode=()=>{
          state.dialogTableVisible=false;
        }
        const handleNodeClick = (data:any) => {
          state.form.label=data.label;
          state.form.title=data.title;
          state.form.icon=data.icon;
          state.form.component=data.component;
          state.form.path=data.path;
          state.form.id=data.id;
          state.form.sort=data.menuSort;
          state.isShow=true;
        }
         //加载结算明细列表
        const getMenuTreeList=async()=>{
         
          var param={}
          let res:any=await getMenuTree(param);
          if(res.code==20000){
            state.datatree=res.data.records;
          }
        }
        const filterNode = (value: string, data: Tree) => {
          if (!value) return true
          return data.label.indexOf(value) !== -1
        }
        return {
            ...toRefs(state),
            handleNodeClick,
            getMenuTreeList,
            addmenu,
            closeMenuNode,
            menuform,
            addSameLevelNode,
            saveMenuNode,
            addChildNode,
            delMenuById,
            deleteNode,
            onSubmit
        }
    }
})
</script>

<style>
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}


.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
  padding: 5px;
}
.custom-tree-node .do i:hover {
  color: #333;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.el-pagination .el-pager .number.active {
    background-color: white;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
</style>