<template>
     <div class="bodydiv" style="width:100%;height:100%;">
        <div class="bodyleft" style="width:30%;height:100%;border-right: 3px solid #DCDFE6;min-height:1000px;float:left;">
          <el-input v-model="filterText" class="sernameval" style="width:180px;" placeholder="Filter keyword" />
          <el-button type="primary" plain   @click="addsubject" style="margin-top:3px;" class="btnbutton">添加科目</el-button>
          <el-tree
            ref="treeRef"
            class="filter-tree"
            :data="treeDatalist"
            :props="defaultProps"
            @node-click="handleNodeClick"
            :filter-node-method="filterNode">
              <template #default="{node,treeDatalist}" >
                <span class="custom-tree-node el-tree-node__label">
                    <span class="label">
                      {{ node.label }}
                    </span>
                    <el-dropdown>
                    <span class="do">
                      <i class="el-icon-plus"></i>
                    </span>
                      <template #dropdown  style="marign-left:120px;">
                        <el-dropdown-menu>
                          <el-dropdown-item @click.native="addSameLevelNode(node)">新增同级</el-dropdown-item>
                          <el-dropdown-item @click.native="addChildNode(node)">新增下级</el-dropdown-item>
                          <el-dropdown-item @click.native="updateNode(node)">编辑</el-dropdown-item>
                          <el-dropdown-item @click.native="deleteNode(node)">删除</el-dropdown-item>
                        </el-dropdown-menu>
                      </template>
                      </el-dropdown>
                  </span>
            </template>
          </el-tree>
        </div>
        <div class="bodyright" v-show="isShow" style="width:60%;margin-left:20px;height:100%;float:left;">
          <el-form ref="formRef" :model="form" label-width="120px">
            <el-form-item label="科目编号:">
              <el-input v-model="form.SubjectCode" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="科目名称:">
              <el-input v-model="form.SubjectName" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="科目全名:">
              <el-input v-model="form.SubjectFullname" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="助记码:">
              <el-input v-model="form.MnemonicCode" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="科目类别:">
              <el-select v-model="form.cateName" class="sernameval" @change="changeCategory($event)" placeholder="请选择">
                <el-option
                  v-for="item in optionsvalue"
                  :key="item.id"
                  :label="item.cateName"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="余额方向:">
              <el-select v-model="form.BalanceDirection" class="sernameval" @change="changeBalanceDirection($event)" placeholder="请选择">
                <el-option
                  v-for="item in BalanceDirectionList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="辅助核算:">
              <el-select v-model="form.AccountStatus" class="sernameval" @change="changeAccountStatus($event)" placeholder="请选择">
                <el-option
                  v-for="item in AccountStatusList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <!-- <el-form-item label="外币核算:">
              <el-input v-model="form.ForeignAccount" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="期末调汇:">
              <el-input v-model="form.EndExchange" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="往来业务核算:">
              <el-input v-model="form.TransAccount" class="sernameval"></el-input>
            </el-form-item> -->
            <el-form-item>
              <el-button type="primary" plain   class="btnbutton" @click="onSubmit">确定</el-button>
              <el-button type="primary" plain   class="btnbutton">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <el-dialog title="科目信息" v-model="dialogTableVisible" center :append-to-body='true' :close-on-click-modal="false"  :lock-scroll="true" width="40%" height="800px">
          <el-form ref="subjectform" :rules="rules" :model="subjectlist" label-width="100px">
            <el-form-item label="科目名称" prop="addsubjectname">
              <el-input v-model="subjectlist.addsubjectname" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="科目编号:" prop="addSubjectCode">
              <el-input v-model="subjectlist.addSubjectCode" class="sernameval"></el-input>
            </el-form-item>
             <el-form-item label="科目类别:" prop="addcateName">
              <el-select v-model="subjectlist.addcateName" style="width:360px;" class="sernameval" @change="addchangeCategory($event)" placeholder="请选择">
                <el-option
                  v-for="item in optionsvalue"
                  :key="item.id"
                  :label="item.cateName"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="余额方向:" prop="addBalanceDirection">
              <el-select v-model="subjectlist.addBalanceDirection" style="width:360px;" class="sernameval" @change="addchangeBalanceDirection($event)" placeholder="请选择">
                <el-option
                  v-for="item in BalanceDirectionList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="辅助核算:" prop="addAccountStatus">
              <el-select v-model="subjectlist.addAccountStatus" style="width:360px;" class="sernameval" @change="addchangeAccountStatus($event)" placeholder="请选择">
                <el-option
                  v-for="item in AccountStatusList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <div class="btn-bottom">
              <el-button type="primary" plain   @click="saveSubjectNode" class="btnbutton">保存</el-button>
              <el-button type="primary" plain   @click="closeSubjectNode" class="btnbutton">取消</el-button>
            </div>
          </el-form>
      </el-dialog>
</template>

<script>
import{ defineComponent,toRefs,reactive, onMounted,ref,watch,unref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {addSubject,deleteSubject,getSubjectList,updateSubject,getSubjectCategoryList,getSubjectByCondition} from "../api/system/index";
import {ElMessage,ElTree,ElMessageBox} from 'element-plus'
export default{
    name: "userlist",
    setup: () => {
        const subjectform =ref(null);
        const state = reactive({
            datas:[],
            treeDatalist:[],
            filterText:"",
            locale:zhCn,
            isShow:false,
            searchname:"",
            dialogTableVisible:false,
            optionsvalue:[],
            currentPage:1,
            pageSize:10,
            form:{
              cateid:"",
              cateName:"",
              subjectid:"",
              SubjectCode:"",
              SubjectName:"",
              SubjectFullname:"",
              MnemonicCode:"",
              SubjectCategory:"",
              BalanceDirection:"",
              BalanceDirectionValue:"",
              ForeignAccount:0,
              EndExchange:0,
              TransAccount:0,
              CountmoneAccount:0,
              AccountStatus:"",
              AccountStatusValue:""
            },
            BalanceDirectionList:[
              {
                  value: '1',
                  label: '借'
                }, {
                  value: '2',
                  label: '贷'
                }
            ],
            AccountStatusList:[ 
              {
                  value: '0',
                  label: '无'
              },
              {
                  value: '1',
                  label: '客户'
              }, {
                  value: '2',
                  label: '供应商'
              }
            ],
            datatree:[],
            rules:{
              addsubjectname: [{ required: true, message: '请输入科目名称', trigger: 'blur' }],
              addSubjectCode: [{ required: true, message: '请输入科目编号', trigger: 'blur' }],
              addBalanceDirection: [{ required: true, message: '请选择余额方向', trigger: 'blur' }],
              addAccountStatus: [{ required: true, message: '请选择辅助核算', trigger: 'blur' }]
            },
            subjectlist:{
              addcateid:"",
              addcateName:"",
              addsubjectname:"",
              addsubjectlevel:1,
              addsubjectid:"",
              addsubjectpid:"",
              addSubjectCode:"",
              addSubjectCategory:"",
              addBalanceDirection:"",
              addBalanceDirectionValue:"",
              addAccountStatus:"",
              addAccountStatusValue:""
            },
            statelevel:"0",
            isEdit:false
        })
        onMounted(() => {
          getSubjectListArray();
          getSubjectCategory();
        })
        const saveSubjectNode=async()=>{
          const form = unref(subjectform);//获取验证规则
          if (!form) return
          try {
            await form.validate();//表单验证
            var param=null;
            if(state.subjectlist.addsubjectlevel==1){
                param={
                id:state.subjectlist.addsubjectid,
                subjectName: state.subjectlist.addsubjectname,
                pid: "0",
                subjectLevel:1,
                subjectType:3,
                subjectCategory:state.subjectlist.addcateid,
                balanceDirection:state.subjectlist.addBalanceDirectionValue,
                subjectCode:state.subjectlist.addSubjectCode,
                subjectCategoryName:state.subjectlist.addcateName,
                accountStatus:state.subjectlist.addAccountStatusValue
              }
              
            }else{
               param={
                id:state.subjectlist.addsubjectid,
                subjectName: state.subjectlist.addsubjectname,
                pid: state.subjectlist.addsubjectpid,
                subjectLevel:state.subjectlist.addsubjectlevel,
                subjectType:3,
                subjectCategory:state.subjectlist.addcateid,
                balanceDirection:state.subjectlist.addBalanceDirectionValue,
                subjectCode:state.subjectlist.addSubjectCode,
                subjectCategoryName:state.subjectlist.addcateName,
                accountStatus:state.subjectlist.addAccountStatusValue
              }
            }
            if(state.isEdit){
                let res=await updateSubject(param);
                if(res.code==20000){
                ElMessage({
                    message: '修改成功！',
                    type: 'success',
                })
                getSubjectListArray();
                clearsubject();
                state.dialogTableVisible=false;
                }
            }else{
                let res=await addSubject(param);
                if(res.code==20000){
                ElMessage({
                    message: '添加成功！',
                    type: 'success',
                })
                clearsubject();
                getSubjectListArray();
                state.dialogTableVisible=false;
                }
            }
          }catch (error) {

          }
        }
        const getSubjectCategory=async()=>{
          var param={
            pageNum:1,
            pageSize:100,
          }
          var valuelsit = await getSubjectCategoryList(param)
          if (valuelsit.code == 200) {
            state.optionsvalue=valuelsit.data.records;
          }
        }
         //选择科目类型
        const changeCategory=async(e)=>{
          state.form.cateid=e;
          let obj = {};//定义对象集合
          obj = state.optionsvalue.find(project => {//projectlist 为Select遍历集合 project 为Select 遍历 对象
                return project.id === e; //筛选出匹配数据 返回对象
          });
          state.form.cateName=obj.cateName;
        }
        const changeBalanceDirection=(e)=>{
          state.form.BalanceDirectionValue=e;
        }
        const changeAccountStatus=(e)=>{
          state.form.AccountStatusValue=e;
        }
         //选择科目类型
        const addchangeCategory=async(e)=>{
          state.subjectlist.addcateid=e;
          let obj = {};//定义对象集合
          obj = state.optionsvalue.find(project => {//projectlist 为Select遍历集合 project 为Select 遍历 对象
                return project.id === e; //筛选出匹配数据 返回对象
          });
          state.subjectlist.addcateName=obj.cateName;
        }
        const addchangeBalanceDirection=(e)=>{
          state.subjectlist.addBalanceDirectionValue=e;
        }
        const addchangeAccountStatus=(e)=>{
          state.subjectlist.addAccountStatusValue=e;
        }
        const clearsubject=()=>{
         state.subjectlist.addsubjectname="";
         state.subjectlist.addsubjectlevel=1;
         state.subjectlist.addsubjectid="";
         state.subjectlist.addsubjectpid="";
         state.subjectlist.addcateid="";
         state.subjectlist.addBalanceDirectionValue="";
         state.subjectlist.addSubjectCode="";
         state.subjectlist.addcateName="";
         state.subjectlist.addAccountStatusValue="";
        }
        const onSubmit=async()=>{
           var param={
            id:state.form.subjectid,
            subjectCategory:state.form.cateid,
            subjectName:state.form.SubjectName,
            subjectFullname:state.form.SubjectFullname,
            balanceDirection:state.form.BalanceDirectionValue,
            subjectCode:state.form.SubjectCode,
            mnemonicCode:state.form.MnemonicCode,
            subjectCategoryName:state.form.cateName,
            AccountStatus:state.form.AccountStatusValue
           }
           let res=await updateSubject(param);
            if(res.code==20000){
              ElMessage({
                message: '修改成功！',
                type: 'success',
              })
            }
        }
        const addsubject=()=>{
          state.isEdit=false;
          state.dialogTableVisible=true;
          state.statelevel="0";
        }
        const deleteNode=async(nodevalue)=>{
          var id=nodevalue.data.id;
          ElMessageBox.confirm("是否删除该科目, 是否继续?", '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(async() => {
            //delMenuById(menuid);
           var param = {
            id:id,
            pageNum:1,
            pageSize:10
           }
           let res=await getSubjectList(param);
           if (res.data.total>0) {
              ElMessage({
                message: '存在子菜单不能删除！',
                type: 'info',
              })
            } else {
               var delparam = {
                id:id
              }
              let msg=await deleteSubject(delparam);
              if (msg.code == 20000) {
                ElMessage({
                  message: '删除成功！',
                  type: 'success',
                })
                clearsubject();
                getSubjectListArray();
              }
            }
          }).catch(() => {

          });

        }
        const updateNode=async(nodevalue)=>{
          clearsubject();
          state.isEdit=true;
          state.subjectlist.addsubjectid=nodevalue.data.id;
          state.subjectlist.addsubjectpid=nodevalue.data.pid;
          state.subjectlist.addsubjectlevel=nodevalue.data.level;
          state.subjectlist.addsubjectname=nodevalue.data.label;
          state.dialogTableVisible=true;
        }
        const addSameLevelNode=async(nodevalue)=>{
          clearsubject();
          state.isEdit=false;
          state.subjectlist.addsubjectpid=nodevalue.data.pid;
          state.subjectlist.addsubjectlevel=nodevalue.data.level;
          state.dialogTableVisible=true;
          if(state.nodelist.pid=="0"){
            state.subjectlist.addsubjectlevel=1;
          }
        }
        const addChildNode=async(nodevalue)=>{
          clearsubject();
          state.isEdit=false;
          state.subjectlist.addsubjectpid=nodevalue.data.id;
          state.subjectlist.addsubjectlevel= parseFloat(nodevalue.data.level)-1;
          state.dialogTableVisible=true;
        }
        const closeMenuNode=()=>{
          state.dialogTableVisible=false;
        }
        const handleNodeClick = (data) => {
          state.form.subjectid=data.id;
          state.form.SubjectName=data.label;
          state.isShow=true;
          getSubjectByConditionList();
        }
        const getSubjectByConditionList=async()=>{
           var param={
            pageNum:1,
            pageSize:10,
            id:state.form.subjectid
          }
          let res=await getSubjectByCondition(param);
          if(res.code==20000){
             state.form.SubjectName=res.data.records[0].subjectName;
             state.form.SubjectFullname=res.data.records[0].subjectFullname;
             state.form.SubjectCode=res.data.records[0].subjectCode;
             state.form.MnemonicCode=res.data.records[0].mnemonicCode;
             state.form.BalanceDirectionValue=res.data.records[0].balanceDirection;
             state.form.cateid=res.data.records[0].subjectCategory;
             state.form.cateName=res.data.records[0].subjectCategoryName;
             if(res.data.records[0].balanceDirection=="1"){
                state.form.BalanceDirection="借";
             }
            if(res.data.records[0].balanceDirection=="2"){
                state.form.BalanceDirection="贷";
            }
            if(res.data.records[0].accountStatus=="0"){
                state.form.AccountStatus="无";
             }
            if(res.data.records[0].accountStatus=="1"){
                state.form.AccountStatus="客户";
            }
            if(res.data.records[0].accountStatus=="2"){
                state.form.AccountStatus="供应商";
            }
          }
        }
         //加载结算明细列表
        const getSubjectListArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            subjectType:3
          }
          let res=await getSubjectList(param);
          if(res.code==20000){
            state.datas=res.data.records;
            getListData();
          }
        }
        const filterNode = (value, data) => {
          if (!value) return true
          return data.label.indexOf(value) !== -1
        }
        const closeSubjectNode=()=>{
          state.dialogTableVisible=false;
        }
        //遍历父节点
        const getListData =()=> {
          let dataArray = [];
          state.datas.forEach(function (data) {
            if(true){
              let Pid = data.pid;
              if (Pid == "0") {
                let objTemp = {
                  id: data.id,
                  label: data.subjectName,
                  pid: Pid,
                  level:data.subjectLevel
                }
                dataArray.push(objTemp);
              }
            }
          })
          data2treeDG(state.datas, dataArray)
        }
        //递归子节点
        const data2treeDG=(datas, dataArray)=>{
          for (let j = 0; j < dataArray.length; j++) {
            let dataArrayIndex = dataArray[j];
            let childrenArray = [];
            let id = dataArrayIndex.id;
            for (let i = 0; i < datas.length; i++) {
              let data = datas[i];
              if(true){
                let pId = data.pid;
                if (pId == id) {//判断是否为儿子节点
                  let objTemp = {
                    id: data.id,
                    label: data.subjectName,
                    pid: pId,
                    level:data.subjectLevel
                  }
                  childrenArray.push(objTemp);
                }
              }
            }
            dataArrayIndex.children = childrenArray;
            if (childrenArray.length > 0) {
                //有儿子节点则递归
                data2treeDG(state.datas, childrenArray)
              }
          }
          state.treeDatalist = dataArray;
        }
        return {
            ...toRefs(state),
            handleNodeClick,
            getSubjectList,
            closeMenuNode,
            addSameLevelNode,
            addChildNode,
            deleteNode,
            onSubmit,
            subjectform,
            getSubjectListArray,
            addsubject,
            saveSubjectNode,
            getListData,
            data2treeDG,
            updateNode,
            closeSubjectNode,
            clearsubject,
            getSubjectCategory,
            changeCategory,
            changeBalanceDirection,
            getSubjectByConditionList,
            changeAccountStatus,
            addchangeCategory,
            addchangeBalanceDirection,
            addchangeAccountStatus
        }
    }
}
</script>
<style>
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}


.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
  padding: 5px;
}
.custom-tree-node .do i:hover {
  color: #333;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.el-pagination .el-pager .number.active {
    background-color: white;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
</style>
