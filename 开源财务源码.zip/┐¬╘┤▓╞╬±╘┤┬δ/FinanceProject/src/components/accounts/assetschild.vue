<template>
     <div class="bodydiv" style="width:100%;height:100%;">
        <div class="bodyleft" style="width:30%;height:100%;border-right: 3px solid #DCDFE6;min-height:1000px;float:left;">
          <el-input v-model="filterText" class="sernameval" style="width:95%;" placeholder="Filter keyword" />
          <el-tree
            ref="treeRef"
            class="filter-tree"
            :data="treeDatalist"
            :props="defaultProps"
            @node-click="handleNodeClick"
            :filter-node-method="filterNode">
              <template #default="{node,treeDatalist}" >
                <span class="custom-tree-node el-tree-node__label">
                    <span class="label">
                      {{ node.label }}
                    </span>
                  </span>
            </template>
          </el-tree>
        </div>
        <div class="bodyright" v-show="isShow" style="width:60%;margin-left:20px;height:100%;float:left;">
          <el-form ref="formRef" :model="form" label-width="120px">
            <el-form-item label="科目编号:">
              <el-input v-model="form.SubjectCode" :disabled="true" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item label="科目名称:">
              <el-input v-model="form.SubjectName" :disabled="true" class="sernameval"></el-input>
            </el-form-item>
             <el-form-item label="年初余额:">
              <el-input v-model="form.StartMoney" class="sernameval"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" plain   class="btnbutton" @click="onSubmit">确定</el-button>
              <el-button type="primary" plain   class="btnbutton">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
</template>

<script>
import{ defineComponent,toRefs,reactive, onMounted,ref,watch,unref }from 'vue';
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {updateAccountsSubject,getAccountsSubjectList} from "../../api/system/index";
import {ElMessage,ElTree,ElMessageBox} from 'element-plus'
export default{
    name: "userlist",
    setup: () => {
        const subjectform =ref(null);
        const state = reactive({
            datas:[],
            treeDatalist:[],
            filterText:"",
            locale:zhCn,
            isShow:false,
            searchname:"",
            form:{
              SubjectId:"",
              SubjectCode:"",
              SubjectName:"",
              StartMoney:0,
              AccountsSubjectId:""
            },
            datatree:[]
        })
        onMounted(() => {
          getAccountsSubjectListArray();
        })
        const onSubmit=async()=>{
           var param={
            id:state.form.AccountsSubjectId,
            startMoney:state.form.StartMoney
           }
           let res=await updateAccountsSubject(param);
            if(res.code==20000){
              ElMessage({
                message: '修改成功！',
                type: 'success',
              })
            }
        }
         //加载结算明细列表
        const getAccountsSubjectListArray=async()=>{
         
          var param={
            pageNum:state.currentPage,
            pageSize:state.pageSize,
            subjectType:1,
            accountsId:localStorage.getItem('accountsId')
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
            state.datas=res.data.records;
            getListData();
          }
        }
        const filterNode = (value, data) => {
          if (!value) return true
          return data.label.indexOf(value) !== -1
        }
        //遍历父节点
        const getListData =()=> {
          let dataArray = [];
          state.datas.forEach(function (data) {
            if(true){
              let Pid = data.pid;
              if (Pid == "0") {
                let objTemp = {
                  id: data.subjectId,
                  label: data.subjectName,
                  pid: Pid,
                  level:data.subjectLevel
                }
                dataArray.push(objTemp);
              }
            }
          })
          data2treeDG(state.datas, dataArray)
        }
        const getSubjectByConditionList=async()=>{
           var param={
            pageNum:1,
            pageSize:10,
            id:state.form.SubjectId
          }
          let res=await getAccountsSubjectList(param);
          if(res.code==20000){
             state.form.StartMoney=res.data.records[0].startMoney;
             state.form.SubjectCode=res.data.records[0].subjectCode;
             state.form.AccountsSubjectId=res.data.records[0].id;
          }
        }
        const handleNodeClick = (data) => {
          state.form.SubjectId=data.id;
          state.form.SubjectName=data.label;
          state.isShow=true;
          getSubjectByConditionList();
        }
        //递归子节点
        const data2treeDG=(datas, dataArray)=>{
          for (let j = 0; j < dataArray.length; j++) {
            let dataArrayIndex = dataArray[j];
            let childrenArray = [];
            let id = dataArrayIndex.id;
            for (let i = 0; i < datas.length; i++) {
              let data = datas[i];
              if(true){
                let pId = data.pid;
                if (pId == id) {//判断是否为儿子节点
                  let objTemp = {
                    id: data.subjectId,
                    label: data.subjectName,
                    pid: pId,
                    level:data.subjectLevel
                  }
                  childrenArray.push(objTemp);
                }
              }
            }
            dataArrayIndex.children = childrenArray;
            if (childrenArray.length > 0) {
                //有儿子节点则递归
                data2treeDG(state.datas, childrenArray)
              }
          }
          state.treeDatalist = dataArray;
        }
        return {
            ...toRefs(state),
            onSubmit,
            getAccountsSubjectListArray,
            getListData,
            data2treeDG,
            handleNodeClick,
            getSubjectByConditionList
        }
    }
}
</script>
<style>
.btnbutton.el-button {
    display: inline-block;
    line-height: 3px;
    min-height: 28px;
    white-space: nowrap;
    -webkit-appearance: none;
    text-align: center;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    margin: 0;
    -webkit-transition: .1s;
    transition: .1s;
    font-weight: 500;
    font-size: 14px;
    margin-bottom: 5px;
}
.sernameval.el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 28px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.searchsel{
  margin-left: 10px;
}
#eltreeassets{
  background-color: #FBFBFB;
  border-right-color: #e7e9ec;
  border-right-width: 5px;
  height:auto!important;
  height:780px;
  min-height:780px;
  border-style: solid;
  float: left;
  width: 95.5%;
  margin-top: 10px;
  border-top-style: none;
  border-bottom-style: none;
  border-left-style: none;
}
.treelist{
  background-color: #FBFBFB;
  font-size: 16px;
  color:#fff;
}
#searchinput{
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.point-left{
  margin-top: -20px;
  width:50%;
  height:30px;
  float:left;
}
.point-right{
  margin-top: -20px;
  width:48%;
  height:40px;
  float:left;
}
.point-input  :deep(.el-input__inner) {
  height: 35px;
  width: 98%;
  float: left;
}
.point-right :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-left :deep(.el-form-item__label) {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #606266;
    line-height: 35px;
    padding: 0 0 0 0;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    line-height: -5px;
}
.point-input-num{
  height: 35px;
  width: 100%;
  float: left;
  margin-top: -8px;
}
.point-input-num :deep(.el-input__inner) {
  width: 100%;
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
}
.pointval :deep(.el-input__inner) {
 -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 32px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.pointval{
  width: 98%;
  height:35px;
}
.point-right-type{
  margin-top: -20px;
  width:58%;
  height:40px;
  float:left;
}
.point-input-time{
  width:83%;
  height: 35px;
  float: left;
}
.point-input-time :deep(.el-input__inner) {
  width:100%;
  height: 35px;
  float: left;
}
.pointval-unit{
  width: 15%;
  height: 40px;
  float: left;
}
.pointval-unit :deep(.el-input__inner) {
  width: 100%;
  -webkit-appearance: none;
  background-color: #FFF;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 35px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  padding-top: 5px;
}
.point-leftalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-rightalarm{
  width: 50%;
  height: 40px;
  float: left;
  margin-top: -10px;
}
.point-leftoperate{
   width: 50%;
  height: 40px;
  float: left;
}


.custom-tree-node {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 24px;
  height: 100%;
}
.custom-tree-node .label {
  display: flex;
  align-items: center;
  height: 100%;
}
.custom-tree-node .label .el-tag {
  margin-left: 5px;
}
.custom-tree-node .do {
  display: none;
}
.custom-tree-node .do i {
  margin-left: 5px;
  color: #999;
  padding: 5px;
}
.custom-tree-node .do i:hover {
  color: #333;
}
.custom-tree-node:hover .do {
  display: inline-block;
}
.el-pagination .el-pager .number.active {
    background-color: white;
}
.point-lable{
  height: 35px;
}
.sel-type{
  width:98%;
}
.sernameval .el-input__inner{
  -webkit-appearance: none;
    background-color: #FFF;
    background-image: none;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: inline-block;
    height: 30px;
    line-height: 40px;
    outline: 0;
    -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
    width: 100%;
}
.btn-bottom{
  text-align: center;
}
</style>
