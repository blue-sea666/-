import menuaxios from "@/utils/systemconfig";
export const getMenuTree=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/getMenuTree",
        method:"GET",
        data
    })
}
export const getMenuList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/list",
        method:"POST",
        data
    })
}
export const saveMenu=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/save",
        method:"POST",
        data
    })
}
export const deleteMenu=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/deleteById",
        method:"POST",
        data
    })
}
export const findMenuById=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/findMenuById",
        method:"POST",
        data
    })
}
export const updateMenu=(data:any)=>{
    return menuaxios({
        path:"/financeapi/menu/updateMenu",
        method:"POST",
        data
    })
}

export const getRoleList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/role/findRole",
        method:"POST",
        data
    })
}
export const saveRole=(data:any)=>{
    return menuaxios({
        path:"/financeapi/role/addRole",
        method:"POST",
        data
    })
}
export const deleteRole=(data:any)=>{
    return menuaxios({
        path:"/financeapi/role/deleteRole",
        method:"POST",
        data
    })
}
export const updateRole=(data:any)=>{
    return menuaxios({
        path:"/financeapi/role/updateRole",
        method:"POST",
        data
    })
}
export const savelist=(data:any)=>{
    return menuaxios({
        path:"/financeapi/userrole/savelist",
        method:"POST",
        data
    })
}
export const findUserRole=(data:any)=>{
    return menuaxios({
        path:"/financeapi/userrole/findUserRole",
        method:"POST",
        data
    })
}
export const findDeptList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/dept/list",
        method:"POST",
        data
    })
}
export const saveDeptList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/dept/save",
        method:"POST",
        data
    })
}
export const updateDeptlist=(data:any)=>{
    return menuaxios({
        path:"/financeapi/dept/updateDept",
        method:"POST",
        data
    })
}
export const getUserArray=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/findUser",
        method:"POST",
        data
    })
}
export const findDeptById=(data:any)=>{
    return menuaxios({
        path:"/financeapi/dept/findDeptById",
        method:"POST",
        data
    })
}
export const deleteDept=(data:any)=>{
    return menuaxios({
        path:"/financeapi/dept/deleteById",
        method:"POST",
        data
    })
}
export const getUserById=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/findUserById",
        method:"POST",
        data
    })
}
export const getUserList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/findUser",
        method:"POST",
        data
    })
}
export const userSave=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/save",
        method:"POST",
        data
    })
}
export const userUpdate=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/update",
        method:"POST",
        data
    })
}
export const userDelete=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/delete",
        method:"POST",
        data
    })
}
export const saveauthArray=(data:any)=>{
    return menuaxios({
        path:"/financeapi/userauth/savelist",
        method:"POST",
        data
    })
}
export const getauthlist=(data:any)=>{
    return menuaxios({
        path:"/financeapi/userauth/list",
        method:"POST",
        data
    })
}
export const loginUser=(data:any)=>{
    return menuaxios({
        path:"/financeapi/user/getUser",
        method:"POST",
        data
    })
}
//科目类别管理
export const addSubjectCategory=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subjectcategory/save",
        method:"POST",
        data
    })
}
export const deleteSubjectCategory=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subjectcategory/delete",
        method:"POST",
        data
    })
}
export const getSubjectCategoryList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subjectcategory/getSubjectCategory",
        method:"POST",
        data
    })
}
export const updateSubjectCategory=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subjectcategory/update",
        method:"POST",
        data
    })
}
//科目管理
export const addSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subject/save",
        method:"POST",
        data
    })
}
export const deleteSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subject/delete",
        method:"POST",
        data
    })
}
export const getSubjectList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subject/getSubject",
        method:"POST",
        data
    })
}
export const getSubjectByCondition=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subject/qrySubjectById",
        method:"POST",
        data
    })
}
export const updateSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/subject/update",
        method:"POST",
        data
    })
}

//账套管理
export const addAccounts=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accounts/save",
        method:"POST",
        data
    })
}
export const deleteAccounts=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accounts/delete",
        method:"POST",
        data
    })
}
export const getAccountsList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accounts/getAccounts",
        method:"POST",
        data
    })
}
export const updateAccounts=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accounts/update",
        method:"POST",
        data
    })
}

//科目管理
export const addAccountsSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accountssubject/save",
        method:"POST",
        data
    })
}
export const deleteAccountsSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accountssubject/delete",
        method:"POST",
        data
    })
}
export const getAccountsSubjectList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accountssubject/getAccountsSubject",
        method:"POST",
        data
    })
}
export const updateAccountsSubject=(data:any)=>{
    return menuaxios({
        path:"/financeapi/accountssubject/update",
        method:"POST",
        data
    })
}

//科目管理
export const addVoucher=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucher/save",
        method:"POST",
        data
    })
}
export const deleteVoucher=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucher/delete",
        method:"POST",
        data
    })
}
export const getVoucherList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucher/getVoucher",
        method:"POST",
        data
    })
}
export const updateVoucher=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucher/update",
        method:"POST",
        data
    })
}
export const updateVoucherById=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucher/updateVoucherById",
        method:"POST",
        data
    })
}
//科目管理
export const addVoucherDetail=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/save",
        method:"POST",
        data
    })
}
export const deleteVoucherDetail=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/delete",
        method:"POST",
        data
    })
}
export const getVoucherDetailByMonthList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/getVoucherDetailByMonth",
        method:"POST",
        data
    })
}
export const getVoucherDetailByYearList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/getVoucherDetailByYear",
        method:"POST",
        data
    })
}
export const getVoucherDetailList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/getVoucherDetail",
        method:"POST",
        data
    })
}
export const updateVoucherDetail=(data:any)=>{
    return menuaxios({
        path:"/financeapi/voucherdetail/update",
        method:"POST",
        data
    })
}

//客户相关
export const addCustomer=(data:any)=>{
    return menuaxios({
        path:"/financeapi/customer/addCustomer",
        method:"POST",
        data
    })
}
export const deleteCustomer=(data:any)=>{
    return menuaxios({
        path:"/financeapi/customer/deleteCustomer",
        method:"POST",
        data
    })
}
export const getCustomerList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/customer/getCustomer",
        method:"POST",
        data
    })
}
export const updateCustomer=(data:any)=>{
    return menuaxios({
        path:"/financeapi/customer/updateCustomer",
        method:"POST",
        data
    })
}
//供应商相关
export const addSupplier=(data:any)=>{
    return menuaxios({
        path:"/financeapi/supplier/addSupplier",
        method:"POST",
        data
    })
}
export const deleteSupplier=(data:any)=>{
    return menuaxios({
        path:"/financeapi/supplier/deleteSupplier",
        method:"POST",
        data
    })
}
export const getSupplierList=(data:any)=>{
    return menuaxios({
        path:"/financeapi/supplier/getSupplier",
        method:"POST",
        data
    })
}
export const updateSupplier=(data:any)=>{
    return menuaxios({
        path:"/financeapi/supplier/updateSupplier",
        method:"POST",
        data
    })
}

