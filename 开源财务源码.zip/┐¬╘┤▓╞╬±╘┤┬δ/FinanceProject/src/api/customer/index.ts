import axios from "@/utils/request";
export const getCustomer=(data:any)=>{
    return axios({
        path:"/api/Customer/getCustomerList",
        method:"POST",
        data
    })
}
export const getsettmentList=(data:any)=>{
    return axios({
        path:"/api/Customer/getsettmentList",
        method:"POST",
        data
    })
}
export const getCustomerSettList=(data:any)=>{
    return axios({
        path:"/api/Customer/getCustomerSettList",
        method:"POST",
        data
    })
}
export const updateCustomer=(data:any)=>{
    return axios({
        path:"/api/Customer/UpdateCustomer",
        method:"POST",
        data
    })
}
export const UpdateSettment=(data:any)=>{
    return axios({
        path:"/api/Customer/UpdateSettment",
        method:"POST",
        data
    })
}
export const deleteCustomer=(data:any)=>{
    return axios({
        path:"/api/Customer/DelCustomer",
        method:"POST",
        data
    })
}
export const addCustomer=(data:any)=>{
    return axios({
        path:"/api/Customer/AddCustomer",
        method:"POST",
        data
    })
}