import axios from "@/utils/request";

export const addMaterial=(data:any)=>{
    return axios({
        path:"/api/MaterialList/AddMaterial",
        method:"POST",
        data
    })
}
export const getMaterialList=(data:any)=>{
    return axios({
        path:"/api/MaterialList/getMaterialList",
        method:"POST",
        data
    })
}
export const deleteMaterial=(data:any)=>{
    return axios({
        path:"/api/MaterialList/DelMaterial",
        method:"POST",
        data
    })
}