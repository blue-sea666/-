import axios from "@/utils/request";

export const AddProductship=(data:any)=>{
    return axios({
        path:"/api/Productship/AddProductship",
        method:"POST",
        data
    })
}
export const getProductShip=(data:any)=>{
    return axios({
        path:"/api/Productship/getShipList",
        method:"POST",
        data
    })
}