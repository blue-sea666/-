import axios from "@/utils/request";
export const loginApi=()=>{
    return axios({
        path:"/api/WareList/getWareList",
        method:"POST"
    })
}
export const upApi=(data:any)=>{
    return axios({
        path:"/api/Values/getUserList",
        method:"POST",
        data
    })
}