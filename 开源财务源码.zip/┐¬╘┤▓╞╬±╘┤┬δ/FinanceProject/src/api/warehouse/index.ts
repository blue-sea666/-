import axios from "@/utils/request";
export const getHouserList=(data:any)=>{
    return axios({
        path:"/api/WareList/getWareList",
        method:"POST",
        data
    })
}
export const updateWare=(data:any)=>{
    return axios({
        path:"/api/WareList/UpdateWare",
        method:"POST",
        data
    })
}
export const deleteWare=(data:any)=>{
    return axios({
        path:"/api/WareList/DelWare",
        method:"POST",
        data
    })
}
export const addWare=(data:any)=>{
    return axios({
        path:"/api/WareList/AddWare",
        method:"POST",
        data
    })
}