import axios from "@/utils/request";

export const addProduct=(data:any)=>{
    return axios({
        path:"/api/ProductList/AddProduct",
        method:"POST",
        data
    })
}
export const getProductList=(data:any)=>{
    return axios({
        path:"/api/ProductList/getProductList",
        method:"POST",
        data
    })
}
export const deleteProduct=(data:any)=>{
    return axios({
        path:"/api/ProductList/DelProduct",
        method:"POST",
        data
    })
}