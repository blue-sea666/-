export const config= {
    host:"https://signapi.dzlongsheng.com/webapi",
    menuhost:"http://121.36.109.107:8088"
}