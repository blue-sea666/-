# v3-element
## 基于vue3.x 实现的后台管理系统模板
    1、  登录逻辑.
    2、  基本布局(基于elementPlus)
    3、  动态路由逻辑
    4、  动态菜单栏逻辑
    5、  面包屑 
    6、  皮肤切换 
    7、  假数据模拟路由菜单 
## gif示例
![image](https://github.com/zzz0908/vue3-elementPlus-admin/blob/master/v3.gif)
## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
