/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : finance

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 25/03/2022 19:30:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_accounts
-- ----------------------------
DROP TABLE IF EXISTS `t_accounts`;
CREATE TABLE `t_accounts`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `accounts_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `accounts_system` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `set_time` datetime NULL DEFAULT NULL,
  `insert_time` datetime NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `accounts_status` int(255) NULL DEFAULT NULL COMMENT '0,启用，1停用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_accounts
-- ----------------------------
INSERT INTO `t_accounts` VALUES ('f530b4bb5c7f4bc78641fe57408ae3e2', '2022年财务账套', '2022年财务新制度', '2022-03-13 23:24:25', '2022-03-13 17:25:58', '2022-03-23 23:24:25', 0);
INSERT INTO `t_accounts` VALUES ('6cc91657c1124fd0a084c25a3d4149fb', '2021账套', '2021财务制度', '2022-03-16 20:14:21', '2022-03-23 20:14:21', NULL, 0);

-- ----------------------------
-- Table structure for t_accountssubject
-- ----------------------------
DROP TABLE IF EXISTS `t_accountssubject`;
CREATE TABLE `t_accountssubject`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `accounts_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `subject_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `subject_status` int(10) NULL DEFAULT NULL COMMENT '0,启用，1.禁用',
  `start_money` decimal(10, 2) NULL DEFAULT NULL,
  `final_money` decimal(10, 2) NULL DEFAULT NULL COMMENT '当前期末余额',
  `edit_flag` int(10) NULL DEFAULT NULL COMMENT '是否是第一次编辑',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_accountssubject
-- ----------------------------
INSERT INTO `t_accountssubject` VALUES ('be9865fcd04d444f887d362c6dfa3895', '62767ad2c931487ebb6de21d2c52dd93', '35d3b5803269495c838c7000dbb2dde1', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('0ee15722cb0648a284a202cb077eb8a1', '62767ad2c931487ebb6de21d2c52dd93', '2c1572191af543f5831390e76fe77438', 0, 0.00, 2000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('65d8e12e6bf64956bc65ab24b9d21d71', '62767ad2c931487ebb6de21d2c52dd93', 'f1bb7ff45d844ab5b21151898ffa2da4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('0879901524da48e887ede6c231c78d63', '62767ad2c931487ebb6de21d2c52dd93', 'e7e8a03b4f8445d4b68f81bb6dbb898a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('65b0221f61a34808a8649e686e60dae7', '62767ad2c931487ebb6de21d2c52dd93', '053550833d724efcbd69d6be6432a8b5', 0, 0.00, 100.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('8e0ada1acc2e4bb4b6f1807d792072e6', '62767ad2c931487ebb6de21d2c52dd93', 'e775023152184671b8aa1e0698c7e7a0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('0eb341d6ad724c55bd8cf7abd3edb653', '62767ad2c931487ebb6de21d2c52dd93', '3e7da01ee9f04e59902733e02e6c7987', 0, 0.00, 3000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('322278ca96ee4ad9aab58a5380fc02f3', '62767ad2c931487ebb6de21d2c52dd93', 'a34714bb926447118faec80f6da4987a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4d46c69df7e44d168036838bf1ea4084', '62767ad2c931487ebb6de21d2c52dd93', 'fd5e1c92c60348488cca8a2cea880bd6', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('40f1876c73a74c7a86a03b6c6f4112fc', '62767ad2c931487ebb6de21d2c52dd93', '3b518de12eb34b3e93af8540f72344fa', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('b7d3786548974e09bfc8197e83490f12', '62767ad2c931487ebb6de21d2c52dd93', '540c45d641324c6bb07b45d6764158fb', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('cef0e45143cb4a74800cdde2b3b2ff4a', '62767ad2c931487ebb6de21d2c52dd93', '6dceb8ef406942cd9455f20eb3f29a71', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('14b58d3f700b4d19a5b359189555a519', '62767ad2c931487ebb6de21d2c52dd93', 'c05a5374a90f4d248c4cb6973bd90b54', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('dbd0a5ed2906411588ab3aafa9359214', '62767ad2c931487ebb6de21d2c52dd93', '56a1e52966b149128c1c0e4032d215c5', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('dbd0a5ed2906411588ab3aafa93592121', '62767ad2c931487ebb6de21d2c52dd93', 'd6c272658f6a48bd957d20bae15d14c1', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('dbd0a5ed2906411588ab3aafa93592127', '62767ad2c931487ebb6de21d2c52dd93', '8a7025af986d4e34968990f1100472b3', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('dbd0a5ed2906411588ab3aafa93592132', '62767ad2c931487ebb6de21d2c52dd93', 'c75dfb1700784c29bfd00eccd5dc0930', 0, 0.00, NULL, NULL);
INSERT INTO `t_accountssubject` VALUES ('549c601cd8e24133b3071046dec4f8ff', 'f530b4bb5c7f4bc78641fe57408ae3e2', '35d3b5803269495c838c7000dbb2dde1', 0, 0.00, 3800.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a9ba768314f04f5b9edd2d0e28702d23', 'f530b4bb5c7f4bc78641fe57408ae3e2', '2c1572191af543f5831390e76fe77438', 0, 0.00, 1000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('74f2684b8a2840d6a3dfc1ab405e8a2c', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f1bb7ff45d844ab5b21151898ffa2da4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c4d699931d9f4126adedd5c5ed75ea1b', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e7e8a03b4f8445d4b68f81bb6dbb898a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d626a6b2c00d47f796620014e196bbf8', 'f530b4bb5c7f4bc78641fe57408ae3e2', '053550833d724efcbd69d6be6432a8b5', 0, 0.00, 100.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a3602f72b2544828ae3153601e79d522', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e775023152184671b8aa1e0698c7e7a0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('da5332a2f4f94a759a3a0bfd1869f66e', 'f530b4bb5c7f4bc78641fe57408ae3e2', '3e7da01ee9f04e59902733e02e6c7987', 0, 0.00, 3000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('1095500b25514a4da834d32bfb9b2b58', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'a34714bb926447118faec80f6da4987a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3dba2497a93a485a89fe0fe2375e38b3', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'fd5e1c92c60348488cca8a2cea880bd6', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a1ab7aac4b974e2fbc9da6253452e8d2', 'f530b4bb5c7f4bc78641fe57408ae3e2', '3b518de12eb34b3e93af8540f72344fa', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a130d8133ba447cdba94bed98deb94b5', 'f530b4bb5c7f4bc78641fe57408ae3e2', '462df2ba2efa4f27b50d4bfb48581d5c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('81e4d78aca94499489b5ca029ef866e3', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4aed1cbc059941f0ad61bc13a7ef0b70', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('8e358b1e9ed84992a8cbb16811e7f7b7', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'bf23d55550184dbc85cea8bcfc2671cf', 0, 0.00, 5000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('cb13e73c5ec1470d819721fc9062a800', 'f530b4bb5c7f4bc78641fe57408ae3e2', '884e3ea3416f4191aedc388973096a45', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a264d594040047dab5babc8c3f0f12dd', 'f530b4bb5c7f4bc78641fe57408ae3e2', '436760733c0d41fd8b76a5f7f3a1a85d', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a34bfa8b1c1642428b0b0296fba83215', 'f530b4bb5c7f4bc78641fe57408ae3e2', '94b2f8379ccf4cc3802e9c6fdc000172', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('eaa580befd6047fe89c7952504d18ae1', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7bc8b5cb3b20414687822ae182286fb0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('641ef731a0de4083835c09e63a44c354', 'f530b4bb5c7f4bc78641fe57408ae3e2', '295b0da4b6384e68ac104d514f4cff05', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('fbb7b9c20492425386163e967939c0a9', 'f530b4bb5c7f4bc78641fe57408ae3e2', '85b1e7dd76fc41889048674c0a6dfd8d', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('fa74f23e51484b518c58779bff89d26d', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e5ec3ed34ff54fc4a95ba1bdb8affe06', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('ca969f6fd40a4a44bd855fb9826969a5', 'f530b4bb5c7f4bc78641fe57408ae3e2', '55d0ac4146ac437693f19a2e3a574eca', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c1bbf1bfd6364822a0bc5d38e55cb68c', 'f530b4bb5c7f4bc78641fe57408ae3e2', '9fbd271661384021ab294c9d0ccc86d0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('fddbd479c535437abd51c5f77f3a1ce2', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7f4c5c507fea4f518e9e6b8d50fb0abe', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('340c28e24d3145999bc056db49f5e306', 'f530b4bb5c7f4bc78641fe57408ae3e2', '8c99d0bfb08643f9b596108a4673e1cd', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('262fe9aeea304f6dba7a78971ddd3e02', 'f530b4bb5c7f4bc78641fe57408ae3e2', '11df6f19298a4d82824b73b7718f4439', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d640791039264c2c9c7373927dbf0a75', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'c23686d574504ca8bd53127f95b4349e', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('b93cd5fb427a47eaa50aaca8fb1805dc', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7749dd82de6d42b89a0088be734e01fc', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('aaa6a1409d014f5cba0200f1329a3fad', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'ed7d33bb064a41ea8ac6f39785a533af', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('31018599a80e42f98ae66c33a77f3de6', 'f530b4bb5c7f4bc78641fe57408ae3e2', '13fbeff781a442abb25fb39db9ef36fb', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('352e4ad6a3f64c1ca12484cab59f2ede', 'f530b4bb5c7f4bc78641fe57408ae3e2', '34729739b62e48b7a5880fa9e031ab38', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('5454d41889384d71b65c34661168b696', 'f530b4bb5c7f4bc78641fe57408ae3e2', '333b241d8b11467fb057b5f2ff724778', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3317ce346d954783a0bdea557279eeff', 'f530b4bb5c7f4bc78641fe57408ae3e2', '69a2fcdeeb2040c291b429bb4138c5b7', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d5f7f91190f6467981273bbc185594b1', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7d6a3f461230454ca4809e5a962c1579', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('5e0a3e79a6e2424c9706575d98d60a90', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'c01cdfd54e934036b7d4134db1516d27', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('8cc216f2369a413db320d975fbff9cae', 'f530b4bb5c7f4bc78641fe57408ae3e2', '41759bd102f64b289a2277b0483ef309', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e70c05b97c3d44a091ea4ea88627246d', 'f530b4bb5c7f4bc78641fe57408ae3e2', '46607ab6ee064517803ac0f6e518e090', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('be0f544db81646d5ac60cb9599d75aae', 'f530b4bb5c7f4bc78641fe57408ae3e2', '94cfd1967aa54d0facb1e881ffd9165c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('40ab966047864c06a38a833ab44ccf74', 'f530b4bb5c7f4bc78641fe57408ae3e2', '36b40b93f3a240c1958a4a45b3971f91', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3827dbf15dff465385c1e2d422d71e8d', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'cb9fb1d5d4c647639fda359c9384a257', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e791741dc2c44ff0a105a213d1869732', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'fde0d863e836461cb636cdea912fb139', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('87ea60c09d6c43699bc72fe24bca1d5f', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e4c46e238c4743ceb5b38855dda7aef7', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a833778655714e679dd28b341a4cb64b', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'c1de6048be924b43ad71c1c8062765a9', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('34f21472c4bf45ad9f21025f6a0a0c44', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'dbaefa58749847619f7b23ca0dc04a9d', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e526ccb1c6c446b4adbe71943bbe2308', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e6e02f94f9f1435b89f1a87277be0dcf', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e97d1cb11e5047c590dca1928d12d7f0', 'f530b4bb5c7f4bc78641fe57408ae3e2', '15bd7370424d4c92bc57a4b5c61a6894', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d5c9e00c05fa4781bc3515cbb7e4c68f', 'f530b4bb5c7f4bc78641fe57408ae3e2', '79aca92b47be422998f9b825c70b6920', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('ec9981a122e24c1298c34cdb7d65e9d3', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e70278513d6b445fb040e43ad480cfda', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3277127f552e48d4850d68bebf84ffb5', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'd512ee465e73494d9fe9fad1d7d0741d', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('758bbe6ce4bd4833912fd0894e498f86', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'ab0ec95e2bac499ab597c1011cae1dd4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('52b27b9a548c4680a9fd66cef1d33d06', 'f530b4bb5c7f4bc78641fe57408ae3e2', '658b889fdc9a4a7b8d72d256ac4acd59', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('b08ca7880b4a48e2a2f57fcbfe000ba9', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'eef2f33c66be419daedf586056c4b887', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('bae404e8b61449679cd631607a4dfffa', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4cf871acc3804ed2b4d15532bdf8a9d4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4a65e8d8bf2e4f538f469179b466d646', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e4048ceca484490f980d473e553adcc3', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a239e10fe4b149f5be89c9c46686de92', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f60c9d3c0a464b98bb0e3f035ca8835b', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a7ec9bbeeaf4492bb165c3a5a85bea4d', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'cc1d3de228834735878f207c4b15afcc', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('1b976d846cd94a15a8151ff1ccaa9c73', 'f530b4bb5c7f4bc78641fe57408ae3e2', '34e97d3042434388aa9c52c28cff6c59', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('f24a55c1d044449a945b1b39953cc81f', 'f530b4bb5c7f4bc78641fe57408ae3e2', '647509c39b0a484889815740a1672c03', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a2bc17c78e104809b8ea268021c86894', 'f530b4bb5c7f4bc78641fe57408ae3e2', '40600a7bc86145ada843a031da4d6eed', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('809348ddcc4c4c8b8703d9ad94d198f1', 'f530b4bb5c7f4bc78641fe57408ae3e2', '6fe34031e850493d8148e9c69bb545e2', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4dd4ca9d0a3e43cebdf30780b5f4dfbf', 'f530b4bb5c7f4bc78641fe57408ae3e2', '5c340a37619143f8a5814d955276c2d7', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('5d09ae8b04f0425d8d6469f7dc1bff46', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'c339e0d99bdb41adb1b89be60de404ff', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('32fb13e014144dd39f1af1eea4602241', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'eb859116f527448290ac51a8a1ac3801', 0, 0.00, -1000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('70f570ae7b214af8adf4b4928e573f75', 'f530b4bb5c7f4bc78641fe57408ae3e2', '1246fcc023c747ac84765454f16bd7d4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4e587e83b31547579fa6f6226b9fed28', 'f530b4bb5c7f4bc78641fe57408ae3e2', '63dd24bc581f4d31a434f8da18a5d986', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('88c1e420a6fc4f25a8e59f4b6612f93d', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'd03370b6b304402eb31327c7050b4c5a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('9b7ca68dfd3d4ebf8fd2c47c7763d214', 'f530b4bb5c7f4bc78641fe57408ae3e2', '73ba0ece3e564ab8a90f8cd49655bcbc', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c5bf4b7083624fcfbbc4499bedba9283', 'f530b4bb5c7f4bc78641fe57408ae3e2', '0ecce3dad4a44c2daed45b7150592938', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4fea08bb07ae428b8b6304d0cec1a2c9', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7414fd56f60d49a19aaa8e80e7cf67c3', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('caf64971a5f246bc80d4c843b713e052', 'f530b4bb5c7f4bc78641fe57408ae3e2', '0ffed834283d483796c341eba303afc5', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('92551962aeea4694a2b25c976b33257a', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'beb94888f2d44ea5a9c0bb68b155f05b', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d80d2896b75646cdb0726bc129cff531', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'b21e1e8c6251425893bd303982034c7a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3b091cd30c4d4ed3939cba21ba0d14b0', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f08a8ac6215c4f5fbcbfbf4d29f08b83', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('116e5cdaf86543d0a786eee2b83842e6', 'f530b4bb5c7f4bc78641fe57408ae3e2', '76a174b3b80f49cea47bb03895ead2c8', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a593f93c8c2a4f6dab5ecda0286cf90f', 'f530b4bb5c7f4bc78641fe57408ae3e2', '1758cafec1b9489d8de2be5b4a42382b', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c09e4c74c6f045a8a8f95871f6359714', 'f530b4bb5c7f4bc78641fe57408ae3e2', '423268e98c384c2a878822489ebfb096', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d8ea0121e2a44d04b8badf131d57bc65', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'b213dd2598704723b76e2547ee32d743', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('67e233b21bb543e88423ff5a7cb1e3fe', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e04624975a2a480cadc613191df238fe', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('73315240090e44beaa16ef490e877e0f', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'ad0c1ae44ab6429c91b67d2bb440127f', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3d6a2f3801de4718a4868e0bfc229dd5', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4c4dac9d42144bc0930b9a694195f211', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c209513adced4a219d1bccf7d8a9a333', 'f530b4bb5c7f4bc78641fe57408ae3e2', '20ad69f747014a7e9c989a319f6a2efa', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('439ed0621b99407bb00a0b80fc5c5bce', 'f530b4bb5c7f4bc78641fe57408ae3e2', '52216cc0b550447db4d6cc9e48e5cb53', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('8db78419e68e478a815ed09b39a10372', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'b2c5d740e7d44abcb44ed211f0f5c656', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('994782a3c1014c2683a74d5194cc01f0', 'f530b4bb5c7f4bc78641fe57408ae3e2', '0293bfa9092047febb04397414a5b571', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4756624bc4a54952b4e2392c0e6ddacd', 'f530b4bb5c7f4bc78641fe57408ae3e2', '8af4ba5141e74734bf31a5594b1b5fd9', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3a299f0c32594c2ca220eb2378d6e8e2', 'f530b4bb5c7f4bc78641fe57408ae3e2', '5bc9cfda1b63406398ca13a104808366', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('0b4bfce979384f8abb3f159d8b53e8fe', 'f530b4bb5c7f4bc78641fe57408ae3e2', '9230caa6dabe49688c5a8bf476eea2e0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('7a7ec772e8004438b5db4049dea4cdbc', 'f530b4bb5c7f4bc78641fe57408ae3e2', '35a2668a096d41518609a282204e1914', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('47da1422dc914f4e8b26a467ae472183', 'f530b4bb5c7f4bc78641fe57408ae3e2', '67c2f6497efe4d4cbe5eab94f205e1b0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('f3cda8e7610e4695a839af118cadfd71', 'f530b4bb5c7f4bc78641fe57408ae3e2', '585f6455d44b41588d6e3307d1d33c88', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('82685af1558a49c8a2d24d7adfb4a0e5', 'f530b4bb5c7f4bc78641fe57408ae3e2', '486f613b494347278165fc0e10d9cfd8', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('90e5f03f7acc41b89e8ac96d9ccf9c94', 'f530b4bb5c7f4bc78641fe57408ae3e2', '1cf625fec4a44e749dca0f81ee23b3a1', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('01eb5d1c9a304b12817e07d08a8b8183', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f0559467c3354f3d9876f3c83d338c63', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('1ce0f494463b4da3a3159281715b5edd', 'f530b4bb5c7f4bc78641fe57408ae3e2', '63bb6a0618a94af78e218a99a9ba9d50', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('398c5dbda497461b82f308a9370ab3a1', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f66714ea379443a1a3f372d54b79417a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('cbea265dbc5f44bc86b2f58ea452b88e', 'f530b4bb5c7f4bc78641fe57408ae3e2', '3c16572374304850920411a65323624b', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('b85bf3ef05154e00b4d80d6e8e27bb37', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'bd2312de5d394cb29db7b1274f165fb0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('46fb7f3784434f299c6e174039f0f147', 'f530b4bb5c7f4bc78641fe57408ae3e2', '5e082b2f411c409eabdb193160d73c83', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('ea253998faf14881aa7c34be94dbe8db', 'f530b4bb5c7f4bc78641fe57408ae3e2', '105a77337c04401e85c2e23497c6dcd2', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('5ff7bfdcd9c041cbabbc90006d9e2d23', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'd88fed8ee8d24441889bc51e6aab21c8', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('383a4840025a4beaa80c5f44e47a25b7', 'f530b4bb5c7f4bc78641fe57408ae3e2', '62712500e20040799829cb5f3d5659f8', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d2a2c993393b4d73837e7deef3820a81', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'cbe2ab64351f4819bffab722ba927889', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('798e2fae512d48588353a50d2fdd0f31', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'cd4989d9a9d442df8e045f26e5537822', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('104e492e13914f5696933caeabbc5a0e', 'f530b4bb5c7f4bc78641fe57408ae3e2', '17c32c7f44744e79ad13b9dc900c1d3c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e4264166c40e4eb9a4808756fd23deab', 'f530b4bb5c7f4bc78641fe57408ae3e2', '9c6efc976e264b5eafb8e2464e5e276a', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e1555b1fb28e4c5c8d60f7d99dc6009b', 'f530b4bb5c7f4bc78641fe57408ae3e2', '714bbd2712da4b028dd02b1adef13239', 0, 0.00, 10000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('151fcbae56cc428e8f535fb38369f5a4', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4752db5fe15d47e0b07df7a8205b2d1d', 0, 0.00, 9000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a7643806f02a436aa7e663a3503a1951', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f6ec4ab3b8704566a4f9f4e4b88011ba', 0, 0.00, 12000.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('1c449c910ff64e39b105e9fa5d0f8aec', 'f530b4bb5c7f4bc78641fe57408ae3e2', '729971d18f864e3c8f361df6fb0e5331', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('6db8255fa3f04dd0bfd6a52f478ba733', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4a886766f7384d1dbe444092b3c00ee7', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('db57b4542e364b9aaa289ab135dfa022', 'f530b4bb5c7f4bc78641fe57408ae3e2', '947af1008afc45a885243e9c5e2bd373', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3fa2ebc4b5084e60af89115fe0e64c23', 'f530b4bb5c7f4bc78641fe57408ae3e2', '775226b82dd04ad6a0f4e9e3e4bfe995', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('99e68a25150342d98196bfba2e0bb162', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e2f6e2d19cc74ad99bce83a3bd677c06', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('29688f7af81f4164813ff66b05617fb3', 'f530b4bb5c7f4bc78641fe57408ae3e2', '335e7fcd58cc43d3b282300aadf9131c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('f202d18ea71a4ce4bcebb2ef745fdb89', 'f530b4bb5c7f4bc78641fe57408ae3e2', '3ad71311f0b8478e9dab302f093fe923', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('2427e24f1f44494bba5c7f98a9ffa9a6', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'acf468083046401382d0935509e381a7', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('ffc072400cf74a588c86374920fbfd48', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'a810da31cbc94946bdf3b70cfa6776bc', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('68c9dbb405a2485e8164f8e932b6f6bd', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'c29f6dbfdfb14949a3a6ec1f2e546ca4', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('28668f1061cb4a91ba32ece43f059556', 'f530b4bb5c7f4bc78641fe57408ae3e2', '89a6563029b04b4b9576e9f4f5f8a4e1', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('bc3e9aaad0e24982b48e8bca4ee5d564', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f94a1d0909fc4ab99b536dd30c3cecdb', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a2b896e2ac9140ddaf0c3d43f8754c72', 'f530b4bb5c7f4bc78641fe57408ae3e2', '1a4f0c5451414b86b76f20fce99b33cb', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('aea06395fe4b489fae47976218a00b93', 'f530b4bb5c7f4bc78641fe57408ae3e2', '60ee2aff8f354edabca6a2f0743e5f1e', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('6a583531fee545079d48aca4ab46fb04', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'b7fc8390eee54a1cbf6fccd58ac1702b', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('05d0f9f46cfc4c5290ff976b7a95b5a4', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f709b935eb474912846a52a76fb4b06c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('dc3c4449e81d411a84b788df5b4a7e89', 'f530b4bb5c7f4bc78641fe57408ae3e2', '9ca1f7d12219468bac0b022249f58c07', 0, 0.00, 200.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('ea1e425e73114b6ba061d7f4e5a13061', 'f530b4bb5c7f4bc78641fe57408ae3e2', '0576e7e5f375416b8d2d9c15bafeee6c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('e6bb576441c54980a1d42e3733e5acba', 'f530b4bb5c7f4bc78641fe57408ae3e2', '2f03fcd0b43044b8b8599d2d712f07e0', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('57824d0b74b1491da2b2e5190f49ed24', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'bc2fa0c13a3f46bbb821b149376f0386', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('4b307fd5be5541b69462a31e30fbee17', 'f530b4bb5c7f4bc78641fe57408ae3e2', '4ab5d91f9920469ea4534d63fd6a34c9', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('0b4e20d247e34bd9b821c2b13faacd42', 'f530b4bb5c7f4bc78641fe57408ae3e2', '5a55679dee874e25a2d66f603967b572', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('48ef445bbf3843d2b925a9eb9752bd64', 'f530b4bb5c7f4bc78641fe57408ae3e2', '95f71108003545af93b5fdfe9aaa4608', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('3b449ee1f1294705a757923421b1e2ac', 'f530b4bb5c7f4bc78641fe57408ae3e2', '7c3f63f9395b4f2f91300b8b20628506', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('98345f47b6eb47c49f9037111300c570', 'f530b4bb5c7f4bc78641fe57408ae3e2', '2a68ddae4d5049f285f9f6fb41e8bb88', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('c01f7a46d64c43dab99a32e86afb43e6', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'f2d26497b1694873ad096ec7951aa175', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('055533c352094566bd0e3f28a6f1d815', 'f530b4bb5c7f4bc78641fe57408ae3e2', '999d69e60b8a42e7865c15b9d7179194', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('a52827d180d94c06bf1dd67d1665dfa8', 'f530b4bb5c7f4bc78641fe57408ae3e2', '973131394b2645f6b447ab424c18aeea', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('76108caf0f3344a8a8b451ce64c05053', 'f530b4bb5c7f4bc78641fe57408ae3e2', '97174df921934a03a8fce3033aaf1102', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('d35c286a743a4d91b799b43d6a984426', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'e8843f19bd2247d39621fb1fe1b72173', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('09bcdc504c6f4fce9881777c05050864', 'f530b4bb5c7f4bc78641fe57408ae3e2', 'aee02e0dbaf84ee78b4f318abcdd2e8c', 0, 0.00, 0.00, NULL);
INSERT INTO `t_accountssubject` VALUES ('2c3d9bd786194afd9effe706054f5b7a', '6cc91657c1124fd0a084c25a3d4149fb', '35d3b5803269495c838c7000dbb2dde1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a281337ef69c4e6e9eb335c3daf3d75b', '6cc91657c1124fd0a084c25a3d4149fb', '2c1572191af543f5831390e76fe77438', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ad16fe73732a473f9eaa6344ecc0a73e', '6cc91657c1124fd0a084c25a3d4149fb', 'f1bb7ff45d844ab5b21151898ffa2da4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3616eea08160490e9aed01ee616342d7', '6cc91657c1124fd0a084c25a3d4149fb', 'e7e8a03b4f8445d4b68f81bb6dbb898a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('f04cf69a50c54268a2b3bef53e41da5b', '6cc91657c1124fd0a084c25a3d4149fb', '053550833d724efcbd69d6be6432a8b5', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('8fe8c378dfa04b988509174268952720', '6cc91657c1124fd0a084c25a3d4149fb', 'e775023152184671b8aa1e0698c7e7a0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d010f69b626d4bc09fd7adf73e0d2a58', '6cc91657c1124fd0a084c25a3d4149fb', '3e7da01ee9f04e59902733e02e6c7987', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('30c097c3fb704e9195b1e6e53d96eb4d', '6cc91657c1124fd0a084c25a3d4149fb', 'a34714bb926447118faec80f6da4987a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('401cc891c2aa4d1cb90469d917414103', '6cc91657c1124fd0a084c25a3d4149fb', 'fd5e1c92c60348488cca8a2cea880bd6', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ec8abfd162e440deb07d41f3d42e7c78', '6cc91657c1124fd0a084c25a3d4149fb', '3b518de12eb34b3e93af8540f72344fa', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('dbd1741cdf9543aba3f60159d4d69436', '6cc91657c1124fd0a084c25a3d4149fb', '462df2ba2efa4f27b50d4bfb48581d5c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('de9365060bc6471ca9c16e3891a23241', '6cc91657c1124fd0a084c25a3d4149fb', '4aed1cbc059941f0ad61bc13a7ef0b70', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1ad246d2332d4e1abe2b62b7ba505f73', '6cc91657c1124fd0a084c25a3d4149fb', 'bf23d55550184dbc85cea8bcfc2671cf', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('613086697fe84daf9772ceae086a6908', '6cc91657c1124fd0a084c25a3d4149fb', '884e3ea3416f4191aedc388973096a45', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ab3434bebac845b7a5fedefdd21a8a73', '6cc91657c1124fd0a084c25a3d4149fb', '436760733c0d41fd8b76a5f7f3a1a85d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('fcad4a9af228435d8278199151e5a1f8', '6cc91657c1124fd0a084c25a3d4149fb', '94b2f8379ccf4cc3802e9c6fdc000172', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5f8b78c0a6c34f6d81d6f96332295e64', '6cc91657c1124fd0a084c25a3d4149fb', '7bc8b5cb3b20414687822ae182286fb0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('958d5a8559514ed5a58bf641a4860660', '6cc91657c1124fd0a084c25a3d4149fb', '295b0da4b6384e68ac104d514f4cff05', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('df27ba6c2f2844e79e99964928f61016', '6cc91657c1124fd0a084c25a3d4149fb', '85b1e7dd76fc41889048674c0a6dfd8d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6486626abfe9444f850d6268ed8116a0', '6cc91657c1124fd0a084c25a3d4149fb', 'e5ec3ed34ff54fc4a95ba1bdb8affe06', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('dcab22981b8b4a9d865f5e1650565b20', '6cc91657c1124fd0a084c25a3d4149fb', '55d0ac4146ac437693f19a2e3a574eca', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b86390264b1e4f27b8a8611eb2a55ece', '6cc91657c1124fd0a084c25a3d4149fb', '9fbd271661384021ab294c9d0ccc86d0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b77e7c45b04f4da793424030763035da', '6cc91657c1124fd0a084c25a3d4149fb', '7f4c5c507fea4f518e9e6b8d50fb0abe', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5f45b4c8b6f343aca41750e5d8f8df90', '6cc91657c1124fd0a084c25a3d4149fb', '8c99d0bfb08643f9b596108a4673e1cd', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('19ac58901cda48ce89de9433a69b0698', '6cc91657c1124fd0a084c25a3d4149fb', '11df6f19298a4d82824b73b7718f4439', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0b98cd188fba4dc3822b5ccff2284cc8', '6cc91657c1124fd0a084c25a3d4149fb', 'c23686d574504ca8bd53127f95b4349e', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b535d52326704b3db8b701fb2dc3d3ce', '6cc91657c1124fd0a084c25a3d4149fb', '7749dd82de6d42b89a0088be734e01fc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bae1621d2b5c49e1ac4a06b036843ef9', '6cc91657c1124fd0a084c25a3d4149fb', 'ed7d33bb064a41ea8ac6f39785a533af', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e2ce86b0c05649f7ba0fbb0272e0f0ad', '6cc91657c1124fd0a084c25a3d4149fb', '13fbeff781a442abb25fb39db9ef36fb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6181efc570b14c3485864f4882b336cc', '6cc91657c1124fd0a084c25a3d4149fb', '34729739b62e48b7a5880fa9e031ab38', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2ab485856db14b84b34d7d83bb827b9f', '6cc91657c1124fd0a084c25a3d4149fb', '333b241d8b11467fb057b5f2ff724778', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('770d5e79a0194cbdbf641450012cc5fc', '6cc91657c1124fd0a084c25a3d4149fb', '69a2fcdeeb2040c291b429bb4138c5b7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('20779458ecf14a41ab37cc4a01e7e209', '6cc91657c1124fd0a084c25a3d4149fb', '7d6a3f461230454ca4809e5a962c1579', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a1101759ac1440f18969ff870c3f9e0b', '6cc91657c1124fd0a084c25a3d4149fb', 'c01cdfd54e934036b7d4134db1516d27', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7b35818a72c646aebc67f2cdbb85bb17', '6cc91657c1124fd0a084c25a3d4149fb', '41759bd102f64b289a2277b0483ef309', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bbda8f227f2c488d957523734ff28fc4', '6cc91657c1124fd0a084c25a3d4149fb', '46607ab6ee064517803ac0f6e518e090', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b89a536997b84491b8d935c73cc8df64', '6cc91657c1124fd0a084c25a3d4149fb', '94cfd1967aa54d0facb1e881ffd9165c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('34cd972eb0844878adb78bed1704741d', '6cc91657c1124fd0a084c25a3d4149fb', '36b40b93f3a240c1958a4a45b3971f91', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4838a6ab16074dac94a5b5218b0e3c3c', '6cc91657c1124fd0a084c25a3d4149fb', 'cb9fb1d5d4c647639fda359c9384a257', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7d56427d0f824bf1991112dd16b72d01', '6cc91657c1124fd0a084c25a3d4149fb', 'fde0d863e836461cb636cdea912fb139', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('81c05ea0add64fb0ac98ea2d99bd1d3b', '6cc91657c1124fd0a084c25a3d4149fb', 'e4c46e238c4743ceb5b38855dda7aef7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4efeee9b19594328a8563e2898b5627f', '6cc91657c1124fd0a084c25a3d4149fb', 'c1de6048be924b43ad71c1c8062765a9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('925f8c54fd854d3b89fcbcca2b4c9a76', '6cc91657c1124fd0a084c25a3d4149fb', 'dbaefa58749847619f7b23ca0dc04a9d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bb36e2b8697d433f9d78b0043d0880a6', '6cc91657c1124fd0a084c25a3d4149fb', 'e6e02f94f9f1435b89f1a87277be0dcf', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('34df23157aaa40cf8fe5107d4732bc7f', '6cc91657c1124fd0a084c25a3d4149fb', '15bd7370424d4c92bc57a4b5c61a6894', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('33545ca7ea8a4b32a4550daada57d0df', '6cc91657c1124fd0a084c25a3d4149fb', '79aca92b47be422998f9b825c70b6920', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('f4a12896bb2540c0a18cabfdf1c83029', '6cc91657c1124fd0a084c25a3d4149fb', 'e70278513d6b445fb040e43ad480cfda', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7b095fed75e548d5937f0d4f0c987030', '6cc91657c1124fd0a084c25a3d4149fb', 'd512ee465e73494d9fe9fad1d7d0741d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('dac5fbbde5bc48f888665d45c5d0de6e', '6cc91657c1124fd0a084c25a3d4149fb', 'ab0ec95e2bac499ab597c1011cae1dd4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4e961784b9164379bacdf5366f38831b', '6cc91657c1124fd0a084c25a3d4149fb', '658b889fdc9a4a7b8d72d256ac4acd59', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1367becf4e074ea49f1ebba2a09b5915', '6cc91657c1124fd0a084c25a3d4149fb', 'eef2f33c66be419daedf586056c4b887', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3a56a78901ec4075a122966b4373bcdd', '6cc91657c1124fd0a084c25a3d4149fb', '4cf871acc3804ed2b4d15532bdf8a9d4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('42ac32200f024536b806ae0909a6e8e2', '6cc91657c1124fd0a084c25a3d4149fb', 'e4048ceca484490f980d473e553adcc3', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('eafd0f6f9dec46308f40c03066467dbb', '6cc91657c1124fd0a084c25a3d4149fb', 'f60c9d3c0a464b98bb0e3f035ca8835b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1410faa494274954a86551a662767440', '6cc91657c1124fd0a084c25a3d4149fb', 'cc1d3de228834735878f207c4b15afcc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('57f682229c8b4099b2149e593a0b488c', '6cc91657c1124fd0a084c25a3d4149fb', '34e97d3042434388aa9c52c28cff6c59', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d7e86fb2f2254dcf909e245f70f955e6', '6cc91657c1124fd0a084c25a3d4149fb', '647509c39b0a484889815740a1672c03', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bb7f963ef9594d259671b01239d903f2', '6cc91657c1124fd0a084c25a3d4149fb', '40600a7bc86145ada843a031da4d6eed', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ce9c82ad417a4b0d86005280697817a0', '6cc91657c1124fd0a084c25a3d4149fb', '6fe34031e850493d8148e9c69bb545e2', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('62c0ff91cd5f448eb8f35d0e0fcbceb6', '6cc91657c1124fd0a084c25a3d4149fb', '5c340a37619143f8a5814d955276c2d7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('56173450b2ed4375aa6e189243ef84eb', '6cc91657c1124fd0a084c25a3d4149fb', 'c339e0d99bdb41adb1b89be60de404ff', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e2ba9cfa925d4a3fa5a04cfc538b4473', '6cc91657c1124fd0a084c25a3d4149fb', 'eb859116f527448290ac51a8a1ac3801', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('777fbf29827a40aa858174bf836dd99e', '6cc91657c1124fd0a084c25a3d4149fb', '1246fcc023c747ac84765454f16bd7d4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c3d90916ba9c41b69f27a1f3cffcf3c3', '6cc91657c1124fd0a084c25a3d4149fb', '63dd24bc581f4d31a434f8da18a5d986', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('74b05e6d00c04e43bc63b72169c04bc8', '6cc91657c1124fd0a084c25a3d4149fb', 'd03370b6b304402eb31327c7050b4c5a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9a0e8bcfa0554886a91730edefd10cc9', '6cc91657c1124fd0a084c25a3d4149fb', '73ba0ece3e564ab8a90f8cd49655bcbc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2423b698532447aa88c4a66897904fc5', '6cc91657c1124fd0a084c25a3d4149fb', '0ecce3dad4a44c2daed45b7150592938', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('01c05110f76b4b998ec8bc779de2034a', '6cc91657c1124fd0a084c25a3d4149fb', '7414fd56f60d49a19aaa8e80e7cf67c3', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6f2edb1278164006b474bebacf34dc6f', '6cc91657c1124fd0a084c25a3d4149fb', '0ffed834283d483796c341eba303afc5', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('47ac4a13765642c4a14ba003709e2ff1', '6cc91657c1124fd0a084c25a3d4149fb', 'beb94888f2d44ea5a9c0bb68b155f05b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7fad995f89fe4b7e84b29b4efc0e86d4', '6cc91657c1124fd0a084c25a3d4149fb', 'b21e1e8c6251425893bd303982034c7a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('8e81a78ef7bd4ff48aa9b55b02b1dff9', '6cc91657c1124fd0a084c25a3d4149fb', 'f08a8ac6215c4f5fbcbfbf4d29f08b83', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c5513b783f6f4c2ba654f6fed8d95c94', '6cc91657c1124fd0a084c25a3d4149fb', '76a174b3b80f49cea47bb03895ead2c8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a539cfefcd9a4da8bf6293af8f510944', '6cc91657c1124fd0a084c25a3d4149fb', '1758cafec1b9489d8de2be5b4a42382b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('04a57fe7ceea4362bdc816e4d8bbdb4c', '6cc91657c1124fd0a084c25a3d4149fb', '423268e98c384c2a878822489ebfb096', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('701f58dd7aa84d9f86d4ade401b9a186', '6cc91657c1124fd0a084c25a3d4149fb', 'b213dd2598704723b76e2547ee32d743', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('af7326f9fdd1438da33c29878bb0dc60', '6cc91657c1124fd0a084c25a3d4149fb', 'e04624975a2a480cadc613191df238fe', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('edbecb394b48448d99475f3d342e71d9', '6cc91657c1124fd0a084c25a3d4149fb', 'ad0c1ae44ab6429c91b67d2bb440127f', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ad941e70c8474138836fe9793172490f', '6cc91657c1124fd0a084c25a3d4149fb', '4c4dac9d42144bc0930b9a694195f211', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('974d691463894ae6ba99ecd99c8043fb', '6cc91657c1124fd0a084c25a3d4149fb', '20ad69f747014a7e9c989a319f6a2efa', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7ab32d75680f441387838004121384d5', '6cc91657c1124fd0a084c25a3d4149fb', '52216cc0b550447db4d6cc9e48e5cb53', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('cb29d61d30c24d0d9c5444721723aea2', '6cc91657c1124fd0a084c25a3d4149fb', 'b2c5d740e7d44abcb44ed211f0f5c656', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5e3965de4d0a40d0b9cdbe1bd7d1568d', '6cc91657c1124fd0a084c25a3d4149fb', '0293bfa9092047febb04397414a5b571', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bf9afcb9545c44b081609d4de6a5a21f', '6cc91657c1124fd0a084c25a3d4149fb', '8af4ba5141e74734bf31a5594b1b5fd9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('daeed5868dfe4e108c5aedaf455868bc', '6cc91657c1124fd0a084c25a3d4149fb', '5bc9cfda1b63406398ca13a104808366', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7c571c83e6a642aeb0b3983b8ce28011', '6cc91657c1124fd0a084c25a3d4149fb', '9230caa6dabe49688c5a8bf476eea2e0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('843c456d6dae4eb6b5c185a86cd3d0e9', '6cc91657c1124fd0a084c25a3d4149fb', '35a2668a096d41518609a282204e1914', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d09db94013434695a99d54df74223a5f', '6cc91657c1124fd0a084c25a3d4149fb', '67c2f6497efe4d4cbe5eab94f205e1b0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('77b0d52abf5145e2b66654320cd907ef', '6cc91657c1124fd0a084c25a3d4149fb', '585f6455d44b41588d6e3307d1d33c88', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('794df068240643d98321cdf72fdfd8ba', '6cc91657c1124fd0a084c25a3d4149fb', '486f613b494347278165fc0e10d9cfd8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('fb673127319b4ebaa57ce247e719c739', '6cc91657c1124fd0a084c25a3d4149fb', '1cf625fec4a44e749dca0f81ee23b3a1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6231cca7fbd64aeeafdaceeb71d1c942', '6cc91657c1124fd0a084c25a3d4149fb', 'f0559467c3354f3d9876f3c83d338c63', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4e5a34c113384c548e2c323b195d6997', '6cc91657c1124fd0a084c25a3d4149fb', '63bb6a0618a94af78e218a99a9ba9d50', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6aebb688f6494762b167a5b1c4720b7d', '6cc91657c1124fd0a084c25a3d4149fb', 'f66714ea379443a1a3f372d54b79417a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5b7f20594e074fb2b4db09508e2285ce', '6cc91657c1124fd0a084c25a3d4149fb', '3c16572374304850920411a65323624b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2785a5b8cffd45bfab510312a98f688b', '6cc91657c1124fd0a084c25a3d4149fb', 'bd2312de5d394cb29db7b1274f165fb0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d4fbf469d8af47b2bcdc675005820d07', '6cc91657c1124fd0a084c25a3d4149fb', '5e082b2f411c409eabdb193160d73c83', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ee0c2dcb5f8a476297ae4f235e6f0ee0', '6cc91657c1124fd0a084c25a3d4149fb', '105a77337c04401e85c2e23497c6dcd2', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d2c495718f244235a8a1c58b6f7ce064', '6cc91657c1124fd0a084c25a3d4149fb', 'd88fed8ee8d24441889bc51e6aab21c8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('913e2ae6581c407ba3d3748338a5441d', '6cc91657c1124fd0a084c25a3d4149fb', '62712500e20040799829cb5f3d5659f8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('97e56205be1f41f5bfdc31b7424b1644', '6cc91657c1124fd0a084c25a3d4149fb', 'cbe2ab64351f4819bffab722ba927889', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4794aedf4b8e4fdc946ce5ce0eb6974c', '6cc91657c1124fd0a084c25a3d4149fb', 'cd4989d9a9d442df8e045f26e5537822', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('df067842783c4623b9c754c9a120db1b', '6cc91657c1124fd0a084c25a3d4149fb', '17c32c7f44744e79ad13b9dc900c1d3c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9b6913df97634411901344b3fc3b2d03', '6cc91657c1124fd0a084c25a3d4149fb', '9c6efc976e264b5eafb8e2464e5e276a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4e51616b4f6d41c591423c1d15f5987b', '6cc91657c1124fd0a084c25a3d4149fb', '714bbd2712da4b028dd02b1adef13239', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3eb04513db6f4482ad2afed5177b0ad3', '6cc91657c1124fd0a084c25a3d4149fb', '4752db5fe15d47e0b07df7a8205b2d1d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('793224242a6846a4b247035277b2af2e', '6cc91657c1124fd0a084c25a3d4149fb', 'f6ec4ab3b8704566a4f9f4e4b88011ba', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('dc9872929bd04d47a11160179fdea2bb', '6cc91657c1124fd0a084c25a3d4149fb', '729971d18f864e3c8f361df6fb0e5331', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('468638851ffb49718060865afb79e868', '6cc91657c1124fd0a084c25a3d4149fb', '4a886766f7384d1dbe444092b3c00ee7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('485b0d58f2d14ab684d859283aa17023', '6cc91657c1124fd0a084c25a3d4149fb', '947af1008afc45a885243e9c5e2bd373', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9a72d13b7479424dafae0fd2720537d5', '6cc91657c1124fd0a084c25a3d4149fb', '775226b82dd04ad6a0f4e9e3e4bfe995', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('88a5b3ce0b544c15be23ced7b73ab501', '6cc91657c1124fd0a084c25a3d4149fb', 'e2f6e2d19cc74ad99bce83a3bd677c06', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1d1318ff863b4f1cb631312c02144f8d', '6cc91657c1124fd0a084c25a3d4149fb', '335e7fcd58cc43d3b282300aadf9131c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7e92308f5f2b48deaf38801e71963f3c', '6cc91657c1124fd0a084c25a3d4149fb', '3ad71311f0b8478e9dab302f093fe923', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('22d1466bcb6e4835a3d5e00f6eb32292', '6cc91657c1124fd0a084c25a3d4149fb', 'acf468083046401382d0935509e381a7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c4e215ce2f0a42aba7b7c6e476cf118d', '6cc91657c1124fd0a084c25a3d4149fb', 'a810da31cbc94946bdf3b70cfa6776bc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9a999f278d89470fbe99b143aa33474a', '6cc91657c1124fd0a084c25a3d4149fb', 'c29f6dbfdfb14949a3a6ec1f2e546ca4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c5b8d1672cf64937bc1d1964797e77b2', '6cc91657c1124fd0a084c25a3d4149fb', '89a6563029b04b4b9576e9f4f5f8a4e1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6e6e63357c4e48beaf48a7d6ce6190f2', '6cc91657c1124fd0a084c25a3d4149fb', 'f94a1d0909fc4ab99b536dd30c3cecdb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b12112d17eb54b4ea320291d5a58294f', '6cc91657c1124fd0a084c25a3d4149fb', '1a4f0c5451414b86b76f20fce99b33cb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a248440805144730b5f925bc05313181', '6cc91657c1124fd0a084c25a3d4149fb', '60ee2aff8f354edabca6a2f0743e5f1e', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('98663c7124fa4a83914e787ed62255f5', '6cc91657c1124fd0a084c25a3d4149fb', 'b7fc8390eee54a1cbf6fccd58ac1702b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a99fcffbc2af4a9bbec261414548c93e', '6cc91657c1124fd0a084c25a3d4149fb', 'f709b935eb474912846a52a76fb4b06c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('045c72f2ed6d4ff1986c7bad6dc54ea9', '6cc91657c1124fd0a084c25a3d4149fb', '9ca1f7d12219468bac0b022249f58c07', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7487655ecce64e1da92e73564b9fa546', '6cc91657c1124fd0a084c25a3d4149fb', '0576e7e5f375416b8d2d9c15bafeee6c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('637d25b8706d418caa1fcfe079030dff', '6cc91657c1124fd0a084c25a3d4149fb', '2f03fcd0b43044b8b8599d2d712f07e0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('64a43e9a898b402c8f8df860655e0824', '6cc91657c1124fd0a084c25a3d4149fb', 'bc2fa0c13a3f46bbb821b149376f0386', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('40a1769b065a48ebbf41786b58ddb127', '6cc91657c1124fd0a084c25a3d4149fb', '4ab5d91f9920469ea4534d63fd6a34c9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c7bee17089904c91aba175418a09ac52', '6cc91657c1124fd0a084c25a3d4149fb', '5a55679dee874e25a2d66f603967b572', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('de8e5b01e5dd481ab4e775da17649f40', '6cc91657c1124fd0a084c25a3d4149fb', '95f71108003545af93b5fdfe9aaa4608', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('78bb76e28462445b96e5d119e5855079', '6cc91657c1124fd0a084c25a3d4149fb', '7c3f63f9395b4f2f91300b8b20628506', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1abc4c17cfb347898d78f07c7ccd2db4', '6cc91657c1124fd0a084c25a3d4149fb', '2a68ddae4d5049f285f9f6fb41e8bb88', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2d3bf4fd04e74b0e99649478a09a5c11', '6cc91657c1124fd0a084c25a3d4149fb', 'f2d26497b1694873ad096ec7951aa175', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('524ffe6804a34dc9ae769a1cffa187c4', '6cc91657c1124fd0a084c25a3d4149fb', '999d69e60b8a42e7865c15b9d7179194', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d83d9e1896704c60b60691d1a4f9818a', '6cc91657c1124fd0a084c25a3d4149fb', '973131394b2645f6b447ab424c18aeea', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0f7249b88fbf4887b844fe7eb46c5ffc', '6cc91657c1124fd0a084c25a3d4149fb', '97174df921934a03a8fce3033aaf1102', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3da4816f3fb64eb4a073f4229111e15d', '6cc91657c1124fd0a084c25a3d4149fb', 'e8843f19bd2247d39621fb1fe1b72173', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5cb4d6691ba54eb986230663d6839fa0', '6cc91657c1124fd0a084c25a3d4149fb', 'aee02e0dbaf84ee78b4f318abcdd2e8c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6de5bd4d8cb449f5bfb8b83f7887024f', '6050c744670f46d29720f6a66afead28', '35d3b5803269495c838c7000dbb2dde1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('487c0800ed904bbba1012708164eb534', '6050c744670f46d29720f6a66afead28', '2c1572191af543f5831390e76fe77438', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6bd5970b111f419aa2d03c7d2c4d0f44', '6050c744670f46d29720f6a66afead28', 'f1bb7ff45d844ab5b21151898ffa2da4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c71a64b89f0c4d0ba0cbf0b57c82a380', '6050c744670f46d29720f6a66afead28', 'e7e8a03b4f8445d4b68f81bb6dbb898a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2d01683209da48799cb18f81eeeb6828', '6050c744670f46d29720f6a66afead28', '053550833d724efcbd69d6be6432a8b5', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('29c75b59630347efa2bdf623f629d542', '6050c744670f46d29720f6a66afead28', 'e775023152184671b8aa1e0698c7e7a0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e4987411534d4630ae929ade219efd6c', '6050c744670f46d29720f6a66afead28', '3e7da01ee9f04e59902733e02e6c7987', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6e8afe179f4e463da98b1958ba24d637', '6050c744670f46d29720f6a66afead28', 'a34714bb926447118faec80f6da4987a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a62da3dbd2704349b3e47ca236941e20', '6050c744670f46d29720f6a66afead28', 'fd5e1c92c60348488cca8a2cea880bd6', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b29e20b0079348bd970a024b3f5df41b', '6050c744670f46d29720f6a66afead28', '3b518de12eb34b3e93af8540f72344fa', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5df9b2b449104f4a8742ebaad0773425', '6050c744670f46d29720f6a66afead28', '462df2ba2efa4f27b50d4bfb48581d5c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('50c279f97cac4def8b7c877f818baf6c', '6050c744670f46d29720f6a66afead28', '4aed1cbc059941f0ad61bc13a7ef0b70', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ed28ae52c16e43e6ba19db38399fd35b', '6050c744670f46d29720f6a66afead28', 'bf23d55550184dbc85cea8bcfc2671cf', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('43172637ea4643a59a269f7032f4cdf4', '6050c744670f46d29720f6a66afead28', '884e3ea3416f4191aedc388973096a45', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('cbea66d95cab455386203f2e722c7591', '6050c744670f46d29720f6a66afead28', '436760733c0d41fd8b76a5f7f3a1a85d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a7e1c1f8544f41868cbfe20c364d64b3', '6050c744670f46d29720f6a66afead28', '94b2f8379ccf4cc3802e9c6fdc000172', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('cb9c94d667ba40279bf7efb85e081929', '6050c744670f46d29720f6a66afead28', '7bc8b5cb3b20414687822ae182286fb0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d1a6a253bd814978ac053c12b4b9a8bd', '6050c744670f46d29720f6a66afead28', '295b0da4b6384e68ac104d514f4cff05', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1ab9cd1d3a18401daa7b2e7f42984ecb', '6050c744670f46d29720f6a66afead28', '85b1e7dd76fc41889048674c0a6dfd8d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7558f1b8a58a4ba5ad29bf07a27a88cc', '6050c744670f46d29720f6a66afead28', 'e5ec3ed34ff54fc4a95ba1bdb8affe06', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('49ed37c723d5471ea765aad8e5147388', '6050c744670f46d29720f6a66afead28', '55d0ac4146ac437693f19a2e3a574eca', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5a8e5da817334cc69c6a8bfa1f335ca5', '6050c744670f46d29720f6a66afead28', '9fbd271661384021ab294c9d0ccc86d0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0a5674c177cb4426ae60d3ef3979806e', '6050c744670f46d29720f6a66afead28', '7f4c5c507fea4f518e9e6b8d50fb0abe', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5dd1bd2dea6d404ab956615a75345e39', '6050c744670f46d29720f6a66afead28', '8c99d0bfb08643f9b596108a4673e1cd', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('76a7aa8b6b154306b8464eb5e92055ea', '6050c744670f46d29720f6a66afead28', '11df6f19298a4d82824b73b7718f4439', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7705df85fb1e4fa0b22c162a1b062785', '6050c744670f46d29720f6a66afead28', 'c23686d574504ca8bd53127f95b4349e', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9ab86670d0854ef59bbf8e208d79d886', '6050c744670f46d29720f6a66afead28', '7749dd82de6d42b89a0088be734e01fc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3522fd02746f45feaaecb73d56d629c6', '6050c744670f46d29720f6a66afead28', 'ed7d33bb064a41ea8ac6f39785a533af', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('833ce1562bd44fe5b58dbc8a44cb4935', '6050c744670f46d29720f6a66afead28', '13fbeff781a442abb25fb39db9ef36fb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('72af56853b1b4728b61fd468a47f1eb4', '6050c744670f46d29720f6a66afead28', '34729739b62e48b7a5880fa9e031ab38', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('989f6c6b8efa4cf49df258e7d36bece1', '6050c744670f46d29720f6a66afead28', '333b241d8b11467fb057b5f2ff724778', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ccd6fca979604cd4b6a8507c27baa362', '6050c744670f46d29720f6a66afead28', '69a2fcdeeb2040c291b429bb4138c5b7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('102126c8f32e4504b41669c726fa5135', '6050c744670f46d29720f6a66afead28', '7d6a3f461230454ca4809e5a962c1579', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('12fd2c7b4cf94764bb1e5fc4d981ea09', '6050c744670f46d29720f6a66afead28', 'c01cdfd54e934036b7d4134db1516d27', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d81590c291e54668a48a956d2c0097aa', '6050c744670f46d29720f6a66afead28', '41759bd102f64b289a2277b0483ef309', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('547a4648335645d99455166f4396c551', '6050c744670f46d29720f6a66afead28', '46607ab6ee064517803ac0f6e518e090', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2adb71749c1d444ead400002a80d7867', '6050c744670f46d29720f6a66afead28', '94cfd1967aa54d0facb1e881ffd9165c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9e909528ded249888ee9adda280532e6', '6050c744670f46d29720f6a66afead28', '36b40b93f3a240c1958a4a45b3971f91', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bd6197b9586d425489c2ef3e792ab2db', '6050c744670f46d29720f6a66afead28', 'cb9fb1d5d4c647639fda359c9384a257', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e50566bd67bc484c9a77dc8d97a35c0c', '6050c744670f46d29720f6a66afead28', 'fde0d863e836461cb636cdea912fb139', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bd1d70bf834f4c96b925dda6d7d38103', '6050c744670f46d29720f6a66afead28', 'e4c46e238c4743ceb5b38855dda7aef7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e338e884e45242ba9f47e71c40879028', '6050c744670f46d29720f6a66afead28', 'c1de6048be924b43ad71c1c8062765a9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('f1cb38f7da47476e8cb4fd8fc6c8b4c4', '6050c744670f46d29720f6a66afead28', 'dbaefa58749847619f7b23ca0dc04a9d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d7cc4971d8b447dba6ada4cf1f2e6e2b', '6050c744670f46d29720f6a66afead28', 'e6e02f94f9f1435b89f1a87277be0dcf', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6e3cdfde44974d0ab07a8e57445e7ea3', '6050c744670f46d29720f6a66afead28', '15bd7370424d4c92bc57a4b5c61a6894', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('314da3a6969a40a382d28ac279eda0ec', '6050c744670f46d29720f6a66afead28', '79aca92b47be422998f9b825c70b6920', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('93413c2ed0654e3f883ebba68d71e432', '6050c744670f46d29720f6a66afead28', 'e70278513d6b445fb040e43ad480cfda', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2a70d66db2f94a12b7673ffe20efec19', '6050c744670f46d29720f6a66afead28', 'd512ee465e73494d9fe9fad1d7d0741d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('148048d44f174052bf1025fa9957abaa', '6050c744670f46d29720f6a66afead28', 'ab0ec95e2bac499ab597c1011cae1dd4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('fdd1647172c547d4ab6f7414598979fa', '6050c744670f46d29720f6a66afead28', '658b889fdc9a4a7b8d72d256ac4acd59', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d166f641ec5b4981a8aef21db42cf7ce', '6050c744670f46d29720f6a66afead28', 'eef2f33c66be419daedf586056c4b887', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4b0a2baa708a4386be3001d28136c062', '6050c744670f46d29720f6a66afead28', '4cf871acc3804ed2b4d15532bdf8a9d4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e863167211464249ac74bab7334a7aeb', '6050c744670f46d29720f6a66afead28', 'e4048ceca484490f980d473e553adcc3', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('cfcd5855f1c34fba805694f265c9f108', '6050c744670f46d29720f6a66afead28', 'f60c9d3c0a464b98bb0e3f035ca8835b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e55e1e4e0c924c199497329dbade4861', '6050c744670f46d29720f6a66afead28', 'cc1d3de228834735878f207c4b15afcc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('33a949ddf2aa44bea117579177caf196', '6050c744670f46d29720f6a66afead28', '34e97d3042434388aa9c52c28cff6c59', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('96ceafa6aa62443eaec710111c346235', '6050c744670f46d29720f6a66afead28', '647509c39b0a484889815740a1672c03', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('80cbd629934e4283a36de8a40ab4e383', '6050c744670f46d29720f6a66afead28', '40600a7bc86145ada843a031da4d6eed', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5b59331905174d408b859e5b888507ba', '6050c744670f46d29720f6a66afead28', '6fe34031e850493d8148e9c69bb545e2', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('63b80057789749b09a82b22ba83df23f', '6050c744670f46d29720f6a66afead28', '5c340a37619143f8a5814d955276c2d7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c4c5b2a4f73a46e78c6649196835b44b', '6050c744670f46d29720f6a66afead28', 'c339e0d99bdb41adb1b89be60de404ff', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9e6d37d0d951471c8b4dd731402cc83c', '6050c744670f46d29720f6a66afead28', 'eb859116f527448290ac51a8a1ac3801', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('53b9b56aecb842059e3d938b80ff4b28', '6050c744670f46d29720f6a66afead28', '1246fcc023c747ac84765454f16bd7d4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b92445c0e4fa4d139a8fd8e50aa35222', '6050c744670f46d29720f6a66afead28', '63dd24bc581f4d31a434f8da18a5d986', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2e20c5bef3e649479f829426f5d84f26', '6050c744670f46d29720f6a66afead28', 'd03370b6b304402eb31327c7050b4c5a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('59718c36db3045469f8153c7d51f5d63', '6050c744670f46d29720f6a66afead28', '73ba0ece3e564ab8a90f8cd49655bcbc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('803cbadd6c1449459073fc4b77324b9c', '6050c744670f46d29720f6a66afead28', '0ecce3dad4a44c2daed45b7150592938', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('acd1b05bad1547cdb92fad4f0ae4de2a', '6050c744670f46d29720f6a66afead28', '7414fd56f60d49a19aaa8e80e7cf67c3', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0df0943df9e847dca3347309448af0d4', '6050c744670f46d29720f6a66afead28', '0ffed834283d483796c341eba303afc5', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3555674aa82d466ca40b59dab86da012', '6050c744670f46d29720f6a66afead28', 'beb94888f2d44ea5a9c0bb68b155f05b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('379b298cfd404732b3811446f5ce3ae1', '6050c744670f46d29720f6a66afead28', 'b21e1e8c6251425893bd303982034c7a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5bc0142eb35746e5886d2536211abb71', '6050c744670f46d29720f6a66afead28', 'f08a8ac6215c4f5fbcbfbf4d29f08b83', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('82d92696d53d4ccebcbb57ad812bf976', '6050c744670f46d29720f6a66afead28', '76a174b3b80f49cea47bb03895ead2c8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c54aba8bedaa47a6a0a8db19df614e8e', '6050c744670f46d29720f6a66afead28', '1758cafec1b9489d8de2be5b4a42382b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('194532144a974093b266ab5e03d3bf49', '6050c744670f46d29720f6a66afead28', '423268e98c384c2a878822489ebfb096', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3de6322af028448d919ff4042a3426c9', '6050c744670f46d29720f6a66afead28', 'b213dd2598704723b76e2547ee32d743', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('33435fb5628c4d7bbb9b98d59612ca60', '6050c744670f46d29720f6a66afead28', 'e04624975a2a480cadc613191df238fe', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a9ef2ecb298b486a8b6350a5bb8f7041', '6050c744670f46d29720f6a66afead28', 'ad0c1ae44ab6429c91b67d2bb440127f', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3276ca4d585a47c19ae080819cfdc76a', '6050c744670f46d29720f6a66afead28', '4c4dac9d42144bc0930b9a694195f211', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b75dd336597f464b98289c040ce18f05', '6050c744670f46d29720f6a66afead28', '20ad69f747014a7e9c989a319f6a2efa', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6afa1df29105439ebe9cd7722eb78b9e', '6050c744670f46d29720f6a66afead28', '52216cc0b550447db4d6cc9e48e5cb53', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3e8ac8a2417441d7b261431ad07ef116', '6050c744670f46d29720f6a66afead28', 'b2c5d740e7d44abcb44ed211f0f5c656', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7956ff25c9f7409e881b512815493918', '6050c744670f46d29720f6a66afead28', '0293bfa9092047febb04397414a5b571', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a29a02cca147427c860d9188a255d194', '6050c744670f46d29720f6a66afead28', '8af4ba5141e74734bf31a5594b1b5fd9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ce49bb79a5ce4afca7dd2dd0ad091860', '6050c744670f46d29720f6a66afead28', '5bc9cfda1b63406398ca13a104808366', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('97e1434fcd92489b8fef9fa06b5278af', '6050c744670f46d29720f6a66afead28', '9230caa6dabe49688c5a8bf476eea2e0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('565ccb940eaf4e0a87b3cd35234b6493', '6050c744670f46d29720f6a66afead28', '35a2668a096d41518609a282204e1914', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5b04dc0dd95d4222ae47702585b79013', '6050c744670f46d29720f6a66afead28', '67c2f6497efe4d4cbe5eab94f205e1b0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('61f44a9495424a37998786fd45f57833', '6050c744670f46d29720f6a66afead28', '585f6455d44b41588d6e3307d1d33c88', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5bdcf6f3b4f8493cbb512fce40726c1d', '6050c744670f46d29720f6a66afead28', '486f613b494347278165fc0e10d9cfd8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('9a1161f85f244bdab5e8dd0ab3d65f87', '6050c744670f46d29720f6a66afead28', '1cf625fec4a44e749dca0f81ee23b3a1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4042d5a82b1342979dce741bb9b307f0', '6050c744670f46d29720f6a66afead28', 'f0559467c3354f3d9876f3c83d338c63', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3431e84a86ac4f40946cd03fe8f9833b', '6050c744670f46d29720f6a66afead28', '63bb6a0618a94af78e218a99a9ba9d50', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e0e6e297bfed4af6ba5a50412c891660', '6050c744670f46d29720f6a66afead28', 'f66714ea379443a1a3f372d54b79417a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0277fd06ceb346a2b22024c1bbe0454a', '6050c744670f46d29720f6a66afead28', '3c16572374304850920411a65323624b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('1c18e8e0082e44618a4acb992e3e8e07', '6050c744670f46d29720f6a66afead28', 'bd2312de5d394cb29db7b1274f165fb0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('54269151457640428bb5f0d11a5ec38f', '6050c744670f46d29720f6a66afead28', '5e082b2f411c409eabdb193160d73c83', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d1cf99ac7d404821a466f6ef298f8c0c', '6050c744670f46d29720f6a66afead28', '105a77337c04401e85c2e23497c6dcd2', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2c1cf0c7401e49a89438850d3789b2e5', '6050c744670f46d29720f6a66afead28', 'd88fed8ee8d24441889bc51e6aab21c8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('c039a7a4ac5c4e98b054b2558000a2b7', '6050c744670f46d29720f6a66afead28', '62712500e20040799829cb5f3d5659f8', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('01859b52cf3447b7acf4310e0d14c45f', '6050c744670f46d29720f6a66afead28', 'cbe2ab64351f4819bffab722ba927889', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('d5094e64832f4194bf0ac5591fbe6b7f', '6050c744670f46d29720f6a66afead28', 'cd4989d9a9d442df8e045f26e5537822', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a5e00cd2ed2e44d7b381d247453c3c6c', '6050c744670f46d29720f6a66afead28', '17c32c7f44744e79ad13b9dc900c1d3c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('0f97e1b6af674ccfac549bf2b3e4c54b', '6050c744670f46d29720f6a66afead28', '9c6efc976e264b5eafb8e2464e5e276a', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('43d826499d6d45b297d2b9cab32db18a', '6050c744670f46d29720f6a66afead28', '714bbd2712da4b028dd02b1adef13239', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('bf54e2276bdd4f7b9f4bfc45b254d103', '6050c744670f46d29720f6a66afead28', '4752db5fe15d47e0b07df7a8205b2d1d', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a2cf6d26d1114bc7a6e3118f35ee938e', '6050c744670f46d29720f6a66afead28', 'f6ec4ab3b8704566a4f9f4e4b88011ba', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e7eeb969bd54467eb6f808ed1d49b9e8', '6050c744670f46d29720f6a66afead28', '729971d18f864e3c8f361df6fb0e5331', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ab7fb1c1cb5f420e9e6ea9a7834fe2f1', '6050c744670f46d29720f6a66afead28', '4a886766f7384d1dbe444092b3c00ee7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3bdc1f293aab45dfafc5743cfdcf3f43', '6050c744670f46d29720f6a66afead28', '947af1008afc45a885243e9c5e2bd373', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6b89dd18dd204b268f4cbf980a6c84eb', '6050c744670f46d29720f6a66afead28', '775226b82dd04ad6a0f4e9e3e4bfe995', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('7c82b618bcfe4509a167398cf586d22a', '6050c744670f46d29720f6a66afead28', 'e2f6e2d19cc74ad99bce83a3bd677c06', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('51e7043c54934f92941ff068728a0df8', '6050c744670f46d29720f6a66afead28', '335e7fcd58cc43d3b282300aadf9131c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('53e65b5b606f4ad486217f7fd25c58b1', '6050c744670f46d29720f6a66afead28', '3ad71311f0b8478e9dab302f093fe923', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('6c00c91ad0e247138b14b9923ec4d35b', '6050c744670f46d29720f6a66afead28', 'acf468083046401382d0935509e381a7', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('262756f05e0948f8abe957081c555e43', '6050c744670f46d29720f6a66afead28', 'a810da31cbc94946bdf3b70cfa6776bc', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('39d77c49d48545379bd07626fbcb87b8', '6050c744670f46d29720f6a66afead28', 'c29f6dbfdfb14949a3a6ec1f2e546ca4', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4f8a56aae8b547658ec5d325362e5bfa', '6050c744670f46d29720f6a66afead28', '89a6563029b04b4b9576e9f4f5f8a4e1', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('a45c5da0d24c4357ae8a16a5426c1e21', '6050c744670f46d29720f6a66afead28', 'f94a1d0909fc4ab99b536dd30c3cecdb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ee7dadd236724c28b9d71a586675032b', '6050c744670f46d29720f6a66afead28', '1a4f0c5451414b86b76f20fce99b33cb', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('e4c85032ff0045ba8bce15a6015be9ae', '6050c744670f46d29720f6a66afead28', '60ee2aff8f354edabca6a2f0743e5f1e', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('29b9d7b8bece4e768e14ea0b5d258af1', '6050c744670f46d29720f6a66afead28', 'b7fc8390eee54a1cbf6fccd58ac1702b', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('369f84e7f7754a2d8cbd0f31ef80d7f8', '6050c744670f46d29720f6a66afead28', 'f709b935eb474912846a52a76fb4b06c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('5a1a51b84b6b45d195b987bd45248532', '6050c744670f46d29720f6a66afead28', '9ca1f7d12219468bac0b022249f58c07', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('663b8c21d7f74b1e89b18a412718c495', '6050c744670f46d29720f6a66afead28', '0576e7e5f375416b8d2d9c15bafeee6c', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('951a78de2c8a4b4c8ce8af2e749f7148', '6050c744670f46d29720f6a66afead28', '2f03fcd0b43044b8b8599d2d712f07e0', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('3ed9ac40970c4dba8330cf7ba98f7d3e', '6050c744670f46d29720f6a66afead28', 'bc2fa0c13a3f46bbb821b149376f0386', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('660c82c5c359427a94ec120179674614', '6050c744670f46d29720f6a66afead28', '4ab5d91f9920469ea4534d63fd6a34c9', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('b4bd1babb64f41869f8f9ca94794af59', '6050c744670f46d29720f6a66afead28', '5a55679dee874e25a2d66f603967b572', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('39a59e0ce8824c779546251eae86718e', '6050c744670f46d29720f6a66afead28', '95f71108003545af93b5fdfe9aaa4608', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('314ba5283b8344bca83789063f902f88', '6050c744670f46d29720f6a66afead28', '7c3f63f9395b4f2f91300b8b20628506', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('23793fe31b67433399f25aaa32513bf6', '6050c744670f46d29720f6a66afead28', '2a68ddae4d5049f285f9f6fb41e8bb88', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('ebaf1be9f5684fb2b2731282e02d3aff', '6050c744670f46d29720f6a66afead28', 'f2d26497b1694873ad096ec7951aa175', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('66f8e2a2b2114e54b45c1948e0d6223d', '6050c744670f46d29720f6a66afead28', '999d69e60b8a42e7865c15b9d7179194', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('4e1912e7ac2e4faa9b5f8427e4513eb3', '6050c744670f46d29720f6a66afead28', '973131394b2645f6b447ab424c18aeea', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('2fd71381f29d405382f8400ccf55009e', '6050c744670f46d29720f6a66afead28', '97174df921934a03a8fce3033aaf1102', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('aafc2b06425a45dabfe0a6c1793549a2', '6050c744670f46d29720f6a66afead28', 'e8843f19bd2247d39621fb1fe1b72173', 0, 0.00, 0.00, 0);
INSERT INTO `t_accountssubject` VALUES ('01c0bf39a8424eee8a21731d0a624952', '6050c744670f46d29720f6a66afead28', 'aee02e0dbaf84ee78b4f318abcdd2e8c', 0, 0.00, 0.00, 0);

-- ----------------------------
-- Table structure for t_customer
-- ----------------------------
DROP TABLE IF EXISTS `t_customer`;
CREATE TABLE `t_customer`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `customer_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `customer_contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `customer_tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `customer_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `customer_status` int(11) NULL DEFAULT NULL,
  `customer_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_customer
-- ----------------------------
INSERT INTO `t_customer` VALUES ('6d7c8c84fab74d85aecd0a8bc30d91ab', '202202270102', '王冰', '吴杰', '17653405826', '762966800@qq.com', 0, '无');

-- ----------------------------
-- Table structure for t_dept
-- ----------------------------
DROP TABLE IF EXISTS `t_dept`;
CREATE TABLE `t_dept`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pid` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_dept
-- ----------------------------
INSERT INTO `t_dept` VALUES ('03480ae838064579936d72bd06554d42', '张掖市远达食品有限责任公司', '0');
INSERT INTO `t_dept` VALUES ('10867405c6e44da68d0367463ba688bf', '销售部', '03480ae838064579936d72bd06554d42');
INSERT INTO `t_dept` VALUES ('f5605fc1074d41128ee16e9fbea2b5eb', '财务部', '03480ae838064579936d72bd06554d42');

-- ----------------------------
-- Table structure for t_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_menu`;
CREATE TABLE `t_menu`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pid` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `level` int(10) NULL DEFAULT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `menu_sort` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_menu
-- ----------------------------
INSERT INTO `t_menu` VALUES ('3', '系统管理', '0', 1, '/list', '系统管理', NULL, 'el-icon-s-tools', 7);
INSERT INTO `t_menu` VALUES ('303433fd75224bb58eba49c8d5afec8f', '基础数据', '0', 1, '/BasicData', '基础数据', NULL, 'el-icon-edit-outline', 1);
INSERT INTO `t_menu` VALUES ('3c067d7ae917423c8d05491878e8f73c', '账套设置', '79e0a283253e4d688ee91a2c6069fa82', 1, 'accounts', '账套设置', 'Accounts/accounts', 'el-icon-user-solid', 1);
INSERT INTO `t_menu` VALUES ('4', '菜单管理', '3', 2, 'list-1', '菜单管理', 'List/list-1', 'el-icon-menu', NULL);
INSERT INTO `t_menu` VALUES ('79e0a283253e4d688ee91a2c6069fa82', '账套管理', '0', 1, '/Accounts', '账套管理', NULL, 'el-icon-s-grid', 6);
INSERT INTO `t_menu` VALUES ('5', '角色管理', '3', 3, 'list-2', '角色管理', 'List/list-2', 'el-icon-s-help', NULL);
INSERT INTO `t_menu` VALUES ('6', '组织管理', '3', 4, 'deptlist', '组织管理', 'List/deptlist', 'el-icon-s-custom', NULL);
INSERT INTO `t_menu` VALUES ('b2c9dfe5a4fb4b928f9460369b75738c', '客户管理', '303433fd75224bb58eba49c8d5afec8f', 1, 'customerinfo', '客户管理', 'BasicData/customerinfo', 'el-icon-s-custom', NULL);
INSERT INTO `t_menu` VALUES ('b8112a64842948f7a08b42d4c754f168', '供应商管理', '303433fd75224bb58eba49c8d5afec8f', 1, 'supplier', '供应商管理', 'BasicData/supplier', 'el-icon-shopping-cart-full', NULL);
INSERT INTO `t_menu` VALUES ('e5d8a900b55048949016f12ac0c2e47a', '往来明细账查询', '1b39e9abdd2f4d6895ca53a74b42cace', 1, 'list', '往来明细账查询', 'AccountBook/list', 'el-icon-monitor', NULL);
INSERT INTO `t_menu` VALUES ('1e5ef781624f489c8dc525c358382301', '凭证审核', '4c77bf46986d4e2fb78b2ffc14285e83', 1, 'vouchercheck', '凭证审核', 'Voucher/vouchercheck', 'el-icon-s-check', NULL);
INSERT INTO `t_menu` VALUES ('8f9f07ea3cd94e97b625af6f2de16348', '损益表', '256f43f1c2c04906804e69ed038414f2', 1, 'list', '损益表', 'Report/list', 'el-icon-postcard', NULL);
INSERT INTO `t_menu` VALUES ('4ca56f8392454a52bf346d33a63370b2', '结账', '4c77bf46986d4e2fb78b2ffc14285e83', 1, 'voucherbill', '结账', 'Voucher/voucherbill', 'el-icon-coin', NULL);
INSERT INTO `t_menu` VALUES ('493f3f97018d444b85e7528b9f90a166', '明细账查询', '1b39e9abdd2f4d6895ca53a74b42cace', 1, 'index', '明细账查询', 'AccountBook/index', 'el-icon-discount', NULL);
INSERT INTO `t_menu` VALUES ('1b39e9abdd2f4d6895ca53a74b42cace', '账簿查询', '0', 1, '/AccountBook', '账簿查询', '', 'el-icon-search', 3);
INSERT INTO `t_menu` VALUES ('86901e40d0264bbd9e7fc2d04a53e047', '资产负债表', '256f43f1c2c04906804e69ed038414f2', 1, 'index', '资产负债表', 'Report/index', 'el-icon-copy-document', NULL);
INSERT INTO `t_menu` VALUES ('256f43f1c2c04906804e69ed038414f2', '报表中心', '0', 1, '/Report', '报表中心', '', 'el-icon-house', 2);
INSERT INTO `t_menu` VALUES ('5740142c46ca43da950d435b7f119935', '凭证录入', '4c77bf46986d4e2fb78b2ffc14285e83', 1, 'index', '凭证录入', 'Voucher/index', 'el-icon-edit', NULL);
INSERT INTO `t_menu` VALUES ('4c77bf46986d4e2fb78b2ffc14285e83', '凭证管理', '0', 1, '/Voucher', '凭证管理', '', 'el-icon-s-finance', 5);
INSERT INTO `t_menu` VALUES ('ca087c86d930436ca27ad878f3595fd4', '现金流量表', '256f43f1c2c04906804e69ed038414f2', 1, 'moneylist', '现金流量表', 'Report/moneylist', 'el-icon-coin', 3);
INSERT INTO `t_menu` VALUES ('e882cb0116b84f70ab9b14a579c67c08', '科目类别', '51e0cad8680c486d9ed2180b5552c19e', 1, 'subjectcategory', '科目类别', 'Subject/subjectcategory', 'el-icon-s-order', 1);
INSERT INTO `t_menu` VALUES ('51e0cad8680c486d9ed2180b5552c19e', '科目管理', '0', 1, '/Subject', '科目管理', NULL, 'el-icon-bank-card', 4);
INSERT INTO `t_menu` VALUES ('f966ce7901cc4bd39227140cb9bd34ad', '科目设置', '51e0cad8680c486d9ed2180b5552c19e', 1, 'subject', '科目设置', 'Subject/subject', 'el-icon-s-cooperation', 2);
INSERT INTO `t_menu` VALUES ('955dde43af764f0aa6ec5b1e6adc37d9', '年初余额设置', '51e0cad8680c486d9ed2180b5552c19e', 1, 'usersubject', '年初余额设置', 'Subject/usersubject', 'el-icon-money', 3);

-- ----------------------------
-- Table structure for t_menurole
-- ----------------------------
DROP TABLE IF EXISTS `t_menurole`;
CREATE TABLE `t_menurole`  (
  `role_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `menu_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_menurole
-- ----------------------------

-- ----------------------------
-- Table structure for t_org
-- ----------------------------
DROP TABLE IF EXISTS `t_org`;
CREATE TABLE `t_org`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `org_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `org_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_org
-- ----------------------------

-- ----------------------------
-- Table structure for t_role
-- ----------------------------
DROP TABLE IF EXISTS `t_role`;
CREATE TABLE `t_role`  (
  `id` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `role_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_role
-- ----------------------------
INSERT INTO `t_role` VALUES ('cfbef9e51d72434c9f05449fc21fef32', '管理员');
INSERT INTO `t_role` VALUES ('da25b71de17c493291b4e6008eb24f09', '基本人员');

-- ----------------------------
-- Table structure for t_subject
-- ----------------------------
DROP TABLE IF EXISTS `t_subject`;
CREATE TABLE `t_subject`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键id',
  `subject_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目编码',
  `subject_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目名称',
  `subject_level` int(10) NULL DEFAULT NULL COMMENT '科目等级',
  `pid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '父级id',
  `insert_time` datetime NULL DEFAULT NULL COMMENT '新增时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '修改时间',
  `isdel` int(10) NULL DEFAULT NULL COMMENT '是否删除，0未删除，1删除',
  `mnemonic_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '助记码',
  `subject_category` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目类别',
  `subject_categoryname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目类别名称',
  `balance_direction` int(10) NULL DEFAULT NULL COMMENT '余额方向，1借方，2.贷方',
  `foreign_account` int(10) NULL DEFAULT NULL COMMENT '外币核算，1.不核算',
  `subject_fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目全名',
  `end_exchange` int(10) NULL DEFAULT NULL COMMENT '期末调汇,1.是，2.否',
  `trans_account` int(10) NULL DEFAULT NULL COMMENT '往来业务核算,1.是，2.否',
  `countmone_account` int(10) NULL DEFAULT NULL COMMENT '数量金额辅助核算',
  `account_status` int(10) NULL DEFAULT NULL COMMENT '辅助核算，0否，是1',
  `subject_type` int(10) NULL DEFAULT NULL COMMENT '科目类型1.资产，2.负债，3.共同，4.权益，5.成本，6.损益',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_subject
-- ----------------------------
INSERT INTO `t_subject` VALUES ('35d3b5803269495c838c7000dbb2dde1', '1001', '库存现金', 1, '0', NULL, NULL, NULL, '', '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '库存现金', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('2c1572191af543f5831390e76fe77438', '1012', '其他货币资金', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '其他货币资金', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('f1bb7ff45d844ab5b21151898ffa2da4', '1002', '银行存款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '银行存款', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e7e8a03b4f8445d4b68f81bb6dbb898a', '1101', '交易性金融资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '交易性金融资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('053550833d724efcbd69d6be6432a8b5', '1111', '买入返售金融资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '买入返售金融资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e775023152184671b8aa1e0698c7e7a0', '1121', '应收票据', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应收票据', NULL, NULL, NULL, 1, 1);
INSERT INTO `t_subject` VALUES ('3e7da01ee9f04e59902733e02e6c7987', '1122', '应收账款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应收账款', NULL, NULL, NULL, 1, 1);
INSERT INTO `t_subject` VALUES ('a34714bb926447118faec80f6da4987a', '1123', '预付账款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '预付账款', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('fd5e1c92c60348488cca8a2cea880bd6', '1131', '应收股利', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应收股利', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('3b518de12eb34b3e93af8540f72344fa', '1132', '应收利息', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应收利息', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('462df2ba2efa4f27b50d4bfb48581d5c', '2001', '短期借款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '短期借款', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('4aed1cbc059941f0ad61bc13a7ef0b70', '4001', '资本公积', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '资本公积', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('bf23d55550184dbc85cea8bcfc2671cf', '5001', '生产成本', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '生产成本', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('884e3ea3416f4191aedc388973096a45', '6051', '其他业务收入', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '其他业务收入', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('436760733c0d41fd8b76a5f7f3a1a85d', '6001', '主营业务收入', 1, '0', NULL, NULL, NULL, NULL, '032dbc6fa8f244eeaca19f786ae92063', '营业收入', 2, NULL, '主营业务收入', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('94b2f8379ccf4cc3802e9c6fdc000172', '1212', '应收分保合同准备金', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应收分保合同准备金', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('7bc8b5cb3b20414687822ae182286fb0', '1221', '其他应收款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '其他应收款', NULL, NULL, NULL, 1, 1);
INSERT INTO `t_subject` VALUES ('295b0da4b6384e68ac104d514f4cff05', '1231', '坏账准备', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '坏账准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('85b1e7dd76fc41889048674c0a6dfd8d', '1302', '拆出资金', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '拆出资金', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e5ec3ed34ff54fc4a95ba1bdb8affe06', '1321', '代理业务资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '代理业务资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('55d0ac4146ac437693f19a2e3a574eca', '1401', '材料采购', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '材料采购', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('9fbd271661384021ab294c9d0ccc86d0', '1402', '在途物资', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '在途物资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('7f4c5c507fea4f518e9e6b8d50fb0abe', '1403', '原材料', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '原材料', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('8c99d0bfb08643f9b596108a4673e1cd', '1404', '材料成本差异', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '材料成本差异', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('11df6f19298a4d82824b73b7718f4439', '1405', '库存商品', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '库存商品', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('c23686d574504ca8bd53127f95b4349e', '1406', '发出商品', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '发出商品', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('7749dd82de6d42b89a0088be734e01fc', '1407', '商品进销差价', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '商品进销差价', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('ed7d33bb064a41ea8ac6f39785a533af', '1408', '委托加工物资', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '委托加工物资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('13fbeff781a442abb25fb39db9ef36fb', '1411', '周转材料', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '周转材料', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('34729739b62e48b7a5880fa9e031ab38', '1421', '消耗性生物资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '消耗性生物资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('333b241d8b11467fb057b5f2ff724778', '1431', '贵金属', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '贵金属', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('69a2fcdeeb2040c291b429bb4138c5b7', '1471', '存货跌价准备', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '存货跌价准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('7d6a3f461230454ca4809e5a962c1579', '1481', '持有待售资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '持有待售资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('c01cdfd54e934036b7d4134db1516d27', '1482', '持有待售资产减值准备', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '持有待售资产减值准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('41759bd102f64b289a2277b0483ef309', '1483', '待摊费用', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '待摊费用', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('46607ab6ee064517803ac0f6e518e090', '1501', '持有至到期投资', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '持有至到期投资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('94cfd1967aa54d0facb1e881ffd9165c', '1502', '持有至到期投资减值准备', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '持有至到期投资减值准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('36b40b93f3a240c1958a4a45b3971f91', '1503', '可供出售金融资产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '可供出售金融资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('cb9fb1d5d4c647639fda359c9384a257', '1504', '其他权益工具投资', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '其他权益工具投资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('fde0d863e836461cb636cdea912fb139', '1511', '长期股权投资', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '长期股权投资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e4c46e238c4743ceb5b38855dda7aef7', '1512', '长期股权投资减值准备', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 2, NULL, '长期股权投资减值准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('c1de6048be924b43ad71c1c8062765a9', '1521', '投资性房地产', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '投资性房地产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('dbaefa58749847619f7b23ca0dc04a9d', '1531', '长期应收款', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '长期应收款', NULL, NULL, NULL, 1, 1);
INSERT INTO `t_subject` VALUES ('e6e02f94f9f1435b89f1a87277be0dcf', '1532', '未实现融资收益', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '未实现融资收益', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('15bd7370424d4c92bc57a4b5c61a6894', '1541', '存出资本保证金', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '存出资本保证金', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('79aca92b47be422998f9b825c70b6920', '1601', '固定资产', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '固定资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e70278513d6b445fb040e43ad480cfda', '1602', '累计折旧', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 2, NULL, '累计折旧', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('d512ee465e73494d9fe9fad1d7d0741d', '1603', '固定资产减值准备', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 2, NULL, '固定资产减值准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('ab0ec95e2bac499ab597c1011cae1dd4', '1604', '在建工程', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '在建工程', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('658b889fdc9a4a7b8d72d256ac4acd59', '1605', '工程物资', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '工程物资', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('eef2f33c66be419daedf586056c4b887', '1606', '固定资产清理', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '固定资产清理', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('4cf871acc3804ed2b4d15532bdf8a9d4', '1701', '无形资产', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '无形资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('e4048ceca484490f980d473e553adcc3', '1702', '累计摊销', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 2, NULL, '累计摊销', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('f60c9d3c0a464b98bb0e3f035ca8835b', '1703', '无形资产减值准备', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 2, NULL, '无形资产减值准备', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('cc1d3de228834735878f207c4b15afcc', '1711', '商誉', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '商誉', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('34e97d3042434388aa9c52c28cff6c59', '1801', '长期待摊费用', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '长期待摊费用', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('647509c39b0a484889815740a1672c03', '1811', '递延所得税资产', 1, '0', NULL, NULL, NULL, NULL, 'ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产', 1, NULL, '递延所得税资产', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('40600a7bc86145ada843a031da4d6eed', '1901', '待处理财产损溢', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '待处理财产损溢', NULL, NULL, NULL, 0, 1);
INSERT INTO `t_subject` VALUES ('6fe34031e850493d8148e9c69bb545e2', '2101', '交易性金融负债', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '交易性金融负债', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('5c340a37619143f8a5814d955276c2d7', '2191', '预提费用', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '预提费用', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('c339e0d99bdb41adb1b89be60de404ff', '2201', '应付票据', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '应付票据', NULL, NULL, NULL, 2, 2);
INSERT INTO `t_subject` VALUES ('eb859116f527448290ac51a8a1ac3801', '2202', '应付账款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '应付账款', NULL, NULL, NULL, 2, 2);
INSERT INTO `t_subject` VALUES ('1246fcc023c747ac84765454f16bd7d4', '2203', '预收账款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '预收账款', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('63dd24bc581f4d31a434f8da18a5d986', '2211', '应付职工薪酬', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应付职工薪酬', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('d03370b6b304402eb31327c7050b4c5a', '2221', '应交税费', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '应交税费', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('73ba0ece3e564ab8a90f8cd49655bcbc', '2221.01', '应交增值税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '应交增值税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('0ecce3dad4a44c2daed45b7150592938', '2221.01.01', '进项税额', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '进项税额', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('7414fd56f60d49a19aaa8e80e7cf67c3', '2221.01.02', '销项税额', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '销项税额', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('0ffed834283d483796c341eba303afc5', '2221.01.03', '转出未交增值税', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '转出未交增值税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('beb94888f2d44ea5a9c0bb68b155f05b', '2221.01.04', '减免税款', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '减免税款', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('b21e1e8c6251425893bd303982034c7a', '2221.01.05', '进项税额转出', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '进项税额转出', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('f08a8ac6215c4f5fbcbfbf4d29f08b83', '2221.01.06', '出口退税', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '出口退税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('76a174b3b80f49cea47bb03895ead2c8', '2221.01.07', '出口抵减内销产品应纳税额', -1, '73ba0ece3e564ab8a90f8cd49655bcbc', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '出口抵减内销产品应纳税额', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('1758cafec1b9489d8de2be5b4a42382b', '2221.02', '未交增值税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '未交增值税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('423268e98c384c2a878822489ebfb096', '2221.03', '企业所得税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '企业所得税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('b213dd2598704723b76e2547ee32d743', '2221.04', '城市建设维护税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '城市建设维护税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('e04624975a2a480cadc613191df238fe', '2221.05', '教育费附加', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '教育费附加', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('ad0c1ae44ab6429c91b67d2bb440127f', '2221.06', '地方教育费附加', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '地方教育费附加', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('4c4dac9d42144bc0930b9a694195f211', '2221.07', '水利建设基金', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '水利建设基金', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('20ad69f747014a7e9c989a319f6a2efa', '2221.08', '房产税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '房产税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('52216cc0b550447db4d6cc9e48e5cb53', '2221.09', '土地使用税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '土地使用税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('b2c5d740e7d44abcb44ed211f0f5c656', '2221.10', '印花税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '印花税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('0293bfa9092047febb04397414a5b571', '2221.11', '代扣个人所得税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '代扣个人所得税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('8af4ba5141e74734bf31a5594b1b5fd9', '2221.12', '环保税', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '环保税', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('5bc9cfda1b63406398ca13a104808366', '2221.13', '待认证进项税额', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '待认证进项税额', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('9230caa6dabe49688c5a8bf476eea2e0', '2221.14', '代扣代缴增值税及附加', 0, 'd03370b6b304402eb31327c7050b4c5a', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '代扣代缴增值税及附加', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('35a2668a096d41518609a282204e1914', '2231', '应付利息', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '应付利息', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('67c2f6497efe4d4cbe5eab94f205e1b0', '2232', '应付股利', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '应付股利', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('585f6455d44b41588d6e3307d1d33c88', '2241', '其他应付款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '其他应付款', NULL, NULL, NULL, 2, 2);
INSERT INTO `t_subject` VALUES ('486f613b494347278165fc0e10d9cfd8', '2245', '持有待售负债', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '持有待售负债', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('1cf625fec4a44e749dca0f81ee23b3a1', '2314', '代理业务负债', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '代理业务负债', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('f0559467c3354f3d9876f3c83d338c63', '2401', '递延收益', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '递延收益', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('63bb6a0618a94af78e218a99a9ba9d50', '2501', '长期借款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '长期借款', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('f66714ea379443a1a3f372d54b79417a', '2502', '长期债券', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '长期债券', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('3c16572374304850920411a65323624b', '2701', '长期应付款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '长期应付款', NULL, NULL, NULL, 2, 2);
INSERT INTO `t_subject` VALUES ('bd2312de5d394cb29db7b1274f165fb0', '2702', '未确认融资费用', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 1, NULL, '未确认融资费用', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('5e082b2f411c409eabdb193160d73c83', '2711', '专项应付款', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '专项应付款', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('105a77337c04401e85c2e23497c6dcd2', '2801', '预计负债', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '预计负债', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('d88fed8ee8d24441889bc51e6aab21c8', '2901', '递延所得税负债', 1, '0', NULL, NULL, NULL, NULL, '2085a9de71f84cf5a07b860aaa4ce261', '流动资产', 2, NULL, '递延所得税负债', NULL, NULL, NULL, 0, 2);
INSERT INTO `t_subject` VALUES ('62712500e20040799829cb5f3d5659f8', '3101', '衍生工具', 1, '0', NULL, NULL, NULL, NULL, 'bc2dcebee7ca4982b620224d77d3074a', '共同', 1, NULL, '衍生工具', NULL, NULL, NULL, 0, 3);
INSERT INTO `t_subject` VALUES ('cbe2ab64351f4819bffab722ba927889', '3201', '套期工具', 1, '0', NULL, NULL, NULL, NULL, 'bc2dcebee7ca4982b620224d77d3074a', '共同', 1, NULL, '套期工具', NULL, NULL, NULL, 0, 3);
INSERT INTO `t_subject` VALUES ('cd4989d9a9d442df8e045f26e5537822', '3202', '被套期项目', 1, '0', NULL, NULL, NULL, NULL, 'bc2dcebee7ca4982b620224d77d3074a', '共同', 1, NULL, '被套期项目', NULL, NULL, NULL, 0, 3);
INSERT INTO `t_subject` VALUES ('17c32c7f44744e79ad13b9dc900c1d3c', '4001', '实收资本', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '实收资本', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('9c6efc976e264b5eafb8e2464e5e276a', '4003', '其他综合收益', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '其他综合收益', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('714bbd2712da4b028dd02b1adef13239', '4101', '盈余公积', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '盈余公积', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('4752db5fe15d47e0b07df7a8205b2d1d', '4101.01', '法定盈余公积金', 0, '714bbd2712da4b028dd02b1adef13239', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '法定盈余公积金', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('f6ec4ab3b8704566a4f9f4e4b88011ba', '4101.02', '任意盈余公积金', 0, '714bbd2712da4b028dd02b1adef13239', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '任意盈余公积金', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('729971d18f864e3c8f361df6fb0e5331', '4103', '本年利润', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '本年利润', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('4a886766f7384d1dbe444092b3c00ee7', '4104', '利润分配', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '利润分配', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('947af1008afc45a885243e9c5e2bd373', '4104.02', '提取法定盈余公积金', 0, '4a886766f7384d1dbe444092b3c00ee7', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '提取法定盈余公积金', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('775226b82dd04ad6a0f4e9e3e4bfe995', '4104.01', '未分配利润', 0, '4a886766f7384d1dbe444092b3c00ee7', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '未分配利润', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('e2f6e2d19cc74ad99bce83a3bd677c06', '4104.03', '提取任意盈余公积金', 0, '4a886766f7384d1dbe444092b3c00ee7', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '提取任意盈余公积金', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('335e7fcd58cc43d3b282300aadf9131c', '4201', '库存股', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '库存股', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('3ad71311f0b8478e9dab302f093fe923', '4401', '其他权益工具', 1, '0', NULL, NULL, NULL, NULL, '16a8f0473408413cb49cfd4a6cc25f55', '所有者权益', 2, NULL, '其他权益工具', NULL, NULL, NULL, 0, 4);
INSERT INTO `t_subject` VALUES ('acf468083046401382d0935509e381a7', '6101', '公允价值变动损益', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '公允价值变动损益', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('a810da31cbc94946bdf3b70cfa6776bc', '6111', '投资收益', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '投资收益', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('c29f6dbfdfb14949a3a6ec1f2e546ca4', '6115', '资产处置损益', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '资产处置损益', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('89a6563029b04b4b9576e9f4f5f8a4e1', '6117', '其他收益', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '其他收益', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('f94a1d0909fc4ab99b536dd30c3cecdb', '6301', '营业外收入', 1, '0', NULL, NULL, NULL, NULL, '144bf578875649abb56a6f04accc1658', '其他收益', 2, NULL, '营业外收入', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('1a4f0c5451414b86b76f20fce99b33cb', '6401', '主营业务成本', 1, '0', NULL, NULL, NULL, NULL, 'c6d5e0c2ef7d4ba0bb1c36c0fea0f605', '营业成本及税金', 1, NULL, '主营业务成本', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('60ee2aff8f354edabca6a2f0743e5f1e', '6402', '其他业务成本', 1, '0', NULL, NULL, NULL, NULL, '12501b198f8f40a189e6b1b931ac12a4', '其他损失', 1, NULL, '其他业务成本', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('b7fc8390eee54a1cbf6fccd58ac1702b', '6403', '营业税金及附加', 1, '0', NULL, NULL, NULL, NULL, 'c6d5e0c2ef7d4ba0bb1c36c0fea0f605', '营业成本及税金', 1, NULL, '营业税金及附加', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('f709b935eb474912846a52a76fb4b06c', '6601', '销售费用', 1, '0', NULL, NULL, NULL, NULL, '1568f0d568234badaaaf2f61a575e8bb', '期间费用', 1, NULL, '销售费用', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('9ca1f7d12219468bac0b022249f58c07', '6602', '管理费用', 1, '0', NULL, NULL, NULL, NULL, '1568f0d568234badaaaf2f61a575e8bb', '期间费用', 1, NULL, '管理费用', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('0576e7e5f375416b8d2d9c15bafeee6c', '6603', '研发费用', 1, '0', NULL, NULL, NULL, NULL, '1568f0d568234badaaaf2f61a575e8bb', '期间费用', 1, NULL, '研发费用', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('2f03fcd0b43044b8b8599d2d712f07e0', '6604', '财务费用', 1, '0', NULL, NULL, NULL, NULL, '1568f0d568234badaaaf2f61a575e8bb', '期间费用', 1, NULL, '财务费用', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('bc2fa0c13a3f46bbb821b149376f0386', '6701', '资产减值损失', 1, '0', NULL, NULL, NULL, NULL, '12501b198f8f40a189e6b1b931ac12a4', '其他损失', 1, NULL, '资产减值损失', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('4ab5d91f9920469ea4534d63fd6a34c9', '6702', '信用减值损失', 1, '0', NULL, NULL, NULL, NULL, '12501b198f8f40a189e6b1b931ac12a4', '其他损失', 1, NULL, '信用减值损失', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('5a55679dee874e25a2d66f603967b572', '6711', '营业外支出', 1, '0', NULL, NULL, NULL, NULL, '12501b198f8f40a189e6b1b931ac12a4', '其他损失', 1, NULL, '营业外支出', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('95f71108003545af93b5fdfe9aaa4608', '6801', '所得税', 1, '0', NULL, NULL, NULL, NULL, 'c2b4de5af88e4a86a12cbbbd57cd17c6', '所得税', 1, NULL, '所得税', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('7c3f63f9395b4f2f91300b8b20628506', '6901', '以前年度损益调整', 1, '0', NULL, NULL, NULL, NULL, 'eaa20de2bd274076bdd9e4c0252160b4', '以前年度损益调整', 2, NULL, '以前年度损益调整', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('2a68ddae4d5049f285f9f6fb41e8bb88', '6902', '代扣代缴增值税及附加', 1, '0', NULL, NULL, NULL, NULL, 'c6d5e0c2ef7d4ba0bb1c36c0fea0f605', '营业成本及税金', 1, NULL, '代扣代缴增值税及附加', NULL, NULL, NULL, 0, 6);
INSERT INTO `t_subject` VALUES ('f2d26497b1694873ad096ec7951aa175', '5101', '制造费用', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '制造费用', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('999d69e60b8a42e7865c15b9d7179194', '5201', '劳务成本', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '劳务成本', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('973131394b2645f6b447ab424c18aeea', '5301', '研发支出', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '研发支出', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('97174df921934a03a8fce3033aaf1102', '5401', '工程施工', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '工程施工', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('e8843f19bd2247d39621fb1fe1b72173', '5402', '工程结算', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 2, NULL, '工程结算', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('aee02e0dbaf84ee78b4f318abcdd2e8c', '5403', '机械作业', 1, '0', NULL, NULL, NULL, NULL, '55cadb03541e4d6684fc60835a9a59bf', '成本', 1, NULL, '机械作业', NULL, NULL, NULL, 0, 5);
INSERT INTO `t_subject` VALUES ('e63f52c008fc4f52aec644ef03f8c4a7', NULL, '交通费', 0, '9ca1f7d12219468bac0b022249f58c07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6);

-- ----------------------------
-- Table structure for t_subjectcategory
-- ----------------------------
DROP TABLE IF EXISTS `t_subjectcategory`;
CREATE TABLE `t_subjectcategory`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cate_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_subjectcategory
-- ----------------------------
INSERT INTO `t_subjectcategory` VALUES ('2085a9de71f84cf5a07b860aaa4ce261', '流动资产');
INSERT INTO `t_subjectcategory` VALUES ('ad80308833564c4f8d34cc9c5f9cd56c', '非流动资产');
INSERT INTO `t_subjectcategory` VALUES ('0ce3cb4fc7c5432985a9d0db1b12b0a7', '流动负债');
INSERT INTO `t_subjectcategory` VALUES ('598ad6f0578e480686470ab9cd218f5b', '非流动负债');
INSERT INTO `t_subjectcategory` VALUES ('c6d5e0c2ef7d4ba0bb1c36c0fea0f605', '营业成本及税金');
INSERT INTO `t_subjectcategory` VALUES ('eaa20de2bd274076bdd9e4c0252160b4', '以前年度损益调整');
INSERT INTO `t_subjectcategory` VALUES ('c2b4de5af88e4a86a12cbbbd57cd17c6', '所得税');
INSERT INTO `t_subjectcategory` VALUES ('12501b198f8f40a189e6b1b931ac12a4', '其他损失');
INSERT INTO `t_subjectcategory` VALUES ('1568f0d568234badaaaf2f61a575e8bb', '期间费用');
INSERT INTO `t_subjectcategory` VALUES ('144bf578875649abb56a6f04accc1658', '其他收益');
INSERT INTO `t_subjectcategory` VALUES ('032dbc6fa8f244eeaca19f786ae92063', '营业收入');
INSERT INTO `t_subjectcategory` VALUES ('55cadb03541e4d6684fc60835a9a59bf', '成本');
INSERT INTO `t_subjectcategory` VALUES ('16a8f0473408413cb49cfd4a6cc25f55', '所有者权益');
INSERT INTO `t_subjectcategory` VALUES ('bc2dcebee7ca4982b620224d77d3074a', '共同');

-- ----------------------------
-- Table structure for t_supplier
-- ----------------------------
DROP TABLE IF EXISTS `t_supplier`;
CREATE TABLE `t_supplier`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `supplier_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_addr` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_bankcd` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_bank` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `supplier_status` int(11) NULL DEFAULT NULL,
  `supplier_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_supplier
-- ----------------------------
INSERT INTO `t_supplier` VALUES ('2ce66a6612e44e1d98979089615db6f4', '北京市东海智能设备有限公司', '202201270102', '李斌', '17653405826', '762966700@qq.com', '北京市东城区', '13200123778123', '北京市东城区工商银行', 1, '无');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dept_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('ba5e8ce2079742d5a1a2a7ec6b64561a', '吴杰', '15025899633', '695555941@qq.com', '695555941', '10867405c6e44da68d0367463ba688bf', 'wujie');
INSERT INTO `t_user` VALUES ('ca76d0542e1e41dcbb78bd8caedb7e9f', '管理员', '17653405826', '762966800@qq.com', 'c20ad4d76fe97759aa27a0c99bff6710', '03480ae838064579936d72bd06554d42', 'admin');

-- ----------------------------
-- Table structure for t_userauth
-- ----------------------------
DROP TABLE IF EXISTS `t_userauth`;
CREATE TABLE `t_userauth`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `role_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `role_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_userauth
-- ----------------------------
INSERT INTO `t_userauth` VALUES ('1c0576154fb14dfb818b09c536f58ccf', 'ca76d0542e1e41dcbb78bd8caedb7e9f', 'da25b71de17c493291b4e6008eb24f09', NULL);
INSERT INTO `t_userauth` VALUES ('bc5fa342c9d047b4a626d19c2f715799', 'd27bb91abc554ee89b5626c2f6b2b5f4', 'da25b71de17c493291b4e6008eb24f09', NULL);
INSERT INTO `t_userauth` VALUES ('bef1e5004c684022aef7097b5fe9bba8', 'ba5e8ce2079742d5a1a2a7ec6b64561a', 'cfbef9e51d72434c9f05449fc21fef32', NULL);
INSERT INTO `t_userauth` VALUES ('c10df72171674592b158daf4d6a3831a', '1', 'da25b71de17c493291b4e6008eb24f09', NULL);
INSERT INTO `t_userauth` VALUES ('d9eb17936826491cb499e5c7c9d4e314', 'd27bb91abc554ee89b5626c2f6b2b5f4', 'cfbef9e51d72434c9f05449fc21fef32', NULL);

-- ----------------------------
-- Table structure for t_userrole
-- ----------------------------
DROP TABLE IF EXISTS `t_userrole`;
CREATE TABLE `t_userrole`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `role_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `menu_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of t_userrole
-- ----------------------------
INSERT INTO `t_userrole` VALUES ('cf48a5a4c08748968070aca38765ddf3', 'da25b71de17c493291b4e6008eb24f09', NULL, 'f966ce7901cc4bd39227140cb9bd34ad', '51e0cad8680c486d9ed2180b5552c19e');
INSERT INTO `t_userrole` VALUES ('0e98b8e99b59433185d8764a76742576', 'da25b71de17c493291b4e6008eb24f09', NULL, '955dde43af764f0aa6ec5b1e6adc37d9', '51e0cad8680c486d9ed2180b5552c19e');
INSERT INTO `t_userrole` VALUES ('113dab7cdd234c0fad827cb947cb9f99', 'da25b71de17c493291b4e6008eb24f09', NULL, '5740142c46ca43da950d435b7f119935', '4c77bf46986d4e2fb78b2ffc14285e83');
INSERT INTO `t_userrole` VALUES ('66bb3f02b4d84aceac41d292ce31f62e', 'da25b71de17c493291b4e6008eb24f09', NULL, '51e0cad8680c486d9ed2180b5552c19e', '0');
INSERT INTO `t_userrole` VALUES ('375e6cba83344956b20529ef394cccfe', 'da25b71de17c493291b4e6008eb24f09', NULL, '4c77bf46986d4e2fb78b2ffc14285e83', '0');
INSERT INTO `t_userrole` VALUES ('6f95c46ba3284d0d8d2ccc03cd007ce0', 'da25b71de17c493291b4e6008eb24f09', NULL, '1e5ef781624f489c8dc525c358382301', '4c77bf46986d4e2fb78b2ffc14285e83');
INSERT INTO `t_userrole` VALUES ('a0874148c37d4a3b99c6025be58c45be', 'da25b71de17c493291b4e6008eb24f09', NULL, '4ca56f8392454a52bf346d33a63370b2', '4c77bf46986d4e2fb78b2ffc14285e83');
INSERT INTO `t_userrole` VALUES ('5ac7f39301674515bc12a588e72b1f0c', 'cfbef9e51d72434c9f05449fc21fef32', NULL, '6', '3');
INSERT INTO `t_userrole` VALUES ('7aac41ebce7a435ea6a77d40bb78ad02', 'cfbef9e51d72434c9f05449fc21fef32', NULL, '3', '0');
INSERT INTO `t_userrole` VALUES ('3b52d5ccc9ab49fe88625b7a62d52e37', 'da25b71de17c493291b4e6008eb24f09', NULL, 'e882cb0116b84f70ab9b14a579c67c08', '51e0cad8680c486d9ed2180b5552c19e');
INSERT INTO `t_userrole` VALUES ('8e393cde35ec421783300f2d64027665', 'da25b71de17c493291b4e6008eb24f09', NULL, '86901e40d0264bbd9e7fc2d04a53e047', '256f43f1c2c04906804e69ed038414f2');
INSERT INTO `t_userrole` VALUES ('a12f15ded70745409299f388efa74a00', 'da25b71de17c493291b4e6008eb24f09', NULL, 'ca087c86d930436ca27ad878f3595fd4', '256f43f1c2c04906804e69ed038414f2');
INSERT INTO `t_userrole` VALUES ('d0ebfd996cb946d79b9aff453247569a', 'da25b71de17c493291b4e6008eb24f09', NULL, '256f43f1c2c04906804e69ed038414f2', '0');
INSERT INTO `t_userrole` VALUES ('15b65e50600b4c18bdd577c3b802061e', 'da25b71de17c493291b4e6008eb24f09', NULL, '8f9f07ea3cd94e97b625af6f2de16348', '256f43f1c2c04906804e69ed038414f2');
INSERT INTO `t_userrole` VALUES ('d9512809eb17415fafac083ab1ce6803', 'da25b71de17c493291b4e6008eb24f09', NULL, '493f3f97018d444b85e7528b9f90a166', '1b39e9abdd2f4d6895ca53a74b42cace');
INSERT INTO `t_userrole` VALUES ('2767b7d17bce4fe88bfc68e230472779', 'da25b71de17c493291b4e6008eb24f09', NULL, 'e5d8a900b55048949016f12ac0c2e47a', '1b39e9abdd2f4d6895ca53a74b42cace');
INSERT INTO `t_userrole` VALUES ('cea266f6fdbb40d6a7a9ef7d284cfe79', 'cfbef9e51d72434c9f05449fc21fef32', NULL, '5', '3');
INSERT INTO `t_userrole` VALUES ('ca7ab6b9c0484387809c0e4008284f05', 'da25b71de17c493291b4e6008eb24f09', NULL, '1b39e9abdd2f4d6895ca53a74b42cace', '0');
INSERT INTO `t_userrole` VALUES ('9f00aec0d26d4734995505667b226d28', 'da25b71de17c493291b4e6008eb24f09', NULL, '3c067d7ae917423c8d05491878e8f73c', '79e0a283253e4d688ee91a2c6069fa82');
INSERT INTO `t_userrole` VALUES ('b56ae514566245e5ae2a6fd7189c15d8', 'da25b71de17c493291b4e6008eb24f09', NULL, 'b8112a64842948f7a08b42d4c754f168', '303433fd75224bb58eba49c8d5afec8f');
INSERT INTO `t_userrole` VALUES ('f1cb9b4c120b43df9330f6d04f202b89', 'cfbef9e51d72434c9f05449fc21fef32', NULL, '4', '3');
INSERT INTO `t_userrole` VALUES ('ad93ac6f3dd24e63b8603a27b4c5f0e8', 'da25b71de17c493291b4e6008eb24f09', NULL, '79e0a283253e4d688ee91a2c6069fa82', '0');
INSERT INTO `t_userrole` VALUES ('2160e9bc75544b21ab83ecccf2bdb1e7', 'da25b71de17c493291b4e6008eb24f09', NULL, '29a1fdf884dd4342b6018d28753f4748', '303433fd75224bb58eba49c8d5afec8f');
INSERT INTO `t_userrole` VALUES ('43b8db9dd0b04221b141ddcfb5b93b1a', 'da25b71de17c493291b4e6008eb24f09', NULL, 'b2c9dfe5a4fb4b928f9460369b75738c', '303433fd75224bb58eba49c8d5afec8f');
INSERT INTO `t_userrole` VALUES ('4e86fc96e1a5478d88fa130c92c77332', 'da25b71de17c493291b4e6008eb24f09', NULL, '6', '3');
INSERT INTO `t_userrole` VALUES ('e4e88c16e8a541f1bf23419aff94c618', 'da25b71de17c493291b4e6008eb24f09', NULL, '303433fd75224bb58eba49c8d5afec8f', '0');
INSERT INTO `t_userrole` VALUES ('5922fd9860934ceca3cb3a023aa6c932', 'da25b71de17c493291b4e6008eb24f09', NULL, '3', '0');
INSERT INTO `t_userrole` VALUES ('53a864225a684e6a9df49b475e003097', 'da25b71de17c493291b4e6008eb24f09', NULL, '4', '3');
INSERT INTO `t_userrole` VALUES ('410e356450364a48a682ffdebf7a2fcc', 'da25b71de17c493291b4e6008eb24f09', NULL, '5', '3');

-- ----------------------------
-- Table structure for t_voucher
-- ----------------------------
DROP TABLE IF EXISTS `t_voucher`;
CREATE TABLE `t_voucher`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `voucher_time` datetime NULL DEFAULT NULL COMMENT '期间',
  `voucher_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '制单人',
  `voucher_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '凭证号',
  `voucher_status` int(255) NULL DEFAULT NULL COMMENT '审核状态，0未审核，1.审核',
  `accounts_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '账套id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_voucher
-- ----------------------------
INSERT INTO `t_voucher` VALUES ('3acfdbfafd8b4840b7a0b17e67acff2b', '2022-03-20 14:51:56', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220320334', 2, 'f530b4bb5c7f4bc78641fe57408ae3e2');
INSERT INTO `t_voucher` VALUES ('e46ddd64a6bc40a4a33683b38fe592b4', '2022-03-19 14:53:37', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220319000334', 2, 'f530b4bb5c7f4bc78641fe57408ae3e2');
INSERT INTO `t_voucher` VALUES ('d43148afa3c64a04b616c6fa9a75c690', '2022-03-01 11:38:44', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220301000336', 1, 'f530b4bb5c7f4bc78641fe57408ae3e2');
INSERT INTO `t_voucher` VALUES ('c224e3175f4c4700b7fda406ac10340d', '2022-03-01 11:38:40', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220301000336', 1, 'f530b4bb5c7f4bc78641fe57408ae3e2');
INSERT INTO `t_voucher` VALUES ('0c0f40860b9943b59aa1186fd9200250', '2022-03-25 08:09:35', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220325000333', 1, 'f530b4bb5c7f4bc78641fe57408ae3e2');
INSERT INTO `t_voucher` VALUES ('7c0f7b9413204401aaf01f1a9e08229a', '2022-03-02 11:40:02', 'ca76d0542e1e41dcbb78bd8caedb7e9f', '凭-20220302000336', 1, 'f530b4bb5c7f4bc78641fe57408ae3e2');

-- ----------------------------
-- Table structure for t_voucherdetail
-- ----------------------------
DROP TABLE IF EXISTS `t_voucherdetail`;
CREATE TABLE `t_voucherdetail`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `voucher_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '凭证头id',
  `summary_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '摘要',
  `subject_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目id',
  `subject_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '科目名称',
  `currentsubject_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '当前科目id',
  `currentsubject_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '当前科目名称',
  `debit_money` decimal(10, 2) NULL DEFAULT NULL COMMENT '借方金额',
  `lender_money` decimal(10, 2) NULL DEFAULT NULL COMMENT '贷方金额',
  `insert_time` datetime NULL DEFAULT NULL COMMENT '新增时间',
  `current_money` decimal(10, 2) NULL DEFAULT NULL COMMENT '当前期末余额',
  `start_money` decimal(10, 2) NULL DEFAULT NULL COMMENT '当前期初余额',
  `customer_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '客户id',
  `supplier_id` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '供应商id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_voucherdetail
-- ----------------------------
INSERT INTO `t_voucherdetail` VALUES ('a283a6f5eb434bb39dfef328b67c0a17', '3acfdbfafd8b4840b7a0b17e67acff2b', '111', 'eb859116f527448290ac51a8a1ac3801', '应付账款', 'eb859116f527448290ac51a8a1ac3801', NULL, 1000.00, 0.00, '2022-03-20 14:51:54', -1000.00, 0.00, '', '2ce66a6612e44e1d98979089615db6f4');
INSERT INTO `t_voucherdetail` VALUES ('fff2f76b9e5b404f8bf8e8e3556bf6b6', 'e46ddd64a6bc40a4a33683b38fe592b4', '11', '2c1572191af543f5831390e76fe77438', '其他货币资金', '2c1572191af543f5831390e76fe77438', NULL, 0.00, 1000.00, '2022-03-20 14:53:35', 1000.00, 2000.00, '', '');
INSERT INTO `t_voucherdetail` VALUES ('044005826ffe45d781d398fc91215812', 'cb8fcc737e234cfa8d29a4ed522d014c', '存款', '35d3b5803269495c838c7000dbb2dde1', '库存现金', '35d3b5803269495c838c7000dbb2dde1', NULL, 4000.00, 0.00, '2022-03-23 16:10:50', 4000.00, 0.00, '', '');
INSERT INTO `t_voucherdetail` VALUES ('5aeb8bebde6444b4897686dc92b17187', '67971418f27f4f328d45417584015dad', '材料', 'bf23d55550184dbc85cea8bcfc2671cf', '生产成本', 'bf23d55550184dbc85cea8bcfc2671cf', NULL, 5000.00, 0.00, '2022-03-23 16:35:58', 5000.00, 0.00, '', '');
INSERT INTO `t_voucherdetail` VALUES ('ea23d088e2ca49bca2e06f237460033a', '7c0f7b9413204401aaf01f1a9e08229a', '交通费', '35d3b5803269495c838c7000dbb2dde1', '库存现金', '35d3b5803269495c838c7000dbb2dde1', NULL, 0.00, 200.00, '2022-03-25 11:39:26', 3800.00, 4000.00, '', '');
INSERT INTO `t_voucherdetail` VALUES ('aa1c0247ea2f4a2094f546059c22e09f', '7c0f7b9413204401aaf01f1a9e08229a', '交通费', '9ca1f7d12219468bac0b022249f58c07', '管理费用', '9ca1f7d12219468bac0b022249f58c07', NULL, 200.00, 0.00, '2022-03-25 11:39:26', 200.00, 0.00, '', '');

SET FOREIGN_KEY_CHECKS = 1;
