package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.entity.User;
import com.data.financeapi.entity.UserRole;
import com.data.financeapi.mapper.SubjectCategoryMapper;
import com.data.financeapi.mapper.UserMapper;
import com.data.financeapi.service.SubjectCategoryService;
import com.data.financeapi.service.UserService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.UserVo;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class SubjectCategoryServiceImpl extends ServiceImpl<SubjectCategoryMapper, SubjectCategory> implements SubjectCategoryService {
    @Override
    public Boolean addSubjectCategory(SubjectCategoryQryDto qry) {
        SubjectCategory subjectCategory = new SubjectCategory(qry);
        subjectCategory.setId(UUIDUtil.uuid());
        return baseMapper.insert(subjectCategory) > 0;
    }

    @Override
    public Boolean updateSubjectCategory(SubjectCategoryQryDto qry) {
        SubjectCategory subjectCategory = new SubjectCategory(qry);
        return baseMapper.updateById(subjectCategory) > 0;
    }

    @Override
    public Boolean delSubjectCategoryById(String Id) {
        SubjectCategory subjectCategory = new SubjectCategory();
        subjectCategory.setId(Id);
        return baseMapper.delete(new QueryWrapper<>(subjectCategory)) > 0;
    }

    public IPage<SubjectCategoryVo> qrySubjectCategoryListPage(Page<SubjectCategory> page, SubjectCategoryQryDto qry) {

        return baseMapper.qrySubjectCategoryListPage(page, qry);
    }
}
