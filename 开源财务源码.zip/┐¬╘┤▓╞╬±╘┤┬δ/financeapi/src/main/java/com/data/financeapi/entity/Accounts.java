package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_accounts")
public class Accounts implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "accounts_name")
    private String AccountsName;

    @TableField(value = "accounts_system")
    private String AccountsSystem;

    @TableField(value = "set_time")
    private String SetTime;

    @TableField(value = "insert_time")
    private String InsertTime;

    @TableField(value = "update_time")
    private String UpdateTime;

    @TableField(value = "accounts_status")
    private Integer AccountsStatus;

    public Accounts() {

    }
    public Accounts(AccountsQryDto accountsQryDto) {
        BeanUtils.copyProperties(accountsQryDto, this);
    }

}