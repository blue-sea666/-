package com.data.financeapi.vo;

import lombok.Data;

@Data
public class SubjectCategoryVo {

    private String Id;

    private String CateName;
}