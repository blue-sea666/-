package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.entity.User;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.UserVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface SubjectCategoryService extends IService<SubjectCategory> {
    Boolean addSubjectCategory(SubjectCategoryQryDto qry);

    Boolean updateSubjectCategory(SubjectCategoryQryDto qry);

    Boolean delSubjectCategoryById(String Id);

    IPage<SubjectCategoryVo> qrySubjectCategoryListPage(Page<SubjectCategory> page, SubjectCategoryQryDto subjectCategoryQryDto);

}
