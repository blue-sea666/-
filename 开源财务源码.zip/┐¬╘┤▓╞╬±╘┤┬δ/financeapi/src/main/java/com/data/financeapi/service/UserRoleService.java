package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.UserRoleQryDto;
import com.data.financeapi.entity.UserRole;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserRoleService extends IService<UserRole> {

    Boolean addUserRole(UserRoleQryDto qry);

    Boolean updateUserRole(UserRoleQryDto qry);

    Boolean delUserRoleById(String menuroleId);

    Boolean delUserRole(String roleId);

    List<UserRole> qryUserRoleList(UserRoleQryDto userQryDto);

    IPage<UserRole> qryUserRoleListPage(long current, long size, UserRoleQryDto userQryDto);

    Boolean saveUserRoleArray(List<UserRoleQryDto> userRoleQryDto) throws Exception;
}
