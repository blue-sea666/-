package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.RoleQryDto;
import com.data.financeapi.entity.Role;
import com.data.financeapi.service.RoleService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.RoleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/role")
@CrossOrigin //解决跨域问题
public class RoleController {
    @Autowired
    RoleService roleService;
    @PostMapping("/findRole")
    public Result findRole(@RequestBody RoleQryDto qry) {

        try {
            Page<Role> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<RoleVo> list=roleService.qryRoleListPage(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/updateRole")
    public R updateRole(@RequestBody RoleQryDto qry){
        try{
            roleService.updateRole(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/addRole")
    public R addRole(@RequestBody RoleQryDto qry){
        try{
            roleService.addRole(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/deleteRole")
    public R deleteRole(@RequestBody RoleQryDto qry){
        try{
            String roleid=qry.getId();
            roleService.delRoleById(roleid);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

