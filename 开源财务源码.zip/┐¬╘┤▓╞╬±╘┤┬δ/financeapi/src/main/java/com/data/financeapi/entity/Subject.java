package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.dto.UserQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_subject")
public class Subject implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "subject_code")
    private String SubjectCode;

    @TableField(value = "subject_name")
    private String SubjectName;

    @TableField(value = "subject_level")
    private Integer SubjectLevel;

    @TableField(value = "pid")
    private String Pid;

    @TableField(value = "insert_time")
    private String InsertTime;

    @TableField(value = "update_time")
    private String UpdateTime;

    @TableField(value = "isdel")
    private Integer isDel;

    @TableField(value = "mnemonic_code")
    private String MnemonicCode;

    @TableField(value = "subject_category")
    private String SubjectCategory;

    @TableField(value = "subject_categoryname")
    private String SubjectCategoryName;

    @TableField(value = "balance_direction")
    private Integer BalanceDirection;

    @TableField(value = "foreign_account")
    private Integer ForeignAccount;

    @TableField(value = "end_exchange")
    private Integer EndExchange;

    @TableField(value = "trans_account")
    private Integer TransAccount;

    @TableField(value = "countmone_account")
    private Integer CountmoneAccount;

    @TableField(value = "subject_fullname")
    private String SubjectFullname;

    @TableField(value = "account_status")
    private Integer AccountStatus;

    @TableField(value = "subject_type")
    private Integer SubjectType;

    public Subject() {

    }
    public Subject(SubjectQryDto subjectQryDto) {
        BeanUtils.copyProperties(subjectQryDto, this);
    }

}