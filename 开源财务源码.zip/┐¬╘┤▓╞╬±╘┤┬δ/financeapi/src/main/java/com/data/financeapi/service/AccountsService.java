package com.data.financeapi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.vo.AccountsVo;
import com.data.financeapi.vo.SubjectVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface AccountsService extends IService<Accounts> {
    String addAccounts(AccountsQryDto qry);

    Boolean updateAccounts(AccountsQryDto qry);

    Boolean delAccountsById(String accountsId);

    List<AccountsVo> qryAccountsList(AccountsQryDto qry);

}
