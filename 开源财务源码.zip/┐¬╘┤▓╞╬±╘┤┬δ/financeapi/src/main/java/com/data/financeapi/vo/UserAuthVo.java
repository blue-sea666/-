package com.data.financeapi.vo;

import lombok.Data;

@Data
public class UserAuthVo {

    private String Id;

    private String RoleName;
}