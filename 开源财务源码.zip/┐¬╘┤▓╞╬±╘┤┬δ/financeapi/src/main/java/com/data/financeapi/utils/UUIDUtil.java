package com.data.financeapi.utils;

import java.util.UUID;

/**
 * Created by cys on 2017/11/11
 * <p>
 * 唯一id生成类
 */
public class UUIDUtil {

    public static String uuid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
