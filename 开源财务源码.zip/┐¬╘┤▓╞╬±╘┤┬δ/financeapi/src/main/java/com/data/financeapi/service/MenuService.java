package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.entity.Menu;
import com.data.financeapi.vo.MenuVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface MenuService extends IService<Menu> {
    Boolean addMenu(MenuQryDto qry);

    Boolean updateMenu(MenuQryDto qry);

    Boolean delMenuById(String menuId);

    List<Menu> qryMenu(MenuQryDto menuQryDto);

    List<MenuVo> qryMenuById(MenuQryDto menuQryDto) throws Exception;

    IPage<Menu> qryMenuPage(int current, int size,MenuQryDto menuQryDto) throws Exception;

    List<MenuVo> qryMenuList(MenuQryDto menuQryDto);
}
