package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.User;
import com.data.financeapi.service.UserService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/user")
@CrossOrigin //解决跨域问题
public class UserController {
    @Autowired
    UserService userService;
    @PostMapping("/findUser")
    public Result findUser(@RequestBody UserQryDto qry) {

        try {
            Page<User> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<UserVo> list=userService.qryUserListPage(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }
    @PostMapping("/getUser")
    public R getUser(@RequestBody UserQryDto qry) {

        try {
            List<UserVo> list=userService.qryUserList(qry);
            return R.ok().data("records", list).data("total", list.size());
        } catch (Exception e) {
            return R.error();
        }
    }
    @PostMapping("/findUserById")
    public Result findUserById(@RequestBody UserQryDto qry) {

        try {
            Page<User> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<UserVo> list=userService.qryUserPageByid(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/update")
    public R updateUser(@RequestBody UserQryDto qry){
        try{
            userService.updateUser(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addUser(@RequestBody UserQryDto qry){
        try{
            userService.addUser(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody UserQryDto user){
        try{
            userService.delUserById(user.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

