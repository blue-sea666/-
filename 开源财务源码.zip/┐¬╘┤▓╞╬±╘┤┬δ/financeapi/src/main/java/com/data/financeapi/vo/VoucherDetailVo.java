package com.data.financeapi.vo;

import com.data.financeapi.dto.VoucherDetailQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class VoucherDetailVo {

    private String id;

    private String VoucherId;

    private String SummaryName;

    private String SubjectId;

    private String SubjectName;

    private double DebitMoney;

    private double LenderMoney;

    private String InsertTime;

    private String VoucherTime;

    private String VoucherName;

    private String VoucherCode;

    private Integer VoucherStatus;

    private String AccountsId;

    public VoucherDetailVo() {

    }
    public VoucherDetailVo(VoucherDetailQryDto voucherDetailQryDto) {
        BeanUtils.copyProperties(voucherDetailQryDto, this);
    }

}