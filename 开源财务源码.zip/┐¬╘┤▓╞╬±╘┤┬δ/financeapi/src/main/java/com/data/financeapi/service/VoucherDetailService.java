package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.VoucherDetailQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.entity.VoucherDetail;
import com.data.financeapi.vo.VoucherDetailVo;
import com.data.financeapi.vo.VoucherVo;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface VoucherDetailService extends IService<VoucherDetail> {
    Boolean addVoucherDetail(VoucherDetailQryDto qry);

    Boolean updateVoucherDetail(VoucherDetailQryDto qry);

    Boolean delVoucherDetailById(String Id);

    IPage<VoucherDetailVo> qryVoucherDetailListPage(Page<VoucherDetail> page, VoucherDetailQryDto qry);

}
