package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.service.SubjectCategoryService;
import com.data.financeapi.service.VoucherService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.VoucherVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/voucher")
@CrossOrigin //解决跨域问题
public class VoucherController {
    @Autowired
    VoucherService voucherService;
    @PostMapping("/getVoucher")
    public Result getVoucher(@RequestBody VoucherQryDto qry) {

        try {
            Page<Voucher> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<VoucherVo> list=voucherService.qryVoucherListPage(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/update")
    public R updateVoucher(@RequestBody VoucherQryDto qry){
        try{
            voucherService.updateVoucher(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/updateVoucherById")
    public R updateVoucherById(@RequestBody VoucherQryDto qry){
        try{
            String[] idArray =qry.getId().split(",");
            for (int value=0;value<idArray.length;value++){
                qry.setId(idArray[value].toString());
                voucherService.updateVoucher(qry);
            }
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addVoucher(@RequestBody VoucherQryDto qry){
        try{
            String voucherId=voucherService.addVoucher(qry);
            return R.ok().data("voucherId", voucherId);
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody VoucherQryDto qry){
        try{
            voucherService.delVoucherById(qry.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

