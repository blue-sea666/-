package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.AccountsSubject;
import com.data.financeapi.mapper.AccountsMapper;
import com.data.financeapi.mapper.AccountsSubjectMapper;
import com.data.financeapi.service.AccountsService;
import com.data.financeapi.service.AccountsSubjectService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.AccountsSubjectVo;
import com.data.financeapi.vo.AccountsVo;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class AccountsSubjectServiceImpl extends ServiceImpl<AccountsSubjectMapper, AccountsSubject> implements AccountsSubjectService {
    @Override
    public Boolean addAccountsSubject(AccountsSubjectQryDto qry){
        AccountsSubject accountsSubject=new AccountsSubject(qry);
        accountsSubject.setId(UUIDUtil.uuid());
        return baseMapper.insert(accountsSubject) > 0;
    }
    @Override
    public Boolean updateAccountsSubject(AccountsSubjectQryDto qry){
        AccountsSubject accountsSubject=new AccountsSubject(qry);
        return baseMapper.updateById(accountsSubject) > 0;
    }
    @Override
    public Boolean delAccountsSubjectById(String accountsSubjectId) {
        AccountsSubject accountsSubject = new AccountsSubject();
        accountsSubject.setId(accountsSubjectId);
        return baseMapper.delete(new QueryWrapper<>(accountsSubject))>0;
    }
    @Override
    public List<AccountsSubjectVo> qryAccountsSubjectList(AccountsSubjectQryDto accountsSubjectQryDto) {

        return baseMapper.qryAccountsSubjectList(accountsSubjectQryDto);
    }
}
