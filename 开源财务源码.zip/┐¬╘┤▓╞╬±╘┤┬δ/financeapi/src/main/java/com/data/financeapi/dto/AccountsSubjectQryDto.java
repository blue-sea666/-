package com.data.financeapi.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

@Data
public class AccountsSubjectQryDto {

    private String Id;

    private String AccountsId;

    private String SubjectId;

    private Integer SubjectStatus;

    private double StartMoney;

    private Integer SubjectType;

    private int pageNum;

    private int pageSize;
}