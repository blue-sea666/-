package com.data.financeapi.utils;

import lombok.Data;

/**
 * 统一返回结果集
 *
 * @author 王薪鑫
 * @date 2021年8月10日
 */
@Data
public class Result<T> {

    /**
     * 是否成功
     */
    private boolean success;

    /**
     * 代码编号
     */
    private Integer code;

    /**
     * 数据集
     */
    private T data;

    /**
     * 消息
     */
    private String message;

    /**
     * 堆栈异常错误消息
     */
    private String stackMessage;

    /**
     * 数据大小
     */
    private long count;

    public Result() {

    }

    public Result(boolean success, Integer code, T data, String message, long count) {
        this.success = success;
        this.code = code;
        this.data = data;
        this.message = message;
        this.count = count;
    }

    public Result(boolean success, Integer code, T data, String message, long count, String stackMessage) {
        this.success = success;
        this.code = code;
        this.data = data;
        this.message = message;
        this.count = count;
        this.stackMessage = stackMessage;
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @return
     */
    public static <T> Result build(boolean success, Integer code) {
        return new Result(success, code, null, null, 0, null);
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @param data
     * @return
     */
    public static <T> Result build(boolean success, Integer code, T data) {
        return new Result(success, code, data, null, 0, null);
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @param data
     * @param count
     * @return
     */
    public static <T> Result build(boolean success, Integer code, T data, long count) {
        return new Result(success, code, data, null, count, null);
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @param message
     * @return
     */
    public static <T> Result build(boolean success, Integer code, String message) {
        return new Result(success, code, null, message, 0, null);
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @param data
     * @param message
     * @return
     */
    public static <T> Result build(boolean success, Integer code, T data, String message) {
        return new Result(success, code, data, message, 0, null);
    }

    /**
     * 自定义生成结果对象
     *
     * @param success
     * @param code
     * @param data
     * @param message
     * @param count
     * @return
     */
    public static <T> Result build(boolean success, Integer code, T data, String message, long count) {
        return new Result(success, code, data, message, count, null);
    }

    /**
     * 成功
     *
     * @return
     */
    public static <T> Result ok() {
        return new Result(true, ResultEnum.Success.getIndex(), null, null, 0, null);
    }

    /**
     * 成功
     *
     * @param data
     * @return
     */
    public static <T> Result ok(T data) {
        return new Result(true, ResultEnum.Success.getIndex(), data, null, 0, null);
    }

    /**
     * 成功
     *
     * @param code
     * @param data
     * @return
     */
    public static <T> Result ok(Integer code, T data) {
        return new Result(true, code, data, null, 0, null);
    }

    /**
     * 成功
     *
     * @param data
     * @param count
     * @return
     */
    public static <T> Result ok(T data, long count) {
        return new Result(true, ResultEnum.Success.getIndex(), data, null, count, null);
    }

    /**
     * 成功
     *
     * @param code
     * @param data
     * @param count
     * @return
     */
    public static <T> Result ok(Integer code, T data, long count) {
        return new Result(true, code, data, null, count);
    }

    /**
     * 失败
     *
     * @param message
     * @return
     */
    public static <T> Result fail(String message) {
        return new Result(false, ResultEnum.Fail.getIndex(), null, message, 0, null);
    }

    /**
     * 失败
     *
     * @param code
     * @param message
     * @return
     */
    public static <T> Result fail(Integer code, String message) {
        return new Result(false, code, null, message, 0, null);
    }

    /**
     * 失败
     *
     * @param message
     * @param stackMessage
     * @return
     */
    public static <T> Result fail(String message, String stackMessage) {
        return new Result(false, ResultEnum.Fail.getIndex(), null, message, 0, stackMessage);
    }

    /**
     * 失败
     *
     * @param code
     * @param message
     * @param stackMessage
     * @return
     */
    public static <T> Result fail(Integer code, String message, String stackMessage) {
        return new Result(false, code, null, message, 0, stackMessage);
    }
}