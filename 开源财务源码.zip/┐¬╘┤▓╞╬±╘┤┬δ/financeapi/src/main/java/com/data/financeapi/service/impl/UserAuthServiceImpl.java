package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.UserAuthQryDto;
import com.data.financeapi.entity.UserAuth;
import com.data.financeapi.mapper.UserAuthMapper;
import com.data.financeapi.service.UserAuthService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.UserAuthVo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class UserAuthServiceImpl extends ServiceImpl<UserAuthMapper, UserAuth> implements UserAuthService {
    @Override
    public Boolean addUserAuth(UserAuthQryDto qry){
        UserAuth userAuth=new UserAuth(qry);
        userAuth.setId(UUIDUtil.uuid());
        return baseMapper.insert(userAuth) > 0;
    }
    @Override
    public Boolean delUserAuthById(String userId) {
        UserAuth userauth = new UserAuth();
        userauth.setUserId(userId);
        return baseMapper.delete(new QueryWrapper<>(userauth))>0;
    }
    @Override
    public Boolean saveUserAuthArray(List<UserAuthQryDto> userAuthQryDto) {

        if (userAuthQryDto == null) {
            return false;
        }
        int insert = baseMapper.saveUserAuthArray(userAuthQryDto);
        return insert > 0;
    }
    @Override
    public List<UserAuthVo> qryUserAuthList(UserAuthQryDto userAuthQryDto) {

        UserAuth userAuth = new UserAuth(userAuthQryDto);
        return baseMapper.qryUserAuthList(userAuthQryDto);
    }
}
