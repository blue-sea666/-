package com.data.financeapi.controller;
import com.data.financeapi.dto.UserAuthQryDto;
import com.data.financeapi.service.UserAuthService;
import com.data.financeapi.utils.R;
import com.data.financeapi.vo.UserAuthVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/userauth")
@CrossOrigin //解决跨域问题
public class UserAuthController {
    @Autowired
    private UserAuthService userAuthService;
    @PostMapping("/savelist")
    public R addUserList(@RequestBody List<UserAuthQryDto> userAuthQryDto){
        try {
            userAuthService.delUserAuthById(userAuthQryDto.get(0).getUserId());
            for (int index = 0; index < userAuthQryDto.size(); index++) {
                userAuthService.addUserAuth(userAuthQryDto.get(index));
            }
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/list")
    public R list(@RequestBody UserAuthQryDto userAuthQryDto) {
        try{
            List<UserAuthVo> authlist=userAuthService.qryUserAuthList(userAuthQryDto);
            return R.ok().data("total",authlist.size()).data("records", authlist);
        }catch (Exception e){
            return R.error();
        }
    }
}

