package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.DeptQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_dept")
public class Dept implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "pid")
    private String Pid;

    @TableField(value = "name")
    private String Name;

    public Dept() {

    }
    public Dept(DeptQryDto deptQryDto) {
        BeanUtils.copyProperties(deptQryDto, this);
    }

}