package com.data.financeapi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.AccountsSubject;
import com.data.financeapi.vo.AccountsSubjectVo;
import com.data.financeapi.vo.AccountsVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface AccountsSubjectService extends IService<AccountsSubject> {
    Boolean addAccountsSubject(AccountsSubjectQryDto qry);

    Boolean updateAccountsSubject(AccountsSubjectQryDto qry);

    Boolean delAccountsSubjectById(String accountsSubjectId);

    List<AccountsSubjectVo> qryAccountsSubjectList(AccountsSubjectQryDto qry);

}
