package com.data.financeapi.vo;

import lombok.Data;

@Data
public class RoleVo {

    private String Id;

    private String RoleName;
}