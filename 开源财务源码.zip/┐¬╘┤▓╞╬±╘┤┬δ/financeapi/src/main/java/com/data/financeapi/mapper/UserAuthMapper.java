package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.dto.UserAuthQryDto;
import com.data.financeapi.entity.UserAuth;
import com.data.financeapi.vo.UserAuthVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserAuthMapper extends BaseMapper<UserAuth> {
    int saveUserAuthArray(@Param("userAuthDto") List<UserAuthQryDto> UserAuthQryDtoList);

    List<UserAuthVo> qryUserAuthList(@Param("userAuthQryDto") UserAuthQryDto userAuthQryDto);
}
