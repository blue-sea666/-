package com.data.financeapi.dto;
import lombok.Data;

@Data
public class UserRoleQryDto{

    private String Id;

    private String RoleId;

    private String UserId;

    private String MenuId;

    private String Level;

    private int pageNum;

    private int pageSize;
}