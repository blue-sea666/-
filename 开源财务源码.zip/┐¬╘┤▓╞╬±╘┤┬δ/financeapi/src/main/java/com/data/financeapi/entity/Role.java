package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.RoleQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_role")
public class Role implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "role_name")
    private String RoleName;

    public Role() {

    }
    public Role(RoleQryDto roleQryDto) {
        BeanUtils.copyProperties(roleQryDto, this);
    }

}