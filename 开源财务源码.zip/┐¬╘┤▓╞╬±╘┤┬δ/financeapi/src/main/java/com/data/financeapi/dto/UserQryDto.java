package com.data.financeapi.dto;

import lombok.Data;

@Data
public class UserQryDto{

    private String Id;

    private String UserName;

    private String UserCode;

    private String UserTel;

    private String UserEmail;

    private String UserPassword;

    private String DeptId;

    private String DeptIdStr;

    private int pageNum;

    private int pageSize;
}