package com.data.financeapi.dto;

import lombok.Data;

@Data
public class SubjectCategoryQryDto {

    private String Id;

    private String CateName;

    private int pageNum;

    private int pageSize;
}