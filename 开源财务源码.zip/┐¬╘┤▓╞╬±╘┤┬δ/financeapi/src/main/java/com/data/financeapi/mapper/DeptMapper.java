package com.data.financeapi.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.entity.Dept;
import com.data.financeapi.vo.DeptVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Mapper
public interface DeptMapper extends BaseMapper<Dept> {
    List<DeptVo> qryDeptList();
}
