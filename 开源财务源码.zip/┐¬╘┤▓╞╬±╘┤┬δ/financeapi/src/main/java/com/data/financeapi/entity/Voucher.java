package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.DeptQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_voucher")
public class Voucher implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "voucher_time")
    private String VoucherTime;

    @TableField(value = "voucher_name")
    private String VoucherName;

    @TableField(value = "voucher_code")
    private String VoucherCode;

    @TableField(value = "voucher_status")
    private Integer VoucherStatus;

    @TableField(value = "accounts_id")
    private String AccountsId;
    public Voucher() {

    }
    public Voucher(VoucherQryDto voucherQryDto) {
        BeanUtils.copyProperties(voucherQryDto, this);
    }

}