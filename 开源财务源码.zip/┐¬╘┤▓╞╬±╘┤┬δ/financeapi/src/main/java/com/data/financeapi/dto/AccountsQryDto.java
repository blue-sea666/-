package com.data.financeapi.dto;

import lombok.Data;

@Data
public class AccountsQryDto {

    private String Id;

    private String AccountsName;

    private String AccountsSystem;

    private String SetTime;

    private String InsertTime;

    private String UpdateTime;

    private Integer AccountsStatus;

    private Integer SubjectType;

    private int pageNum;

    private int pageSize;
}