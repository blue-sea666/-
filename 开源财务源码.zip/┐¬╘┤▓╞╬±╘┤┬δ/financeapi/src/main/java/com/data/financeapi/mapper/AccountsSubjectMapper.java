package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.AccountsSubject;
import com.data.financeapi.vo.AccountsSubjectVo;
import com.data.financeapi.vo.AccountsVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface AccountsSubjectMapper extends BaseMapper<AccountsSubject> {
    List<AccountsSubjectVo> qryAccountsSubjectList(@Param("AccountsSubjectQryDto") AccountsSubjectQryDto accountsSubjectQryDto);
}
