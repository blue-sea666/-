package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.entity.User;
import com.data.financeapi.vo.SubjectVo;
import com.data.financeapi.vo.UserVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface SubjectService extends IService<Subject> {
    Boolean addSubject(SubjectQryDto qry);

    Boolean updateSubject(SubjectQryDto qry);

    Boolean delSubjectById(String subjectId);

    List<SubjectVo> qrySubjectList(SubjectQryDto subjectQryDto);

    List<SubjectVo> qrySubjectById(SubjectQryDto subjectQryDto);
}
