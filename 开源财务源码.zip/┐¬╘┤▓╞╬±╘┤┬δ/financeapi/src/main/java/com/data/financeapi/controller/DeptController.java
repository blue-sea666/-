package com.data.financeapi.controller;


import com.data.financeapi.dto.DeptQryDto;
import com.data.financeapi.service.DeptService;
import com.data.financeapi.utils.R;
import com.data.financeapi.vo.DeptVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/dept")
@CrossOrigin //解决跨域问题
public class DeptController {
    @Autowired
    DeptService deptService;
    //项目启动的情况下访问 http://localhost:8001/swagger-ui.html 就能打开swagger接口文档，并能修改传值，发送请求
    @PostMapping("/list")
    public R list() {
        try{
            List<DeptVo> deptlist=deptService.qryDeptList();
            return R.ok().data("records", deptlist);
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/findDeptById")
    public R findDeptById(@RequestBody DeptQryDto qry) {
        try {
            return R.ok().data("total",deptService.qryDeptById(qry).size()).data("records",deptService.qryDeptById(qry));
        } catch (Exception e) {
            return R.error();
        }
    }
    @PostMapping("/updateDept")
    public R updateDept(@RequestBody DeptQryDto dept){
        try{
            deptService.updateDept(dept);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/save")
    public R addDept(@RequestBody DeptQryDto dept){
        try{
            deptService.addDept(dept);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/deleteById")
    public R deleteById(@RequestBody DeptQryDto dept){
        try{
            String id=dept.getId();
            deptService.delDeptById(id);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

