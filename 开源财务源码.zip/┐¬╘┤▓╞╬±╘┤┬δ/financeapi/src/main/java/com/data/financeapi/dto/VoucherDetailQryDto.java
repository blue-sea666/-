package com.data.financeapi.dto;

import lombok.Data;

@Data
public class VoucherDetailQryDto {

    private String id;

    private String VoucherId;

    private String SummaryName;

    private String SubjectId;

    private String SubjectName;

    private double DebitMoney;

    private double LenderMoney;

    private String InsertTime;

    private String VoucherTime;

    private String VoucherName;

    private String VoucherCode;

    private Integer VoucherStatus;

    private String AccountsId;

    private int PageNum;

    private int PageSize;


}