package com.data.financeapi.controller;


import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.dto.UserAuthQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.dto.UserRoleQryDto;
import com.data.financeapi.entity.Menu;
import com.data.financeapi.entity.UserRole;
import com.data.financeapi.service.MenuService;
import com.data.financeapi.service.UserAuthService;
import com.data.financeapi.service.UserRoleService;
import com.data.financeapi.utils.NodeUtil;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.MenuVo;
import com.data.financeapi.vo.UserAuthVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/menu")
@CrossOrigin //解决跨域问题
public class MenuController {
    @Autowired
    MenuService menuService;
    @Autowired
    UserAuthService userAuthService;
    @Autowired
    UserRoleService userRoleService;
    //项目启动的情况下访问 http://localhost:8001/swagger-ui.html 就能打开swagger接口文档，并能修改传值，发送请求
    @PostMapping("/list")
    public R list(@RequestBody UserQryDto qry) {
        try{
            String userId=qry.getId();
            UserAuthQryDto userAuthQryDto=new UserAuthQryDto();
            userAuthQryDto.setUserId(userId);
            List<UserAuthVo> authlist=userAuthService.qryUserAuthList(userAuthQryDto);
            String menuIdStr="";
            for(UserAuthVo userAuthVo:authlist){
                String roleId=userAuthVo.getId();
                UserRoleQryDto userRoleQryDto=new  UserRoleQryDto();
                userRoleQryDto.setRoleId(roleId);
                List<UserRole> userRoleList=userRoleService.qryUserRoleList(userRoleQryDto);
                for (UserRole userRole:userRoleList){
                    String menuId=userRole.getMenuId();
                    menuIdStr=menuIdStr+menuId+",";
                }
            }
            List<MenuVo> menuarray=new ArrayList<>();
            if (menuIdStr!=""){
                MenuQryDto menuQryDto=new MenuQryDto();
                menuQryDto.setIdStr(menuIdStr);
                List<MenuVo> menulist=menuService.qryMenuList(menuQryDto);
                NodeUtil util=new NodeUtil();
                menuarray=util.queryCatList(menulist);
            }
            return R.ok().data("records", menuarray);

        }catch (Exception e){
            return R.error();
        }
    }
    @GetMapping("/getMenuTree")
    public R getMenuTree() {
        try{
            List<Menu> menulist=menuService.list();
            NodeUtil util=new NodeUtil();
            List<Menu> arraylist=util.queryCatTree(menulist);
            return R.ok().data("records", arraylist);
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/findMenuById")
    public R findMenuById(@RequestBody MenuQryDto qry) {
        try {
            return R.ok().data("total",menuService.qryMenuById(qry).size()).data("records",menuService.qryMenuById(qry));
        } catch (Exception e) {
            return R.error();
        }
    }

    @PostMapping("/findMenuPage")
    public Result findMenuPage(@RequestBody MenuQryDto qry) {

        try {
            return Result.ok(menuService.qryMenuPage(qry.getPageNum(), qry.getPageSize(), qry));
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }
    @PostMapping("/updateMenu")
    public R updateMenu(@RequestBody MenuQryDto menu){
        try{
            menuService.updateMenu(menu);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addMenu(@RequestBody MenuQryDto menu){
        try{

            menuService.addMenu(menu);

            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/deleteById")
    public R deleteById(@RequestBody MenuQryDto menu){
        try{
            String id=menu.getId();
            menuService.delMenuById(id);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

