package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.User;
import com.data.financeapi.vo.UserVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserService extends IService<User> {
    Boolean addUser(UserQryDto qry);

    Boolean updateUser(UserQryDto qry);

    Boolean delUserById(String menuId);

    IPage<UserVo> qryUserListPage(Page<User> page, UserQryDto userQryDto) throws Exception;

    IPage<UserVo> qryUserPageByid(Page<User> page, UserQryDto userQryDto) throws Exception;

    List<UserVo> qryUserList(UserQryDto userQryDto);
}
