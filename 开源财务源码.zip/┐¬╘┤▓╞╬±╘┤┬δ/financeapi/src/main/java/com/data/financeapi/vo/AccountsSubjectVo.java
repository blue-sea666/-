package com.data.financeapi.vo;

import lombok.Data;

@Data
public class AccountsSubjectVo {

    private String Id;

    private String AccountsId;

    private String SubjectId;

    private Integer SubjectStatus;

    private double StartMoney;

    private String SubjectCode;

    private String SubjectName;

    private Integer SubjectLevel;

    private Integer AccountStatus;

    private String Pid;

    private String InsertTime;

    private String UpdateTime;

    private Integer isDel;

    private String MnemonicCode;

    private String SubjectCategory;

    private String SubjectCategoryName;

    private Integer BalanceDirection;

    private Integer ForeignAccount;

    private Integer EndExchange;

    private Integer TransAccount;

    private Integer CountmoneAccount;

    private String SubjectFullname;

    private Integer SubjectType;
}