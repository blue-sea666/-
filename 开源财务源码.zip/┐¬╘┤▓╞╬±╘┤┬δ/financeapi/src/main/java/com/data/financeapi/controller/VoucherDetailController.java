package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.VoucherDetailQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.entity.VoucherDetail;
import com.data.financeapi.service.VoucherDetailService;
import com.data.financeapi.service.VoucherService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.VoucherDetailVo;
import com.data.financeapi.vo.VoucherVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/voucherdetail")
@CrossOrigin //解决跨域问题
public class VoucherDetailController {
    @Autowired
    VoucherDetailService voucherDetailService;
    @PostMapping("/getVoucherDetail")
    public Result getVoucherDetail(@RequestBody VoucherDetailQryDto qry) {

        try {
            Page<VoucherDetail> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<VoucherDetailVo> list=voucherDetailService.qryVoucherDetailListPage(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/update")
    public R updateVoucherDetail(@RequestBody VoucherDetailQryDto qry){
        try{
            voucherDetailService.updateVoucherDetail(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addVoucherDetail(@RequestBody List<VoucherDetailQryDto> qry){
        try{
            for (VoucherDetailQryDto voucherDetailQryDto: qry) {
                voucherDetailService.addVoucherDetail(voucherDetailQryDto);
            }
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody VoucherDetailQryDto qry){
        try{
            voucherDetailService.delVoucherDetailById(qry.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

