package com.data.financeapi.dto;
import lombok.Data;

@Data
public class UserAuthQryDto {

    private String Id;

    private String RoleId;

    private String UserId;
}
