package com.data.financeapi.dto;

import lombok.Data;

@Data
public class DeptQryDto {

    private String Id;

    private String Pid;

    private String Name;

}