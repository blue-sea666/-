package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.vo.AccountsVo;
import com.data.financeapi.vo.SubjectVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface AccountsMapper extends BaseMapper<Accounts> {
    List<AccountsVo> qryAccountsList(@Param("AccountsQryDto") AccountsQryDto accountsQryDto);
}
