package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.UserQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_user")
public class User implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "user_name")
    private String UserName;

    @TableField(value = "user_code")
    private String UserCode;

    @TableField(value = "user_tel")
    private String UserTel;

    @TableField(value = "user_email")
    private String UserEmail;

    @TableField(value = "user_password")
    private String UserPassword;

    @TableField(value = "dept_id")
    private String DeptId;

    public User() {

    }
    public User(UserQryDto userQryDto) {
        BeanUtils.copyProperties(userQryDto, this);
    }

}