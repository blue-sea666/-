package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.VoucherVo;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface VoucherService extends IService<Voucher> {
    String addVoucher(VoucherQryDto qry);

    Boolean updateVoucher(VoucherQryDto qry);

    Boolean delVoucherById(String Id);

    IPage<VoucherVo> qryVoucherListPage(Page<Voucher> page, VoucherQryDto qry);

}
