package com.data.financeapi.controller;


import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.dto.UserRoleQryDto;
import com.data.financeapi.entity.Menu;
import com.data.financeapi.service.MenuService;
import com.data.financeapi.service.UserRoleService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/userrole")
@CrossOrigin //解决跨域问题
public class UserRoleController {
    @Autowired
    UserRoleService userRoleService;
    @Autowired
    private MenuService menuService;
    @PostMapping("/savelist")
    public R addUserList(@RequestBody List<UserRoleQryDto> userRoleQryDto){
        try {
            userRoleService.delUserRole(userRoleQryDto.get(0).getRoleId());
            for (int index = 0; index < userRoleQryDto.size(); index++) {

                MenuQryDto menuQryDto=new MenuQryDto();
                String menuId=userRoleQryDto.get(index).getMenuId();
                menuQryDto.setId(menuId);
                List<Menu> list=menuService.qryMenu(menuQryDto);
                for (Menu menuVo:list) {
                    userRoleQryDto.get(index).setLevel(menuVo.getPid());
                    userRoleService.addUserRole(userRoleQryDto.get(index));
                }
                //userRoleService.delUserRole(userRoleQryDto.get(index).getMenuId());
                //userRoleQryDto.get(index).setId(UUIDUtil.uuid());
            }
            //userRoleService.saveUserRoleArray(userRoleQryDto);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
    @PostMapping("/findUserRole")
    public Result findRoleById(@RequestBody UserRoleQryDto qry) {

        try {
            return Result.ok(userRoleService.qryUserRoleListPage(qry.getPageNum(), qry.getPageSize(), qry));
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/update")
    public R updateUserRole(@RequestBody UserRoleQryDto qry){
        try{
            userRoleService.updateUserRole(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addUser(@RequestBody UserRoleQryDto qry){
        try{
            userRoleService.addUserRole(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(String userRoleId){
        try{
            userRoleService.delUserRoleById(userRoleId);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

