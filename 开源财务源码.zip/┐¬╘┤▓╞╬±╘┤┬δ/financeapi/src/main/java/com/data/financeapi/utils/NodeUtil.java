package com.data.financeapi.utils;

import com.data.financeapi.entity.Menu;
import com.data.financeapi.vo.MenuVo;

import java.util.*;

/**
 * @author yjw
 * @date 2020/7/28
 */
public class NodeUtil {

    private static final Integer LEVEL_1 = 1;

    /**
     * 获取所有分类
     * @return
     */
    public  List<MenuVo> queryCatList(List<MenuVo> data){
        //定义新的list
        List<MenuVo> categoriesList = new ArrayList<>();
        //先找到所有的一级分类
        for(MenuVo category : data){

            if(category.getPid().equals("0")){
                categoriesList.add(category);

                Map<String,Object> datas = new HashMap<>();
                datas.put("icon",category.getIcon());
                datas.put("title",category.getName());
                category.setMeta(datas);
            }
        }
        // 为一级菜单设置子菜单，getChild是递归调用的
        for(MenuVo category : categoriesList){
            category.setChildren(getChilde(category.getId(), data));
        }

        return categoriesList;
    }

    /**
     * 递归查找子菜单
     *
     * @param id 当前菜单id
     * @param rootList 要查找的列表
     * @return
     */
    public  List<MenuVo> getChilde(String id, List<MenuVo> rootList){
        //子级
        List<MenuVo> childList = new ArrayList<>();
        for(MenuVo category : rootList){
            // 遍历所有节点，将父级id与传过来的id比较
            if(category.getPid().equals(id)){
                childList.add(category);
            }
        }
        // 把子级的子级再循环一遍
        for(MenuVo category : childList){
            category.setChildren(getChilde(category.getId(), rootList));
            Map<String,Object> datas = new HashMap<>();
            datas.put("title",category.getName());
            datas.put("icon",category.getIcon());
            if (category.getComponent()!=null){
                datas.put("component",category.getComponent());
            }
            category.setMeta(datas);
        }
        // 递归退出条件
        if (childList.size() == 0){
            return null;
        }
        return childList;
    }


    /**
     * 获取所有分类
     * @return
     */
    public  List<Menu> queryCatTree(List<Menu> data){
        //定义新的list
        List<Menu> categoriesList = new ArrayList<>();
        //先找到所有的一级分类
        for(Menu category : data){

            if(category.getPid().equals("0")){
                categoriesList.add(category);
            }
        }
        // 为一级菜单设置子菜单，getChild是递归调用的
        for(Menu category : categoriesList){
            category.setChildren(getChildeTree(category.getId(), data));
        }

        return categoriesList;
    }

    /**
     * 递归查找子菜单
     *
     * @param id 当前菜单id
     * @param rootList 要查找的列表
     * @return
     */
    public  List<Menu> getChildeTree(String id, List<Menu> rootList){
        //子级
        List<Menu> childList = new ArrayList<>();
        for(Menu category : rootList){
            // 遍历所有节点，将父级id与传过来的id比较
            if(category.getPid().equals(id)){
                childList.add(category);
            }
        }
        // 把子级的子级再循环一遍
        for(Menu category : childList){
            category.setChildren(getChildeTree(category.getId(), rootList));

        }
        // 递归退出条件
        if (childList.size() == 0){
            return null;
        }
        return childList;
    }
}
