package com.data.financeapi.controller;


import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import com.data.financeapi.service.AccountsService;
import com.data.financeapi.service.AccountsSubjectService;
import com.data.financeapi.utils.R;
import com.data.financeapi.vo.AccountsSubjectVo;
import com.data.financeapi.vo.AccountsVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/accountssubject")
@CrossOrigin //解决跨域问题
public class AccountsSubjectController {
    @Autowired
    AccountsSubjectService accountsSubjectService;
    @PostMapping("/getAccountsSubject")
    public R getAccountsSubject(@RequestBody AccountsSubjectQryDto qry) {

        try {
            List<AccountsSubjectVo> list=accountsSubjectService.qryAccountsSubjectList(qry);
            return R.ok().data("records", list).data("total", list.size());
        } catch (Exception e) {
            return R.error();
        }
    }
    @PostMapping("/update")
    public R updateAccountsSubject(@RequestBody AccountsSubjectQryDto qry){
        try{
            accountsSubjectService.updateAccountsSubject(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addAccountsSubject(@RequestBody AccountsSubjectQryDto qry){
        try{
            accountsSubjectService.addAccountsSubject(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody AccountsSubjectQryDto accountsSubject){
        try{
            accountsSubjectService.delAccountsSubjectById(accountsSubject.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

