package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.User;
import com.data.financeapi.service.SubjectService;
import com.data.financeapi.service.UserService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.SubjectVo;
import com.data.financeapi.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/subject")
@CrossOrigin //解决跨域问题
public class SubjectController {
    @Autowired
    SubjectService subjectService;
    @PostMapping("/getSubject")
    public R getUser(@RequestBody SubjectQryDto qry) {

        try {
            List<SubjectVo> list=subjectService.qrySubjectList(qry);
            return R.ok().data("records", list).data("total", list.size());
        } catch (Exception e) {
            return R.error();
        }
    }
    @PostMapping("/qrySubjectById")
    public R qrySubjectById(@RequestBody SubjectQryDto qry) {

        try {
            List<SubjectVo> list=subjectService.qrySubjectById(qry);
            return R.ok().data("records", list).data("total", list.size());
        } catch (Exception e) {
            return R.error();
        }
    }

    @PostMapping("/update")
    public R updateSubject(@RequestBody SubjectQryDto qry){
        try{
            subjectService.updateSubject(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addSubject(@RequestBody SubjectQryDto qry){
        try{
            subjectService.addSubject(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody SubjectQryDto subject){
        try{
            subjectService.delSubjectById(subject.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

