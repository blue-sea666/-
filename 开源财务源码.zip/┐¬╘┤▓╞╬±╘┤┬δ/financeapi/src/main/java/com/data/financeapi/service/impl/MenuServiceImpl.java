package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.entity.Menu;
import com.data.financeapi.mapper.MenuMapper;
import com.data.financeapi.service.MenuService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.MenuVo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu> implements MenuService {
    @Override
    public Boolean addMenu(MenuQryDto qry){
        Menu menu=new Menu(qry);
        String uuid=UUIDUtil.uuid();
        menu.setId(uuid);
        if (qry.getPid().equals("0")){
            Menu mu=new Menu(qry);
            mu.setId(UUIDUtil.uuid());
            mu.setPid(uuid);
            mu.setLabel("未命名");
            mu.setTitle("未命名");
            mu.setIcon("el-icon-s-tools");
            mu.setComponent("/index/list");
            baseMapper.insert(mu);
        }
       return baseMapper.insert(menu)>0;
    }
    @Override
    public Boolean updateMenu(MenuQryDto qry){
        Menu menu=new Menu(qry);
        return baseMapper.updateById(menu) > 0;
    }
    @Override
    public Boolean delMenuById(String menuId) {
        Menu menu = new Menu();
        menu.setId(menuId);
        return baseMapper.delete(new QueryWrapper<>(menu))>0;
    }
    @Override
    public List<MenuVo> qryMenuById(MenuQryDto menuQryDto) {

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("pid", menuQryDto.getId());
        return baseMapper.selectList(queryWrapper);
    }
    @Override
    public List<Menu> qryMenu(MenuQryDto menuQryDto) {

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("id", menuQryDto.getId());
        return baseMapper.selectList(queryWrapper);
    }
    @Override
    public List<MenuVo> qryMenuList(MenuQryDto menuQryDto) {

        return baseMapper.qryMenuListByid(menuQryDto);
    }
    @Override
    public IPage<Menu> qryMenuPage(int current, int size, MenuQryDto menuQryDto) {

        Menu menu = new Menu(menuQryDto);
        Page<Menu> page = new Page<>();
        page.setCurrent(current);
        page.setSize(size);
        return baseMapper.selectPage(page, new QueryWrapper<>(menu));
    }

}
