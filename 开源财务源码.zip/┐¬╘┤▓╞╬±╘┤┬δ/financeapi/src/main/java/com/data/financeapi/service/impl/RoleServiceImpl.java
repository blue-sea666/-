package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.data.financeapi.dto.RoleQryDto;
import com.data.financeapi.entity.Role;
import com.data.financeapi.mapper.RoleMapper;
import com.data.financeapi.service.RoleService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.RoleVo;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {
    @Override
    public Boolean addRole(RoleQryDto qry){
        Role role=new Role(qry);
        role.setId(UUIDUtil.uuid());
        return baseMapper.insert(role) > 0;
    }
    @Override
    public Boolean updateRole(RoleQryDto qry){
        Role role=new Role(qry);
        return baseMapper.updateById(role) > 0;
    }
    @Override
    public Boolean delRoleById(String roleId) {
        Role role = new Role();
        role.setId(roleId);
        return baseMapper.delete(new QueryWrapper<>(role))>0;
    }
    @Override
    public IPage<RoleVo> qryRoleListPage(Page<Role> page, RoleQryDto roleQryDto) {

        Role role = new Role(roleQryDto);
//
//        Page<Role> page = new Page<>();
//        page.setCurrent(current);
//        page.setSize(size);
        return baseMapper.qryRoleListPage(page, roleQryDto);
    }
}
