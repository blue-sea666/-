package com.data.financeapi.controller;


import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.service.AccountsService;
import com.data.financeapi.service.AccountsSubjectService;
import com.data.financeapi.service.SubjectService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.AccountsVo;
import com.data.financeapi.vo.SubjectVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/accounts")
@CrossOrigin //解决跨域问题
public class AccountsController {
    @Autowired
    AccountsService accountsService;
    @Autowired
    AccountsSubjectService accountsSubjectService;
    @Autowired
    SubjectService subjectService;
    @PostMapping("/getAccounts")
    public R getAccounts(@RequestBody AccountsQryDto qry) {

        try {
            List<AccountsVo> list=accountsService.qryAccountsList(qry);
            return R.ok().data("records", list).data("total", list.size());
        } catch (Exception e) {
            return R.error();
        }
    }
    @PostMapping("/update")
    public R updateAccounts(@RequestBody AccountsQryDto qry){
        try{
            accountsService.updateAccounts(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addAccounts(@RequestBody AccountsQryDto qry){
        try{
            String accountsId=accountsService.addAccounts(qry);
            SubjectQryDto qryDto=new SubjectQryDto();
            List<SubjectVo> subjectVoList=subjectService.qrySubjectList(qryDto);
            for (SubjectVo subjectVo:subjectVoList) {
                AccountsSubjectQryDto accountsSubjectQryDto=new AccountsSubjectQryDto();
                accountsSubjectQryDto.setId(UUIDUtil.uuid());
                accountsSubjectQryDto.setAccountsId(accountsId);
                accountsSubjectQryDto.setSubjectId(subjectVo.getId());
                accountsSubjectQryDto.setSubjectStatus(0);
                accountsSubjectQryDto.setStartMoney(0);
                accountsSubjectService.addAccountsSubject(accountsSubjectQryDto);
            }
            //accountsSubjectService.qryAccountsSubjectList();
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody AccountsQryDto accounts){
        try{
            accountsService.delAccountsById(accounts.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

