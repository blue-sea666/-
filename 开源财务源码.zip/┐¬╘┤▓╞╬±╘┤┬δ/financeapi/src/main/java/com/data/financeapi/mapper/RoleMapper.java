package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.RoleQryDto;
import com.data.financeapi.entity.Role;
import com.data.financeapi.vo.RoleVo;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface RoleMapper extends BaseMapper<Role> {

    IPage<RoleVo> qryRoleListPage(Page<Role> page, @Param("RoleQryDto") RoleQryDto roleQryDto);
}
