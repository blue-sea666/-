package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.User;
import com.data.financeapi.vo.UserVo;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserMapper extends BaseMapper<User> {

    IPage<UserVo> qryUserListPage(Page<User> page, @Param("UserQryDto") UserQryDto userQryDto);

    IPage<UserVo> qryUserPageByid(Page<User> page, @Param("UserQryDto") UserQryDto userQryDto);
}
