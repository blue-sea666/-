package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.UserAuthQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_userauth")
public class UserAuth implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "role_id")
    private String RoleId;

    @TableField(value = "user_id")
    private String UserId;

    public UserAuth() {

    }
    public UserAuth(UserAuthQryDto userAuthQryDto) {
        BeanUtils.copyProperties(userAuthQryDto, this);
    }

}