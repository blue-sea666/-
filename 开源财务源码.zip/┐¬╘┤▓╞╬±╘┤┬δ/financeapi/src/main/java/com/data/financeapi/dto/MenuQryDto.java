package com.data.financeapi.dto;

import lombok.Data;

@Data
public class MenuQryDto{

    private String Id;

    private String Pid;

    private Integer Level;

    private String Path;

    private String Label;

    private String Component;

    private String Icon;

    private String Title;

    private String IdStr;

    private int PageNum;

    private int PageSize;


}