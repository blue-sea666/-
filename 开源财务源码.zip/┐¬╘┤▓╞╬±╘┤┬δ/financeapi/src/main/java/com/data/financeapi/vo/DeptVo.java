package com.data.financeapi.vo;

import com.data.financeapi.dto.DeptQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class DeptVo {

    private String id;

    private String pid;

    private String name;

    public DeptVo() {

    }
    public DeptVo(DeptQryDto deptQryDto) {
        BeanUtils.copyProperties(deptQryDto, this);
    }

}