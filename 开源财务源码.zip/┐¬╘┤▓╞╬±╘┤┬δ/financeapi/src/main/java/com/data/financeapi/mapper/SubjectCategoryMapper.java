package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.SubjectVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface SubjectCategoryMapper extends BaseMapper<SubjectCategory> {
    IPage<SubjectCategoryVo> qrySubjectCategoryListPage(Page<SubjectCategory> page, @Param("SubjectCategoryQryDto") SubjectCategoryQryDto subjectCategoryQryDto);
}
