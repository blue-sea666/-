package com.data.financeapi.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.RoleQryDto;
import com.data.financeapi.entity.Role;
import com.data.financeapi.vo.RoleVo;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface RoleService extends IService<Role> {
    Boolean addRole(RoleQryDto qry);

    Boolean updateRole(RoleQryDto qry);

    Boolean delRoleById(String roleId);

    IPage<RoleVo> qryRoleListPage(Page<Role> page, RoleQryDto roleQryDto) throws Exception;
}
