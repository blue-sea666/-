package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.UserRoleQryDto;
import com.data.financeapi.entity.UserRole;
import com.data.financeapi.mapper.UserRoleMapper;
import com.data.financeapi.service.UserRoleService;
import com.data.financeapi.utils.UUIDUtil;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, UserRole> implements UserRoleService {
    @Override
    public Boolean addUserRole(UserRoleQryDto qry){
        UserRole userRole=new UserRole(qry);
        userRole.setId(UUIDUtil.uuid());
        return baseMapper.insert(userRole) > 0;
    }
    @Override
    public Boolean updateUserRole(UserRoleQryDto qry){
        UserRole userRole=new UserRole(qry);
        return baseMapper.updateById(userRole) > 0;
    }
    @Override
    public Boolean delUserRoleById(String userroleId) {

        return baseMapper.deleteById(userroleId) > 0;
    }
    @Override
    public Boolean delUserRole(String roleId) {
        UserRole userole = new UserRole();
        userole.setRoleId(roleId);
        return baseMapper.delete(new QueryWrapper<>(userole))>0;
    }
    @Override
    public IPage<UserRole> qryUserRoleListPage(long current, long size, UserRoleQryDto userRoleQryDto) {

        UserRole userRole = new UserRole(userRoleQryDto);

        Page<UserRole> page = new Page<>();
        page.setCurrent(current);
        page.setSize(size);
        return baseMapper.selectPage(page, new QueryWrapper<>(userRole));
    }
    @Override
    public List<UserRole> qryUserRoleList(UserRoleQryDto userRoleQryDto) {

        UserRole userRole = new UserRole(userRoleQryDto);
        return baseMapper.selectList(new QueryWrapper<>(userRole));
    }
    @Override
    public Boolean saveUserRoleArray(List<UserRoleQryDto> userRoleQryDto) {

        if (userRoleQryDto == null) {
            return false;
        }
        int insert = baseMapper.saveUserRoleArray(userRoleQryDto);
        return insert > 0;
    }
}
