package com.data.financeapi;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.data.financeapi.mapper")
public class FinanceapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinanceapiApplication.class, args);
    }

}
