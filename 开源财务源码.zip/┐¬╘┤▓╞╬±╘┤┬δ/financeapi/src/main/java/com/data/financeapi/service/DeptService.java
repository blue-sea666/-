package com.data.financeapi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.DeptQryDto;
import com.data.financeapi.entity.Dept;
import com.data.financeapi.vo.DeptVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface DeptService extends IService<Dept> {
    Boolean addDept(DeptQryDto qry);

    Boolean updateDept(DeptQryDto qry);

    Boolean delDeptById(String deptId);

    List<DeptVo> qryDeptById(DeptQryDto deptQryDto) throws Exception;

    List<DeptVo> qryDeptList() throws Exception;
}
