package com.data.financeapi.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.entity.Menu;
import com.data.financeapi.vo.MenuVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Mapper
public interface MenuMapper extends BaseMapper<Menu> {
    List<MenuVo> qryMenuListByid(@Param("menuQryDto") MenuQryDto menuQryDto);
}
