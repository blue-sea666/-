package com.data.financeapi.vo;

import lombok.Data;

@Data
public class UserVo {

    private String Id;

    private String UserName;

    private String UserCode;

    private String UserTel;

    private String UserEmail;

    private String UserPassword;

    private String DeptId;
}