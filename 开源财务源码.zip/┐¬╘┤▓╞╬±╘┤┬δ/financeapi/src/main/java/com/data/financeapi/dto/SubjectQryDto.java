package com.data.financeapi.dto;

import lombok.Data;

@Data
public class SubjectQryDto {

    private String Id;

    private String SubjectCode;

    private String SubjectName;

    private Integer SubjectLevel;

    private String Pid;

    private String InsertTime;

    private String UpdateTime;

    private Integer isDel;

    private String MnemonicCode;

    private String SubjectCategory;

    private String SubjectCategoryName;

    private Integer BalanceDirection;

    private Integer ForeignAccount;

    private Integer EndExchange;

    private Integer TransAccount;

    private Integer CountmoneAccount;

    private String SubjectFullname;

    private Integer SubjectType;

    private Integer AccountStatus;

    private int pageNum;

    private int pageSize;
}