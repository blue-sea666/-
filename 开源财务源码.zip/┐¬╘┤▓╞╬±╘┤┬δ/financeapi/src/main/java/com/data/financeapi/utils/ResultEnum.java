package com.data.financeapi.utils;

/**
 * @author: 王薪鑫
 * @date: 2021年8月11日
 */
public enum ResultEnum {

    /**
     * 无操作
     */
    None("无操作", 0),

    /**
     * 成功
     */
    Success("成功", 200),

    /**
     * 失败
     */
    Fail("失败", 201),

    /**
     * 错误请求
     */
    ErrorRequest("错误请求", 202),

    /**
     * 未授权
     */
    NoAuthorization("未授权", 203),

    /**
     * 拒绝请求
     */
    RefuseRequest("拒绝请求", 204),

    /**
     * 未找到
     */
    NotFound("未找到", 205),

    /**
     * 参数不符合
     */
    NotParameter("参数不符合", 206),

    /**
     * 请求超时
     */
    RequestTimeOut("请求超时", 207),

    /**
     * 登录超时
     */
    LoginTimeOut("登录超时", 208),

    /**
     * 服务器错误
     */
    Error("服务器错误", 209),

    /**
     * http协议错误
     */
    ErrorHttp("http协议错误", 210),

    /**
     * 业务问题
     */
    Business("业务问题", 211);

    private String name;
    private int index;

    ResultEnum() {
    }

    ResultEnum(String name, int index) {
        this.name = name;
        this.index = index;
    }

    public static String getName(int index) {
        for (ResultEnum info : ResultEnum.values()) {
            if (info.getIndex() == index) {
                return info.getName();
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
