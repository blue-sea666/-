package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_subjectcategory")
public class SubjectCategory implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "cate_name")
    private String CateName;


    public SubjectCategory() {

    }
    public SubjectCategory(SubjectCategoryQryDto subjectCategoryQryDto) {
        BeanUtils.copyProperties(subjectCategoryQryDto, this);
    }

}