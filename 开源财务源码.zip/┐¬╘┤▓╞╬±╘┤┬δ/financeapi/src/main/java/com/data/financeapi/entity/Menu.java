package com.data.financeapi.entity;

import java.io.Serializable;
import java.util.ArrayList;

import com.baomidou.mybatisplus.annotation.TableField;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.MenuQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
@TableName("t_menu")
public class Menu implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "pid")
    private String Pid;

    @TableField(value = "level")
    private Integer Level;

    @TableField(value = "path")
    private String Path;

    @TableField(value = "label")
    private String Label;

    @TableField(value = "title")
    private String Title;

    @TableField(value = "component")
    private String Component;

    @TableField(value = "icon")
    private String Icon;

    @TableField(exist = false)
    private List<Menu> children = new ArrayList<>();

    @TableField(exist = false)
    Map<String,Object> meta = new HashMap<>();

    public Menu() {

    }
    public Menu(MenuQryDto menuQryDto) {
        BeanUtils.copyProperties(menuQryDto, this);
    }

}