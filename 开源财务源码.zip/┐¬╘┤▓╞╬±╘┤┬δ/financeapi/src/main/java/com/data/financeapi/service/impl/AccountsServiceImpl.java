package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.entity.Accounts;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.mapper.AccountsMapper;
import com.data.financeapi.mapper.SubjectMapper;
import com.data.financeapi.service.AccountsService;
import com.data.financeapi.service.SubjectService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.AccountsVo;
import com.data.financeapi.vo.SubjectVo;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class AccountsServiceImpl extends ServiceImpl<AccountsMapper, Accounts> implements AccountsService {
    @Override
    public String addAccounts(AccountsQryDto qry){
        String uuid=UUIDUtil.uuid();
        Accounts accounts=new Accounts(qry);
        accounts.setId(uuid);
        Date date = new Date(); // this object contains the current date value
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        accounts.setInsertTime(formatter.format(date));
        baseMapper.insert(accounts);
        return uuid;
    }
    @Override
    public Boolean updateAccounts(AccountsQryDto qry){
        Accounts accounts=new Accounts(qry);
        Date date = new Date(); // this object contains the current date value
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        accounts.setUpdateTime(formatter.format(date));
        return baseMapper.updateById(accounts) > 0;
    }
    @Override
    public Boolean delAccountsById(String accountsId) {
        Accounts accounts = new Accounts();
        accounts.setId(accountsId);
        return baseMapper.delete(new QueryWrapper<>(accounts))>0;
    }
    @Override
    public List<AccountsVo> qryAccountsList(AccountsQryDto accountsQryDto) {

        return baseMapper.qryAccountsList(accountsQryDto);
    }
}
