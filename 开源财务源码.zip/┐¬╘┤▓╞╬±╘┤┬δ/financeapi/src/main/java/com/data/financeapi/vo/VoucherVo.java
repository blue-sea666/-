package com.data.financeapi.vo;

import com.data.financeapi.dto.DeptQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
public class VoucherVo {

    private String id;

    private String VoucherTime;

    private String VoucherName;

    private String UserName;

    private String VoucherCode;

    private Integer VoucherStatus;

    private String AccountsName;

    private String AccountsId;

    public VoucherVo() {

    }
    public VoucherVo(VoucherQryDto voucherQryDto) {
        BeanUtils.copyProperties(voucherQryDto, this);
    }

}