package com.data.financeapi.vo;

import com.data.financeapi.dto.MenuQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class MenuVo {

    private String id;

    private String pid;

    private Integer level;

    private String path;

    private String name;

    private String component;

    private String icon;

    private List<MenuVo> children = new ArrayList<>();

    Map<String,Object> meta = new HashMap<>();

    public MenuVo() {

    }
    public MenuVo(MenuQryDto menuQryDto) {
        BeanUtils.copyProperties(menuQryDto, this);
    }

}