package com.data.financeapi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.data.financeapi.dto.UserAuthQryDto;
import com.data.financeapi.entity.UserAuth;
import com.data.financeapi.vo.UserAuthVo;

import java.util.List;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserAuthService extends IService<UserAuth> {

    Boolean addUserAuth(UserAuthQryDto qry);

    Boolean delUserAuthById(String roleId);

    Boolean saveUserAuthArray(List<UserAuthQryDto> userAuthQryDto) throws Exception;

    List<UserAuthVo> qryUserAuthList(UserAuthQryDto userAuthQryDto);
}
