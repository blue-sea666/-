package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.dto.VoucherDetailQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@TableName("t_voucherdetail")
public class VoucherDetail implements Serializable {

    @TableField("id")
    private String Id;

    @TableField("voucher_id")
    private String VoucherId;

    @TableField("summary_name")
    private String SummaryName;

    @TableField("subject_id")
    private String SubjectId;

    @TableField("subject_name")
    private String SubjectName;

    @TableField("debit_money")
    private double DebitMoney;

    @TableField("lender_money")
    private double LenderMoney;

    @TableField("insert_time")
    private String InsertTime;

    public VoucherDetail() {

    }
    public VoucherDetail(VoucherDetailQryDto voucherDetailQryDto) {
        BeanUtils.copyProperties(voucherDetailQryDto, this);
    }

}