package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.AccountsQryDto;
import com.data.financeapi.dto.AccountsSubjectQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_accountssubject")
public class AccountsSubject implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "accounts_id")
    private String AccountsId;

    @TableField(value = "subject_id")
    private String SubjectId;

    @TableField(value = "subject_status")
    private Integer SubjectStatus;

    @TableField(value = "start_money")
    private double StartMoney;

    public AccountsSubject() {

    }
    public AccountsSubject(AccountsSubjectQryDto accountsSubjectQryDto) {
        BeanUtils.copyProperties(accountsSubjectQryDto, this);
    }

}