package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.VoucherDetailQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.entity.VoucherDetail;
import com.data.financeapi.mapper.VoucherDetailMapper;
import com.data.financeapi.mapper.VoucherMapper;
import com.data.financeapi.service.VoucherDetailService;
import com.data.financeapi.service.VoucherService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.VoucherDetailVo;
import com.data.financeapi.vo.VoucherVo;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class VoucherDetailServiceImpl extends ServiceImpl<VoucherDetailMapper, VoucherDetail> implements VoucherDetailService {
    @Override
    public Boolean addVoucherDetail(VoucherDetailQryDto qry) {
        VoucherDetail voucherDetail = new VoucherDetail(qry);
        voucherDetail.setId(UUIDUtil.uuid());
        return baseMapper.insert(voucherDetail) > 0;
    }

    @Override
    public Boolean updateVoucherDetail(VoucherDetailQryDto qry) {
        VoucherDetail voucherDetail = new VoucherDetail(qry);
        return baseMapper.updateById(voucherDetail) > 0;
    }

    @Override
    public Boolean delVoucherDetailById(String Id) {
        VoucherDetail voucherDetail = new VoucherDetail();
        voucherDetail.setId(Id);
        return baseMapper.delete(new QueryWrapper<>(voucherDetail)) > 0;
    }

    public IPage<VoucherDetailVo> qryVoucherDetailListPage(Page<VoucherDetail> page, VoucherDetailQryDto qry) {

        return baseMapper.qryVoucherDetailListPage(page, qry);
    }
}
