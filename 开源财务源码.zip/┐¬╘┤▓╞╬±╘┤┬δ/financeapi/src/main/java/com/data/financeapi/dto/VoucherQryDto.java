package com.data.financeapi.dto;

import lombok.Data;

@Data
public class VoucherQryDto {

    private String id;

    private String VoucherTime;

    private String VoucherName;

    private String VoucherCode;

    private Integer VoucherStatus;

    private String AccountsId;

    private int pageNum;

    private int pageSize;
}