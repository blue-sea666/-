package com.data.financeapi.dto;

import lombok.Data;

@Data
public class RoleQryDto{

    private String Id;

    private String RoleName;

    private int pageNum;

    private int pageSize;
}