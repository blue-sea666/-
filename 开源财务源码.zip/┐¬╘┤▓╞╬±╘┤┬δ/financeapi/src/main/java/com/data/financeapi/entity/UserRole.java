package com.data.financeapi.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.data.financeapi.dto.UserRoleQryDto;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

@Data
@TableName("t_userrole")
public class UserRole implements Serializable {

    @TableField("id")
    private String Id;

    @TableField(value = "role_id")
    private String RoleId;

    @TableField(value = "user_id")
    private String UserId;

    @TableField(value = "menu_id")
    private String MenuId;

    @TableField(value = "level")
    private String Level;

    public UserRole() {

    }
    public UserRole(UserRoleQryDto userRoleQryDto) {
        BeanUtils.copyProperties(userRoleQryDto, this);
    }

}