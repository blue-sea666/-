package com.data.financeapi.vo;

import lombok.Data;

@Data
public class UserRoleVo {

    private String Id;

    private String RoleId;

    private String UserId;
}