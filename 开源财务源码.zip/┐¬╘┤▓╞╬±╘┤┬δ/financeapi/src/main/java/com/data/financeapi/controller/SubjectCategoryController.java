package com.data.financeapi.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.service.SubjectCategoryService;
import com.data.financeapi.service.SubjectService;
import com.data.financeapi.utils.R;
import com.data.financeapi.utils.Result;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.SubjectVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 会员表 前端控制器
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@RestController
@RequestMapping("/financeapi/subjectcategory")
@CrossOrigin //解决跨域问题
public class SubjectCategoryController {
    @Autowired
    SubjectCategoryService subjectCategoryService;
    @PostMapping("/getSubjectCategory")
    public Result getSubjectCategory(@RequestBody SubjectCategoryQryDto qry) {

        try {
            Page<SubjectCategory> page = new Page<>();
            page.setCurrent(qry.getPageNum());
            page.setSize(qry.getPageSize());
            IPage<SubjectCategoryVo> list=subjectCategoryService.qrySubjectCategoryListPage(page, qry);
            return Result.ok(list);
        } catch (Exception e) {
            return Result.fail("内部错误，请联系管理员");
        }
    }

    @PostMapping("/update")
    public R updateSubject(@RequestBody SubjectCategoryQryDto qry){
        try{
            subjectCategoryService.updateSubjectCategory(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/save")
    public R addSubject(@RequestBody SubjectCategoryQryDto qry){
        try{
            subjectCategoryService.addSubjectCategory(qry);
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }

    @PostMapping("/delete")
    public R deleteById(@RequestBody SubjectCategoryQryDto qry){
        try{
            subjectCategoryService.delSubjectCategoryById(qry.getId());
            return R.ok();
        }catch (Exception e){
            return R.error();
        }
    }
}

