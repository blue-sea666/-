package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.SubjectCategoryQryDto;
import com.data.financeapi.dto.VoucherQryDto;
import com.data.financeapi.entity.SubjectCategory;
import com.data.financeapi.entity.Voucher;
import com.data.financeapi.mapper.SubjectCategoryMapper;
import com.data.financeapi.mapper.VoucherMapper;
import com.data.financeapi.service.SubjectCategoryService;
import com.data.financeapi.service.VoucherService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.SubjectCategoryVo;
import com.data.financeapi.vo.VoucherVo;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class VoucherServiceImpl extends ServiceImpl<VoucherMapper, Voucher> implements VoucherService {
    @Override
    public String addVoucher(VoucherQryDto qry) {
        String voucherId=UUIDUtil.uuid();
        Voucher voucher = new Voucher(qry);
        voucher.setId(voucherId);
        baseMapper.insert(voucher);
        return  voucherId;
    }

    @Override
    public Boolean updateVoucher(VoucherQryDto qry) {
        Voucher voucher = new Voucher(qry);
        return baseMapper.updateById(voucher) > 0;
    }

    @Override
    public Boolean delVoucherById(String Id) {
        Voucher voucher = new Voucher();
        voucher.setId(Id);
        return baseMapper.delete(new QueryWrapper<>(voucher)) > 0;
    }

    public IPage<VoucherVo> qryVoucherListPage(Page<Voucher> page, VoucherQryDto qry) {

        return baseMapper.qryVoucherListPage(page, qry);
    }
}
