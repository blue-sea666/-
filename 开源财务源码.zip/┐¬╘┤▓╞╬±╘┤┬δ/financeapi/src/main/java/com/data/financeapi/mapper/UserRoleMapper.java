package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.data.financeapi.dto.UserRoleQryDto;
import com.data.financeapi.entity.UserRole;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {
    int saveUserRoleArray(@Param("userRoleDto")List<UserRoleQryDto> UserRoleQryDtoList);

    List<UserRole> qryUserRoleList(@Param("userRoleDto") UserRoleQryDto userAuthQryDto);
}
