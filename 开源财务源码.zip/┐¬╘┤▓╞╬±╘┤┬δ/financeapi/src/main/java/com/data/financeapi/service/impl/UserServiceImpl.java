package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.User;
import com.data.financeapi.mapper.UserMapper;
import com.data.financeapi.service.UserService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.UserVo;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    @Override
    public Boolean addUser(UserQryDto qry){
        User user=new User(qry);
        user.setId(UUIDUtil.uuid());
        String md5Password = DigestUtils.md5DigestAsHex(user.getUserPassword().getBytes(StandardCharsets.UTF_8));
        user.setUserPassword(md5Password);
        return baseMapper.insert(user) > 0;
    }
    @Override
    public Boolean updateUser(UserQryDto qry){
        User role=new User(qry);
        return baseMapper.updateById(role) > 0;
    }
    @Override
    public Boolean delUserById(String userId) {
        User user = new User();
        user.setId(userId);
        return baseMapper.delete(new QueryWrapper<>(user))>0;
    }
    @Override
    public IPage<UserVo> qryUserListPage(Page<User> page, UserQryDto userQryDto) {

        User user = new User(userQryDto);

        return baseMapper.qryUserListPage(page, userQryDto);
    }
    @Override
    public IPage<UserVo> qryUserPageByid(Page<User> page, UserQryDto userQryDto) {

        User user = new User(userQryDto);

        return baseMapper.qryUserPageByid(page, userQryDto);
    }
    @Override
    public List<UserVo> qryUserList(UserQryDto userQryDto) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("user_code", userQryDto.getUserCode());
        String password=DigestUtils.md5DigestAsHex(userQryDto.getUserPassword().getBytes(StandardCharsets.UTF_8));
        queryWrapper.eq("user_password", password);
        return baseMapper.selectList(queryWrapper);
    }
}
