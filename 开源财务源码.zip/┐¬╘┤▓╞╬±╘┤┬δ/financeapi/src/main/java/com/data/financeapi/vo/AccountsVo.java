package com.data.financeapi.vo;

import lombok.Data;

@Data
public class AccountsVo {

    private String Id;

    private String AccountsName;

    private String AccountsSystem;

    private String SetTime;

    private String InsertTime;

    private Integer AccountsStatus;
}