package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.DeptQryDto;
import com.data.financeapi.entity.Dept;
import com.data.financeapi.mapper.DeptMapper;
import com.data.financeapi.service.DeptService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.DeptVo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class DeptServiceImpl extends ServiceImpl<DeptMapper, Dept> implements DeptService {
    @Override
    public Boolean addDept(DeptQryDto qry){
        Dept dept=new Dept(qry);
        String uuid=UUIDUtil.uuid();
        dept.setId(uuid);
       return baseMapper.insert(dept)>0;
    }
    @Override
    public Boolean updateDept(DeptQryDto qry){
        Dept dept=new Dept(qry);
        return baseMapper.updateById(dept) > 0;
    }
    @Override
    public Boolean delDeptById(String deptId) {
        Dept dept = new Dept();
        dept.setId(deptId);
        return baseMapper.delete(new QueryWrapper<>(dept))>0;
    }
    @Override
    public List<DeptVo> qryDeptById(DeptQryDto deptQryDto) {

        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq("pid", deptQryDto.getId());
        return baseMapper.selectList(queryWrapper);
    }
    @Override
    public List<DeptVo> qryDeptList() {

        return baseMapper.qryDeptList();
    }
}
