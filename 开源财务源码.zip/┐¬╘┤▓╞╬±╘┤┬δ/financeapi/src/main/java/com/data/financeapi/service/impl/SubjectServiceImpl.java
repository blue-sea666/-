package com.data.financeapi.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.entity.User;
import com.data.financeapi.mapper.SubjectMapper;
import com.data.financeapi.mapper.UserMapper;
import com.data.financeapi.service.SubjectService;
import com.data.financeapi.service.UserService;
import com.data.financeapi.utils.UUIDUtil;
import com.data.financeapi.vo.SubjectVo;
import com.data.financeapi.vo.UserVo;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * <p>
 * 会员表 服务实现类
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
@Service
public class SubjectServiceImpl extends ServiceImpl<SubjectMapper, Subject> implements SubjectService {
    @Override
    public Boolean addSubject(SubjectQryDto qry){
        Subject subject=new Subject(qry);
        subject.setId(UUIDUtil.uuid());
        return baseMapper.insert(subject) > 0;
    }
    @Override
    public Boolean updateSubject(SubjectQryDto qry){
        Subject subject=new Subject(qry);
        return baseMapper.updateById(subject) > 0;
    }
    @Override
    public Boolean delSubjectById(String subjectId) {
        Subject subject = new Subject();
        subject.setId(subjectId);
        return baseMapper.delete(new QueryWrapper<>(subject))>0;
    }
    @Override
    public List<SubjectVo> qrySubjectList(SubjectQryDto subjectQryDto) {

        return baseMapper.qrySubjectList(subjectQryDto);
    }
    @Override
    public List<SubjectVo> qrySubjectById(SubjectQryDto subjectQryDto) {

        return baseMapper.qrySubjectById(subjectQryDto);
    }
}
