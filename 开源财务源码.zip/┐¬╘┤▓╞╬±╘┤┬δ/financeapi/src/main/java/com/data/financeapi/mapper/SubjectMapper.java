package com.data.financeapi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.data.financeapi.dto.MenuQryDto;
import com.data.financeapi.dto.SubjectQryDto;
import com.data.financeapi.dto.UserQryDto;
import com.data.financeapi.entity.Subject;
import com.data.financeapi.entity.User;
import com.data.financeapi.vo.MenuVo;
import com.data.financeapi.vo.SubjectVo;
import com.data.financeapi.vo.UserVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 会员表 Mapper 接口
 * </p>
 *
 * @author 李立志
 * @since 2022-01-11
 */
public interface SubjectMapper extends BaseMapper<Subject> {
    List<SubjectVo> qrySubjectList(@Param("SubjectQryDto") SubjectQryDto subjectQryDto);
    List<SubjectVo> qrySubjectById(@Param("SubjectQryDto") SubjectQryDto subjectQryDto);
}
