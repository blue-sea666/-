package com.data.financeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class webapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
